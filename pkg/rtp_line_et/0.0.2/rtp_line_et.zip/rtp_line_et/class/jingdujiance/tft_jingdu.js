'use strict'

const JingduBase = require('./base');
const { start_position, station_db, jingdu_table_name } = require('../../config.json');
const { xlog, path } = require('xlog');

const logger = new xlog({
    projectName: 'rtp_line_et',
    filePath: path.join(__dirname, '../../logs'),
    category: ['jingdu', 'tft_jingdu'],
    logsName: 'tft_jingdu',
    logging: true
});
class SynchronizeTftJingdu extends JingduBase {

    constructor(panel, stationInfo, PanelSourceTftJingdu, seqSource, seqAim, rotateConf) {
        super(panel, stationInfo, PanelSourceTftJingdu, seqSource, seqAim, logger, station_db.tft_jingdu_db_config.host, start_position.tft_jindu, rotateConf);
    }

    static getInstance(panel, stationInfo, PanelSourceTftJingdu, seqSource, seqAim, rotateConf) {
        if (SynchronizeTftJingdu.instance) {
            return SynchronizeTftJingdu.instance;
        } else {
            SynchronizeTftJingdu.instance = new SynchronizeTftJingdu(panel, stationInfo, PanelSourceTftJingdu, seqSource, seqAim, rotateConf);
            return SynchronizeTftJingdu.instance;
        }
    }
    /**
     * 根据panel获取全部信息
     * @param {String} panel_id
     */
    async getNewstInfoByPanelId(panel_id) {
        try {
            let panel_info = await this.sequelize_src.query(`select panel_id , save_path , is_ok , gen_time , gen_time_str from ${jingdu_table_name} where panel_id = "${panel_id}" order by uid DESC limit 1`, { type: this.sequelize_src.QueryTypes.SELECT });
            if (panel_info.length) {
                console.log(panelInfo[0].save_path, '===');
                return {
                    ...panel_info[0],
                    save_path: panelInfo[0].save_path ? `http://${tft_jingdu_db_config.host}:3144/${panelInfo[0].save_path.slice(3)}` : ''
                };
            }
            return null;
        } catch (error) {
            console.log(error);
            return null;
        }
    }
}

module.exports = SynchronizeTftJingdu;
