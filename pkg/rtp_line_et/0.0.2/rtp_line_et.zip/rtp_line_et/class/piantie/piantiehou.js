/**
 * @file {同步 偏贴后工位数据
 */
'use strict'

const PiantieBase = require('./base');
const { initPiantiehouFlawData } = require('../../model/piantie/piantiehou/flaw')
const { initPiantiehouFlawFilterData } = require('../../model/piantie/piantiehou/flaw_filter')
const { initPiantiehouJobData } = require('../../model/piantie/piantiehou/job')
const { initPiantiehouPanelData } = require('../../model/piantie/piantiehou/panel')
const { start_position } = require('../../config.json');
const { xlog, path } = require('xlog');
const logger = new xlog({
    projectName: 'rtp_line_et',
    filePath: path.join(__dirname, '../../logs'),
    category: ['piantie', 'piantiehou'],
    logsName: 'piantiehou',
    logging: true
});
const { piantiehou_db_config } = require('../../config.json').station_db
class SynchronizePiantiehou extends PiantieBase {

    currentPanelID = null // 记录当前的panel_id

    constructor(panel, sequelize_source, sequelize_aim, stationInfo, rotateConf) {
        initPiantiehouFlawData(sequelize_aim);
        initPiantiehouFlawFilterData(sequelize_aim);
        initPiantiehouJobData(sequelize_aim);
        initPiantiehouPanelData(sequelize_aim);
        super(panel, sequelize_source, sequelize_aim, stationInfo, logger, start_position.piantiehou, piantiehou_db_config.host, rotateConf);
    }
    /**
     * 初始化参数
     * @param {string} panel 表的模型对象
     * @param {Sequeliz} sequelize_source 源表的sequelize实例
     * @param {Sequeliz} sequelize_aim 目标表的sequelize实例
     * @param {string} stationName 工站名（便于日志区分）
     * @returns
     */
    static getInstance(panel, sequelize_source, sequelize_aim, stationInfo, rotateConf) {
        if (SynchronizePiantiehou.instance) {
            return SynchronizePiantiehou.instance;
        } else {
            SynchronizePiantiehou.instance = new SynchronizePiantiehou(panel, sequelize_source, sequelize_aim, stationInfo, rotateConf);
            return SynchronizePiantiehou.instance;
        }
    }
    /**
     * 获取最新的panel信息
     */
    async getNewsPanel() {
        let panel_id = await this.PanelPiantie.getLatestPanelFromSource(this.sequelize_source);
        if (panel_id) {
            return panel_id;
        }
    }
    /**
     * 根据panel获取全部信息
     * @param {String} panel_id
     * @returns Object | null
     */
    async getNewstInfoByPanelId(panel_id) {
        try {
            let panel_info = await this.handPanelInfo(panel_id);
            let job_info = await this.handJobInfo(panel_id);
            let flaw_info = await this.handFlawInfo(panel_id);
            let flaw_filter_info = await this.handFlawFilterinfo(panel_id);
            let stations = flaw_filter_info.map((item) => {
                return {
                    station_id: item.station_id,
                    station_name: item.station_name
                }
            })
            let result = stations.filter(item => {
                return item.station_id;
            })
            return {
                panel_info,
                job_info,
                flaw_info,
                flaw_filter_info,
                stations: result
            }
        } catch (error) {
            this.logger.err(error);
            return null;
        }
    }
    // 回写checked字段
    async reWriteChecked(panelId) {
        try {
            let res = await this.PanelPiantie.reWriteChecked(this.PanelPiantie, panelId);
            if (res[0] && res[0].dataValues) {
                this.logger.info(`${this.stationName} Panel checked回写成功!`);
            }
        } catch (error) {
            this.logger.err(error);
        }
    }
}

module.exports = SynchronizePiantiehou;
