/**
 * @file{同步 cf 精度检测工站库}
 */
'use strict';

const schedule = require('node-schedule');
const {
    transformData,
    formatFlawFilterData,
    parseDetectParam
} = require('../../uitls/tool');
let handleUuid = require('../summary/handle_uuid');
const Tools = require('../../uitls/tools');
const queue = require('queue');

class PolBase {

    constructor(tableModel, sequelize_source, sequelize_source_ipu, sequelize_aim, stationInfo, logger, startPostion, sourceIp, pol_gap_num, rotateConf) {
        //各个表的操作模型对象
        this.FlawFilterPol = tableModel.FlawFilterCfPol || tableModel.FlawFilterTftPol;
        this.PanelPol = tableModel.PanelCfPol || tableModel.PanelTftPol;
        this.JobPol = tableModel.JobCfPol || tableModel.JobTftPol;
        this.FlawPol = tableModel.FlawCfPol || tableModel.FlawTftPol;

        this.sequelize_source = sequelize_source;
        this.sequelize_source_ipu = sequelize_source_ipu;
        this.sequelize_aim = sequelize_aim;
        this.stationName = stationInfo.station_name_standard;
        this.stationInfo = stationInfo;
        this.uploadPanelTimes = 0;
        this.sourceDoffMaxUid = 0;
        this.uploadPanelTimes_flawFilter = 0;
        //当前片
        this.currentPanel = null;
        // 当前缺陷片
        this.currentFlawFilterArr = [];
        this.taskQueue_panel = queue({ concurrency: 1, autostart: true });
        this.taskQueue_job = queue({ concurrency: 1, autostart: true });
        this.timeDelay = '*/2 * * * * *';
        this.logger = logger;
        this.sourceIp = sourceIp;
        this.startPostion = startPostion;
        this.pol_gap_num = pol_gap_num;
        this.rotateConf = rotateConf;
        this.init();
    }
    // 初始化
    async init() {

        // 获取当前执行位置
        await this.getSyncPosition();

        // 开始定时缓存任务
        schedule.scheduleJob(this.timeDelay, () => {
            this.addTaskQueue();
        });
    }
    // push task queue
    addTaskQueue() {
        // pane, flaw, flaw_filter
        this.taskQueue_panel.push(async cb => {
            await this.handPanelInfo();
            cb();
        })
        // job
        this.taskQueue_job.push(async cb => {
            await this.handJobInfo();
            cb();
        })
    }
    /**
     * 获取各个表的同步位置
     */
    async getSyncPosition() {
        try {
            // panel 同步起点 以源库sheet uid为准
            this.panelUid = await this.PanelPol.getLatestPanelId(this.sequelize_aim);

            if (this.panelUid == 1) {
                this.panelUid = this.startPostion.panelUid;
            }

            // job 同步起点 job uid为准
            this.jobUid = await this.JobPol.getLatestJobId(this.sequelize_aim);

            if (this.jobUid == 1) {
                this.jobUid = this.startPostion.jobUid;
            }

            // flaw_filter uid
            this.FlawFilterId = await this.FlawFilterPol.getLatestFlawFilterId(this.sequelize_aim, this.panelUid);
            this.currentFlawFilterId = this.panelUid;
        } catch (error) {
            this.logger.err(error);
        }
    }
    /**
     * 查询某片的缺陷，并转成具有父子关系的缺陷数组
     * @param {panelId} panelId
     * @returns 具有父子关系的缺陷分类数组
     */
    async transformFlawFilteDataToDetectParam(panelId) {
        try {
            // 查询flaw的数组
            let res = await this.FlawFilterPol.getFlawFilterInfoByPanelId(this.sequelize_source, this.panelUid, this.stationInfo.station_alias);
            // 查询所有的缺陷分类
            let detect = await this.FlawFilterPol.getAllFlawType(this.sequelize_source, panelId);
            // 将RTS的缺陷分类转成数组形式[{ flaw_class_type:'', symbol: '', show: '', color: '', shape: ''}]
            let { flawTypeArr } = parseDetectParam(detect[0].detect_param, this.stationInfo.station_alias);
            // 如果此片上有缺陷就统计缺陷，否则返回一个全集全集中是没有缺陷的缺陷json

            if (res.length) {
                // 转成有flaw_count的缺陷分类数组
                let map = new Map();
                let flawFilterArray = [];
                for (let i = 0; i < res.length; i++) {
                    if (map.has(res[i].flaw_class_type)) {
                        map.set(res[i].flaw_class_type, {
                            ...res[i],
                            flaw_count: ++map.get(res[i].flaw_class_type).flaw_count
                        });
                    } else {
                        map.set(res[i].flaw_class_type, {
                            ...res[i],
                            flaw_count: 1
                        });
                    }
                }
                // console.log(map);
                for (const i of map) {
                    const a = i[1];
                    flawFilterArray.push(i[1]);
                }
                let resultData = [];
                flawTypeArr.forEach(item => {
                    const data = {
                        ...item,
                    };
                    delete data.uid;
                    delete data.flaw_class_type;
                    flawFilterArray.forEach(flawFilterItem => {
                        if (flawFilterItem.flaw_class_type == item.flaw_class_type) {
                            data.flaw_count = flawFilterItem.flaw_count;
                            data.station_id = flawFilterItem.station_id;
                            data.station_name = flawFilterItem.station_name;
                        }
                    })
                    resultData.push({
                        ...data,
                        panel_id: flawFilterArray[0].panel_id,
                        panel_table_uid: flawFilterArray[0].panel_table_uid,
                        flaw_class_type: item.flaw_class_type,
                        flaw_count: data.flaw_count ? data.flaw_count : 0,
                        // symbol: 'R'
                    })
                })
                // 转成具有父子关系的数组
                return formatFlawFilterData(resultData, true);
            } else {
                // 无缺陷，加上缺陷类型，并转换成父子关系的缺席分类返回
                return formatFlawFilterData(flawTypeArr.map(item => ({ ...item, flaw_count: 0 })), true);
            }
        } catch (error) {
            this.logger.err(error);
            return [];
        }
    }
    /**
     * hand FlawFilter
     * @param {String} panelId
     */
    async handFlawFilterInfo(panelId) {
        try {
            if (panelId) {
                return await this.transformFlawFilteDataToDetectParam(panelId);
            }
            // 1, 查目标库flaw_filter的最新的panel更新心位置flawFilterNewsPaneUId
            // 2, 查询这个panel的缺陷分类，
            let res = await this.FlawFilterPol.getFlawFilterInfoByPanelId(this.sequelize_source, this.panelUid, this.stationInfo.station_alias);
            // 3, 转换对应逻辑并post到目标库
            if (res.length) {
                let map = transformData(res);
                let flawFilterArray = [];
                // 重复的片的缺陷不从新位置开始，而是从第一次开始的位置开始
                if (this.panelUid != this.currentFlawFilterId) {
                    this.FlawFilterId = this.FlawFilterId + this.currentFlawFilterArr.length;
                }
                let detect = await this.FlawFilterPol.getAllFlawType(this.sequelize_source, res[0].panel_id);
                // 将RTS的缺陷分类转成数组形式[{ flaw_class_type:'', symbol: '', show: '', color: '', shape: ''}]
                let { flawTypeArr, flawTypeObj } = parseDetectParam(detect[0].detect_param, this.stationInfo.station_alias);
                // console.log("flawTypeArr", flawFilterArray)
                let index = 1;
                for (const i of map) {
                    flawFilterArray.push({
                        ...i[1],
                        id: this.FlawFilterId + index
                    })
                    index++;
                }
                let resultData = [];
                flawFilterArray.forEach(flawFilterItem => {
                    // remove traverse flawtypeArr instead of Object Key match ;zqf
                    if (flawTypeObj[flawFilterItem.flaw_class_type]) {
                        let oneFlaw = flawTypeObj[flawFilterItem.flaw_class_type]
                        resultData.push({
                            ...flawFilterItem,
                            flaw_class_type: flawFilterItem.flaw_class_type,//+ '__' + this.stationInfo.station_alias,
                            color: oneFlaw.color,
                            show: oneFlaw.show,
                            shape: oneFlaw.shape,
                            symbol: oneFlaw.symbol
                        })
                    }
                    // flawTypeArr.forEach(item => {
                    //     if (flawFilterItem.flaw_class_type == item.flaw_class_type) {
                    //         resultData.push({
                    //             ...flawFilterItem,
                    //             // TODO flaw_class_type: flawFilterItem.flaw_class_type,
                    //             flaw_class_type: flawFilterItem.flaw_class_type,//+ '__' + this.stationInfo.station_alias,
                    //             color: item.color,
                    //             show: item.show,
                    //             shape: item.shape,
                    //             symbol: item.symbol
                    //         })
                    //     }
                    // })
                })
                this.currentFlawFilterId = this.panelUid;
                this.currentFlawFilterArr = resultData;
                // 上传缺陷分类
                await this.postDataToLineDb(this.FlawFilterPol, resultData, 'flaw_filter');
                this.logger.info(`${(resultData[0] || {}).panel_id}片的flaw_filter上传${this.stationName} 工站sucess!`);
                return resultData;
            }
            return [];
        } catch (_) {
            this.logger.err(_);
            return [];
        }
    }
    /**
     * hand  Flaw
     * @param {String} panelId
     */
    async handFlawInfo(panelInfo) {
        try {
            if (panelInfo.panelId) {
                let res = await this.FlawPol.getFlawInfoByPanelId(this.sequelize_source, panelId, this.stationInfo.station_alias);
                res = res.map(item => {
                    let temp = '';
                    if (item.save_path) {
                        temp = item.save_path.split("/");
                        // 把内网IP 转成 能与产线直连的 ip
                        temp[2] = this.sourceIp;
                    }
                    return {
                        ...item,
                        save_path: temp == '' ? '' : temp.join('/')
                    }
                })
                return res;
            }
            // 获取 缺陷信息
            let res = await this.FlawPol.getFlawInfoByPanelId(this.sequelize_source, this.sequelize_source_ipu, this.panelUid, this.stationInfo.station_alias);
            // debugger;
            // 查询所有的缺陷分类
            let detect = await this.FlawFilterPol.getAllFlawType(this.sequelize_source, this.panelUid);
            let { flawTypeObj } = parseDetectParam(detect[0].detect_param, this.stationInfo.station_alias);

            if (res.length) {
                let rotatePoints = {};
                res = res.map(item => {
                    let temp = '';
                    if (item.save_path) {
                        temp = item.save_path.split("/");
                        // 把内网IP 转成 能与产线直连的 ip
                        temp[2] = this.sourceIp;
                    }
                    let flawInfoExt = undefined
                    if (flawTypeObj && flawTypeObj[item.flaw_class_type]) {
                        flawInfoExt = flawTypeObj[item.flaw_class_type]
                    }

                    // 旋转flaw
                    rotatePoints = Tools.getRotatedFlawPoints(
                        {
                            x: item.center_pos_cd,
                            y: item.center_pos_md
                        },
                        {
                            rotate: this.rotateConf.rotate,
                            xMirror: this.rotateConf.xMirror,
                            height: panelInfo.length_md,
                            width: panelInfo.length_cd
                        }
                    )

                    return {
                        ...item,
                        save_path: temp == '' ? '' : temp.join('/'),
                        show: flawInfoExt ? flawInfoExt.show : flawInfoExt,
                        ui_show_text: flawInfoExt ? flawInfoExt.symbol : flawInfoExt,
                        center_pos_cd: rotatePoints.x,
                        center_pos_md: rotatePoints.y
                    }
                })

                // post 目标库wuquxian
                await this.postDataToLineDb(this.FlawPol, res, 'flaw');
                this.logger.info(`panel_info表uid: ${this.panelUid}的缺陷信息同步成功`);
                return res;
            }
            return [];
        } catch (_) {
            console.log(_)
            this.logger.err(_);
            return []
        }
    }
    /**
     * hand job
     * @param {String} panelId
     */
    async handJobInfo(panelId) {
        try {
            if (panelId) {
                let res = await this.JobPol.getJobInfoByPanelId(this.sequelize_source, panelId);
                return res;
            }
            let res = await this.JobPol.getJobInfoByPanelId(this.sequelize_source, this.jobUid ? this.jobUid : 1);
            // 最新的job_uid
            let maxJobUid = await this.JobPol.getMaxUidfromSourceJob(this.sequelize_source);
            if (res) {
                // 查询有panel_id的膜信息
                const jobInfo = await this.getPanelExistJobInfo(res);
                // 存进目标库
                let result = this.postDataToLineDb(this.JobPol, jobInfo, 'job');
                if (result) {
                    this.logger.info(`${res.job_name}工单上传${this.stationName} 工站sucess!`);
                } else {
                    this.logger.info(`${res.job_name}工单上传${this.stationName} 工站failed!`)
                    return false;
                }

                // 如果此片是最新片，继续更新
                if (res.ok_number + res.ng_number != res.panel_sum && maxJobUid == this.jobUid) {
                    this.logger.info(`job_nameL: ${res.job_name}需要再更新一次!`);
                    return false;
                }
            }
            // 没到最新位置，一直往最新位置更新
            this.jobUid < maxJobUid ? this.jobUid++ : this.jobUid;
        } catch (error) {
            this.logger.err(error);
        }
    }
    /**
     * 只同步有panel的sheet的job信息
     * @param {Obejct} job_info sheet的job信息
     */
    async getPanelExistJobInfo(job_info) {
        try {
            // 获取有panel的片的总数，ok，ng
            const panelExistJobInfo = await this.JobPol.getPanelExistJobInfo(this.sequelize_source, this.jobUid, job_info.panel_sum);
            return {
                ...job_info,
                ...panelExistJobInfo
            }
        } catch (error) {
            this.logger.err(error);
        }

    }
    /**
     * hand panel
     * @param {String} panelId
     */
    async handPanelInfo(panelId) {
        try {
            if (panelId) {
                let panelInfo = await this.PanelPol.getLatestPanel(this.sequelize_source, panelId);
                if (!panelInfo) return [];

                let panelPolInfo = {
                    ...panelInfo
                    // is_ok: panelInfo.flaw_count > 0 ? 0 : 1
                }
                // 剔除掉三个不要的属性
                delete panelPolInfo.head_md;
                delete panelPolInfo.create_time;
                delete panelPolInfo.sheet_id_seq;
                return panelPolInfo;
            }

            // 查询 sheet 表 uidd对应的膜信息
            let panelInfo = await this.PanelPol.getLatestPanel(this.sequelize_source, this.panelUid);
            let maxPanelUid = await this.PanelPol.getMaxUidfromSourcePanel(this.sequelize_source);
            this.logger.info(`当前片PID: ${panelInfo ? panelInfo.panel_id : null}  max-sheet-uid: ${maxPanelUid}, 当前sheet-uid: ${this.panelUid}`)

            if (panelInfo) {
                // 如果此片无panel_id跳过
                if (!panelInfo.panel_id) {
                    this.panelUid < maxPanelUid - this.pol_gap_num ? this.panelUid++ : '';
                    this.logger.info(`当前片无panel_id --> max-sheet-uid: ${maxPanelUid}, 当前sheet-uid: ${this.panelUid}`);
                    return;
                }

                // 缺陷分类json
                let detectParamData = await this.transformFlawFilteDataToDetectParam(panelInfo.panel_id);
                let panelPolInfo = {
                    ...panelInfo,
                    // is_ok: panelInfo.flaw_count > 0 ? 0 : 1,
                    checked: false,
                    detectParam: `${JSON.stringify(detectParamData)}`,
                    // 旋转角度引起的高度变化
                    length_md: this.rotateConf.rotate % 180 == 0 ? panelInfo.length_md : panelInfo.length_cd,
                    length_cd: this.rotateConf.rotate % 180 == 0 ? panelInfo.length_cd : panelInfo.length_md
                }

                // 剔除掉三个不要的属性
                delete panelPolInfo.head_md;
                delete panelPolInfo.create_time;
                delete panelPolInfo.sheet_id_seq;
                // 存进目标库
                await this.postDataToLineDb(this.PanelPol, panelPolInfo, 'panel');
                // flaw
                const flawInfo = await this.handFlawInfo({
                    length_md: panelInfo.length_md,
                    length_cd: panelInfo.length_cd
                });
                // flaw_filter
                const flawFilterInfo = await this.handFlawFilterInfo();
                // 这片的完整信息
                const panelAllInfo = {
                    panelInfo: panelPolInfo,
                    flawInfo,
                    flawFilterInfo
                }
                // 生成uuid
                await handleUuid.addQueue(this.sequelize_aim, panelInfo.panel_id, this.stationName, panelAllInfo);
                this.logger.info(`sheet_id: ${this.panelUid} 上传成功!`);

                this.panelUid < maxPanelUid - this.pol_gap_num ? this.panelUid++ : '';
            }
        } catch (_) {
            this.logger.err(_);
            console.log(_);
        }
    }
    /**
     * 上传data到产线db的指定表中
     * @param {} operatorName 表的操作对象
     * @param {Object} data 上传的数据
     */
    async postDataToLineDb(operatorName, data) {
        try {
            let res = await operatorName.uploadPolInfo(operatorName, data);
            return (res.dataValues || res.length) ? true : false;
        } catch (_) {
            this.logger.err(_);
            return false;
        }
    }
    async getNewsDataFromLineDb() {

    }
}

module.exports = PolBase;
