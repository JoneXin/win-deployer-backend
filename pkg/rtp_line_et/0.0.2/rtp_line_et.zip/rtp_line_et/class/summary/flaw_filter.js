const { linedb_piantiehou_config, linedb_cf_jingdujiance_config, linedb_cf_pol_config, linedb_piantieqian_config, linedb_tft_jingdujiance_config, linedb_tft_pol_config, linedb_summary_config } = require('../../config.json').line_db;
const seqPiantiehou = require('../../lib/db').getSequelizeInstance(linedb_piantiehou_config);
const seqPiantieqian = require('../../lib/db').getSequelizeInstance(linedb_piantieqian_config);
// const seqCfJingdujiance = require('../../lib/db').getSequelizeInstance(linedb_cf_jingdujiance_config);
// const seqTftJingdujiance = require('../../lib/db').getSequelizeInstance(linedb_tft_jingdujiance_config);
const seqCfPol = require('../../lib/db').getSequelizeInstance(linedb_cf_pol_config);
const seqTftPol = require('../../lib/db').getSequelizeInstance(linedb_tft_pol_config);
const seqRtpSummary = require('../../lib/db').getSequelizeInstance(linedb_summary_config);
const flawFilterModel = require('../../model/summary/flaw_filter');
const getOpenstaions = require('../../uitls/getOpenStations');

class flawFilter {
    constructor() {
        // 初始化model
        flawFilterModel.initFlawFilterData(seqRtpSummary);

        // 同步数据库的配置，可放在json文件中
        this.syncFlawFilterConfig = {
            syncLimit: 50
        };

        // seq实例的列表，严格按照先后顺序配置，后续的更新顺序会按照这个顺序来
        this.seqInstanceList = [
            {
                name: 'rtp_piantieqian',
                instance: seqPiantieqian,
                stationName: 'piantieqian'
            },
            {
                name: 'rtp_tft_pol',
                instance: seqTftPol,
                stationName: 'tft_pol'
            },
            {
                name: 'rtp_cf_pol',
                instance: seqCfPol,
                stationName: 'cf_pol'
            },
            {
                name: 'rtp_piantiehou',
                instance: seqPiantiehou,
                stationName: 'piantiehou'
            }
        ];
        this.init();
    }

    async init() {
        let openStations = await getOpenstaions();
        // 动态指定同步工站
        this.seqInstanceList = this.seqInstanceList.filter(item => {
            for (let i = 0; i < openStations.length; i++) {
                if (openStations[i].station_name == item.stationName) {
                    return true;
                }
            }
        })
        console.log(`flaw_filter的汇总工站列表${this.seqInstanceList}`);
    }

    static getInstance() {
        if (!flawFilter.instance) {
            flawFilter.instance = new flawFilter();
        }
        return flawFilter.instance;
    }

    // 处理flaw_filter的同步
    handleSyncToFlawFilter = async () => {
        try {
            // 1. 查询rtp_summary的flaw_filter表,根据 sync_db 与 sync_id 确定哪个数据库从哪儿开始同步
            let allFlawFilterUuidList = [];
            let syncFlawFilterList = [];

            for (const seqInfo of this.seqInstanceList) {
                let syncId = await this.getNewestSyncIdBySyncDb(seqInfo.name);
                // 2. 通过panel_table_uid 与 panel表uid的 建立左外连接
                let flawFilterInfo = await this.getFlawFilterInfoByJoinPanel(seqInfo.instance, syncId.length ? syncId[0].sync_id : 0);
                // console.log(flawFilterInfo);

                // 3. 判断每个panel_uuid是否存在（不存在就停止后续）
                if (flawFilterInfo.length == 0) continue;
                // if (!flawFilterInfo.every(item => !!item.panel_uuid)) continue;
                let lastPanelUidRes = await seqInfo.instance.query(`select uid from panel order by uid desc limit 1`, { type: seqInfo.instance.QueryTypes.SELECT })
                if (!flawFilterInfo.every(item => {
                    if (item.panelUid && item.panel_uuid) return true;
                    if (!item.panelUid && item.panel_table_uid < lastPanelUidRes[0].uid) {
                        console.log(`${seqInfo.name}库 的panel表缺少uid为${item.panel_table_uid}的数据`);
                        return true;
                    }
                    console.log(`看到这个log表示flaw_filter中的table_uid为${item.panel_table_uid}已经存在，但是panel信息还没同步过来`);
                    return false;
                })) continue;

                // 加入更新信息列表中
                flawFilterInfo.map(item => {
                    item.sync_db = seqInfo.name;
                    item.sync_id = item.id;
                    delete item.id;
                });
                syncFlawFilterList.push(...flawFilterInfo);
                const flawFilterUuidList = flawFilterInfo.map(item => item.panel_uuid);
                allFlawFilterUuidList.push(...flawFilterUuidList);

            }

            // 如果没有数据就return
            if (syncFlawFilterList.length == 0) return true;

            // 4. 通过panel_uuid去 rtp_summary库的panel_summary表中查询uid
            let allFlawFilterUuidSet = new Set(allFlawFilterUuidList);
            allFlawFilterUuidSet.delete(null);
            allFlawFilterUuidList = [...allFlawFilterUuidSet];
            // console.log(allFlawFilterUuidList);
            let panelUuidInfo = await this.getPanelSummaryUidByPanelUuid(allFlawFilterUuidList);
            // console.log(panelUuidInfo);
            // console.log(syncFlawFilterList);

            // 5. 将uid的值写入要更新的字段panel_table_uid中
            //     5.1 修改更新的数据和格式
            //      将panel_table_uid 替换、 删除panel_uuid 字段
            syncFlawFilterList.map(item => {
                item.panel_table_uid = panelUuidInfo[item.panel_uuid] || null;
                delete item.panel_uuid;
                delete item.panelUid;
            });
            // console.log(syncFlawFilterList);
            await flawFilterModel.FlawFilterMujian.uploadInfo(syncFlawFilterList);
            return true;
        } catch (error) {
            console.log(error);
            return false;
        }
    }

    // flaw_filter 与 panel 建立左外连接的信息
    getFlawFilterInfoByJoinPanel = async (seqInstance, syncId) => {
        let sql = 'SELECT id,flaw_filter.panel_id,panel_table_uid,flaw_class_type,station_id,`show`,flaw_filter.flaw_count,symbol,color,station_name,shape,panel_uuid, panel.uid as panelUid FROM flaw_filter LEFT JOIN panel ON flaw_filter.panel_table_uid = panel.uid WHERE id > ' + syncId + ' ORDER BY id LIMIT ' + this.syncFlawFilterConfig.syncLimit;
        let res = await seqInstance.query(sql, { type: seqInstance.QueryTypes.SELECT });
        return res;
    }

    // 根据panel_uuid获取rtp_summary数据库的 panel_summary表中的uuid
    getPanelSummaryUidByPanelUuid = async (flawFilterUuidList) => {
        if (!flawFilterUuidList.length) return {};
        // 处理语句格式变成 panel_id1,panel_id2,panel_id3,......
        const uuidIn = flawFilterUuidList.length > 1 ? flawFilterUuidList.reduce((acc, cur, idx) => idx == 1 ? "'" + acc + "','" + cur + "'" : acc + ",'" + cur + "'") : `'${flawFilterUuidList[0] || ''}'`;
        let res = await seqRtpSummary.query(`select uid,panel_uuid from panel_summary where panel_uuid in (${uuidIn})`, { type: seqRtpSummary.QueryTypes.SELECT });
        let rtn = {};
        res.forEach(item => {
            rtn[item.panel_uuid] = item.uid;
        });
        return rtn;
    }

    // 查询flaw_filter 中某个sync_db的最新的sync_id
    getNewestSyncIdBySyncDb = async (syncDb) => {
        let res = await seqRtpSummary.query(`SELECT sync_id FROM flaw_filter WHERE sync_db = '${syncDb}' ORDER BY id DESC LIMIT 1`, { type: seqRtpSummary.QueryTypes.SELECT });
        return res;
    }
}

module.exports = flawFilter.getInstance();