const queue = require('queue');
const { v1 } = require('uuid');

const { line_db, is_open_summary } = require('../../config.json');
const seqSummary = require('../../lib/db').getSequelizeInstance(line_db.linedb_summary_config);
const Summary = require('./summary');
const { xlog, path } = require('xlog');
const logger = new xlog({
    projectName: 'rtp_line_et',
    filePath: path.join(__dirname, '../../logs'),
    category: ['summary', 'handuuId'],
    logsName: 'handle_uuid',
    logging: true
});

class handleUuid {
    constructor() {
        // 日志分级
        this.logger = logger;
        // 要做队列
        this.execQueue = queue({ concurrency: 1, autostart: true });
    }

    // 单例
    static getInstance() {
        if (!handleUuid.instance) {
            handleUuid.instance = new handleUuid();
        }
        return handleUuid.instance;
    }

    // 添加队列
    addQueue = async (seqInstance, pId, stationName, panelAllInfo) => {
        try {
            if (!(typeof pId == 'string') || !(pId.constructor == String)) {
                logger.info('pId 不是字符串');
                return false;
            }
            // TODO: 汇总的开关,不需要汇总的时候就直接返回以结束
            if (!is_open_summary) return;

            await seqInstance.authenticate();
            this.execQueue.push(
                async (cb) => {
                    const uuid = await this.handleUuid(seqInstance, pId);
                    if (uuid) {
                        // 处理汇总信息
                        await Summary.handPanelSummary(uuid, panelAllInfo, stationName);
                        logger.info(`pId为${pId}的片处理成功!`);
                    }
                    // logger.info(`此片无uuid，有问题，呼叫管理员`);
                    cb();
                }
            );
            logger.info(`${stationName} 工站的${pId}片发送给生成uuid队列!`);
            return true;
        } catch (error) {
            logger.err(error);
            return false;
        }
    }

    // 主函数用来处理uuid
    /**
     * 
     * @param {*} seqInstance 
     * @param {*} params 
     * @returns Boolean
     */
    /**
     * 用pId查询rtp_summary数据库的panel_summary表
     * 
     * 1. panel_summary表无pId
     *      a: 生成uuid
     *      b: panel_summary 插入 panel_id, panel_uuid
     *      c: 机台的panel表 对应的pId更新panel_uuid(更新的是最老的那个没有uuid的)
     * 2. panel_summary表有pId
     *      a: panel_summary表取出uuid
     *      b: 机台的panel表 对应的pId 是否有uuid
     *          b.1 机台有uuid
     *              b.1.1 生成uuid
     *              b.1.2 panel_summary 插入 panel_id, panel_uuid
     *              b.1.3 机台的panel表 对应的pId更新panel_uuid(这边对应的可能有多个，应该更新的是最老的那个没有uuid的也就是有uuid的下一个)
     *          b.2 机台没有uuid
     *              b.2.1 更新机台，但是更新哪个？
     *                    找机台上最后一个对应pId的有uuid的，
     *                    取出uuid，
     *                    对应到rtp_summary数据库的panel_summary表的uuid，
     *                    取rtp_summary数据库的panel_summary表pid对应的下一个uuid
     *                    更新机台panel表的是最老的那个没有uuid的
     */
    handleUuid = async (seqInstance, params) => {
        try {
            // if (Math.random() < 0.3) throw new Error('模拟发生错误');
            // 防错，先看一下当前机台是否真的有没有uuid的panel
            let hasEmptyUuidRes = await seqInstance.query(`select uid from panel where panel_id='${params}' and (panel_uuid is null or panel_uuid='') order by uid limit 1`, { type: seqSummary.QueryTypes.SELECT });
            if (hasEmptyUuidRes.length == 0) {
                logger.info(`当前机台pid为${params}都有uuid，没必要生成`);
                return false;
            }

            // 1. 用pId查询rtp_summary数据库的panel_summary表
            let pIdRes = await seqSummary.query(`select uid,panel_id,panel_uuid from panel_summary where panel_id='${params}'`, { type: seqSummary.QueryTypes.SELECT });

            // panel_summary表无pId
            if (pIdRes.length == 0) {
                logger.info('panel_summary表无pId');
                return await this.generateUuid(seqInstance, params);
            } else {
                // panel_summary表有pId
                // 看机台是否有最新的uuid
                let newEstUuid = pIdRes[pIdRes.length - 1].panel_uuid;
                let panelUuidRes = await seqInstance.query(`select uid from panel where panel_uuid='${newEstUuid}'`, { type: seqSummary.QueryTypes.SELECT });
                // 机台有最新的uuid
                if (panelUuidRes.length > 0) {
                    logger.info('机台有最新的uuid');
                    return await this.generateUuid(seqInstance, params);
                } else {
                    logger.info('机台没有最新的uuid');
                    // 机台没有最新的uuid
                    // 更新机台
                    // 1.找机台上最后一个对应pId的有uuid的
                    let lastOneUuidRes = await seqInstance.query(`select uid,panel_uuid from panel where panel_id='${params}' and (panel_uuid is not null and panel_uuid!='') order by uid limit 1`, { type: seqSummary.QueryTypes.SELECT });
                    // 2.取出uuid
                    let lastOneUuid;
                    let nextOneUuid = newEstUuid;
                    // 3.对应到rtp_summary数据库的panel_summary表的uuid
                    // 4.取rtp_summary数据库的panel_summary表pid对应的下一个uuid
                    if (lastOneUuidRes.length > 1) {
                        lastOneUuid = lastOneUuidRes[0].panel_uuid;
                        for (let i = 0; i < pIdRes.length; i++) {
                            if (pIdRes[i].panel_uuid == lastOneUuid) {
                                nextOneUuid = pIdRes[i + 1].panel_uuid;
                                break;
                            }
                        }
                    }
                    logger.info('更新的uuid为：' + nextOneUuid);
                    // 5.更新机台panel表的是最老的那个没有uuid的
                    let lastOneUid = lastOneUuidRes.length > 0 ? lastOneUuidRes[0].uid : 0;
                    let updatePanelUuidRes = await seqInstance.query(`update panel set panel_uuid='${nextOneUuid}' where uid>${lastOneUid} and panel_id='${params}' and (panel_uuid is null or panel_uuid='') order by uid limit 1`, { type: seqSummary.QueryTypes.UPDATE });
                    logger.info(updatePanelUuidRes);
                    return nextOneUuid;
                }
            }
        } catch (error) {
            logger.err(error);
            return false;
        }
    }
    /**
     * 生成panel 的 uuid
     * @param {seq} seqInstance 
     * @param {*} params 
     * @returns uuid
     */
    generateUuid = async (seqInstance, params) => {
        // 生成uuid
        let uuid = v1().replace(/-/g, '');
        // panel_summary 插入 panel_id, panel_uuid
        logger.info('panel_summary 插入新生成的uuid');
        let insertUuidInSummaryRes = await seqSummary.query(`insert into panel_summary(panel_id,panel_uuid) values('${params}','${uuid}')`);
        logger.info(insertUuidInSummaryRes);
        // 机台的panel表 对应的pId更新panel_uuid(更新的是最老的那个没有uuid的)
        logger.info('机台更新 新生成的uuid');
        let updatePanelUuidRes = await seqInstance.query(`update panel set panel_uuid='${uuid}' where panel_id='${params}' and (panel_uuid is null or panel_uuid='') order by uid limit 1`, { type: seqSummary.QueryTypes.UPDATE });
        logger.info(updatePanelUuidRes);
        return uuid
    }
}

module.exports = handleUuid.getInstance();