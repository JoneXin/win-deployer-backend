'use strict'
const Cleanning = require('./job/cleanning');

const run = () => {
    Cleanning.getInstance();
}

run();



