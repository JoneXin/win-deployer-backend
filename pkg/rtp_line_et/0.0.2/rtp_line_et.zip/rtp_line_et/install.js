
const axios = require('axios')
const path = require('path');
const fs = require('fs-extra');
let logPath = path.join(__dirname, '../log');
fs.ensureDirSync(logPath);

async function go() {
    let seriptList = [
        {
            "script": path.join(__dirname, './index.js'),
            "cwd": path.join(__dirname, './'),
            "name": "rtp_line_et",
            "log_date_format": "YYYY-MM-DD HH:mm Z"
        }
    ]
    for (let i = 0; i < seriptList.length; i++) {
        const item = seriptList[i];
        await axios.post('http://127.0.0.1:8172/pm2server/cmd', {
            cmd: "stop",
            param: item
        }).catch(function (error) {
            console.log(error);
        });
        await axios.post('http://127.0.0.1:8172/pm2server/cmd', {
            cmd: "start",
            param: item
        }).catch(function (error) {
            console.log(error);
        });
    }
}

go();
