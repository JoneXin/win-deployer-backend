/**
 * @file {cf精度检测目标库panel表model}
 */
'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const { line_db } = require('../../config.json');
const seqCfAim = require('../../lib/db').getSequelizeInstance(line_db.linedb_cf_jingdujiance_config);
class PanelCfJingdu extends Model { }
const { panelJingduInitData } = require('../common/init_data');

PanelCfJingdu.init(
    {
        ...panelJingduInitData[0],
        checked: {
            field: 'checked',
            type: DataTypes.INTEGER
        },
        // 增加同步字段
        ex_info: {
            field: 'ex_info',
            type: DataTypes.TEXT
        },

    },
    {
        freezeTableName: true,
        sequelize: seqCfAim,
        modelName: 'panel',
        timestamps: false
    }
)

PanelCfJingdu.getNewsSyncPanel = async () => {
    let res = await seqCfAim.query(`select max(uid) as uid from panel`, { type: seqCfAim.QueryTypes.SELECT });
    return res[0].uid ? res[0].uid : 1
}


// 从原库同步数据到中间库，需要开通哪些更新的字段
PanelCfJingdu.upload = async (data) => {
    // 精度检测导出新增11个字段，从原库读取这11个字段，存放在中间库的ex_info字段中同步过来，所以下面要更新的字段需要添加一个"ex_info"
    let res = await PanelCfJingdu.bulkCreate([data], {
        updateOnDuplicate:
            ['uid', 'panelId', 'genTime', 'genTimeStr', 'isOk', 'savePath', 'ltX', 'ltY', 'rtY', 'rtX', 'lbX', 'lbY', 'rbY', 'rbX', 'ex_info'],
    });
    return res;
}

module.exports = { PanelCfJingdu, seqCfAim };