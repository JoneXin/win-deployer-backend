/**
 * @file {cf精度检测目标库panel表model}
 */
'use strict'

const { Model } = require('sequelize');
const { station_db, jingdu_table_name } = require('../../config.json');
const seqTftSource = require('../../lib/db').getSequelizeInstance(station_db.tft_jingdu_db_config);
// const { panelJingduInitData } = require('../common/init_data');
class PanelSourceTftJingdu extends Model { }

// PanelSourceTftJingdu.init(
//     ...panelJingduInitData,
//     {
//         freezeTableName: true,
//         sequelize: seqTftSource,
//         modelName: jingdu_table_name,
//         timestamps: false
//     }
// )

// // 通过uid 获取panel信息
// PanelSourceTftJingdu.getPanelInfoByUid = async (uid) => {
//     // console.log(uid, '--');
//     const res = await PanelSourceTftJingdu.findOne({
//         where: {
//             uid
//         }
//     });
//     return res;
// }

// // 查询源库最新的同步位置
// PanelSourceTftJingdu.getMaxUidFromSource = async () => {
//     const res = await PanelSourceTftJingdu.findOne({
//         attributes: [seqTftSource.fn('max', seqTftSource.col('uid'))]
//     });
//     return res['max(`uid`)'];
// }

// 因为精度检的原库改变，所以改为原生查询

PanelSourceTftJingdu.getPanelInfoByUid = async (uid) => {
    const res = await seqTftSource.query(`select * from  panel where uid = ${uid} limit 1`, { type: seqTftSource.QueryTypes.SELECT })
    return res[0];
}

// 查询源库最新的同步位置
PanelSourceTftJingdu.getMaxUidFromSource = async () => {
    const res = await seqTftSource.query(`select * from panel ORDER BY uid DESC limit 1`, { type: seqTftSource.QueryTypes.SELECT });
    return res[0] && res[0].uid;
}
module.exports = { PanelSourceTftJingdu, seqTftSource };