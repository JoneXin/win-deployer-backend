'use strict';
const { formatDate } = require('../../../uitls/tool');

// 获取目标库的最大flaw的max(uid)
const getLatestFlawId = async sequelize_aim => {
    let res = await sequelize_aim.query('select max(uid) as uid from flaw', { type: sequelize_aim.QueryTypes.SELECT });
    return res[0].uid;
};

/**
 * 获取panel_id对应flaw信息array || 获取一个uid区间的缺陷array
 * @param {*} sequelize_source
 * @param {String | Number} queryStr panelID | panel_info -> uid
 * @returns {Array} panel_id对应flaw信息array || uid区间的缺陷array
 */
const getFlawData = async (sequelize_source, queryStr, stationName) => {

    if (typeof queryStr == 'string') {
        let res_panel = await sequelize_source.query(`select uid from panel_info where panel_id = '${queryStr}' order by create_time desc limit 1`, { type: sequelize_source.QueryTypes.SELECT });
        queryStr = res_panel.length ? res_panel[0].uid : 1;
    }

    let res_flaw = await sequelize_source.query(`select uid, jobId as job_id, dCD as center_pos_cd, dMD as center_pos_md, dLength as length_md, 
    dWidth as length_cd, flawClassType as flaw_class_type, createTime as gen_time, cameraId as camera_id, dArea as area, content as save_path, 
    dDiameter as diameter, exField, station from flaw where doffId = (select doff_id from panel_info where uid = ${queryStr})`, { type: sequelize_source.QueryTypes.SELECT });

    let res_panel = await sequelize_source.query(`select panel_id, lot_id from panel_info where uid = ${queryStr}`, { type: sequelize_source.QueryTypes.SELECT });
    if (res_flaw.length && res_panel.length) {
        return res_flaw.map(item => {
            let ex_info = JSON.parse(item.exField)
            if(!ex_info.flaw) ex_info.flaw ={}
            ex_info.flaw.station = item.station
            return {
                ...item,
                panel_id: res_panel[0].panel_id,
                lot_id: res_panel[0].lot_id,
                gen_time_str: formatDate(item.gen_time),
                center_pos_md: Number(item.center_pos_md),
                center_pos_cd: Number(item.center_pos_cd),
                // TODO flaw_class_type: Number(item.flaw_class_type),
                flaw_class_type: item.flaw_class_type + '__' + stationName,
                panel_table_uid: queryStr,
                ex_info: JSON.stringify({
                    ex_field: ex_info
                })
            }
        });
    } else {
        return [];
    }
};

// 上传到目标库
const uploadPolInfo = async (FlawPiantie, data) => {
    let res = await FlawPiantie.bulkCreate(data, { updateOnDuplicate: ['uid',] });
    return res;
};

module.exports = {
    getLatestFlawId,
    getFlawData,
    uploadPolInfo,
};
