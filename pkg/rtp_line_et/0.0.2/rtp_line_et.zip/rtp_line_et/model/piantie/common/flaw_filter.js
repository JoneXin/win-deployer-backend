'use strict';

// 获取目标库flaw_filter的最大panel_id
const getMaxPanelIdFromFlawFilter = async sequelize_aim => {
    let res = await sequelize_aim.query('select max(panel_table_uid) as id from flaw_filter', { type: sequelize_aim.QueryTypes.SELECT });
    console.log(res, '=====');
    return res[0].id ? res[0].id : 1;
};

/**
 * 查询目标库flaw表的panel_tabel_uid对应第一个缺陷的uid || 查询目标库的flaw_filter表的max(uid)
 * @param {*} sequelize_aim
 * @param {number} flawFilterUid panel_tabel_uid的值
 * @returns panel_tabel_uid对应第一个缺陷的uid || flaw_filter表的max(uid)
 */
const getLatestFlawFilterId = async (sequelize_aim, flawFilterUid) => {
    let sql = null;
    // 第一次进的时候，这里FlawFIlter 也对应更新上一次可能没同步完的数据
    if (flawFilterUid) {
        let res = await sequelize_aim.query(`select min(id) as id from flaw_filter where panel_table_uid = ${flawFilterUid}`, { type: sequelize_aim.QueryTypes.SELECT });
        return res.length ? res[0].id - 1 : 0;
    } else {
        let res = await sequelize_aim.query('select max(id) as id from flaw_filter', { type: sequelize_aim.QueryTypes.SELECT });
        return res.length ? res[0].id : 0;
    }
};

// 查询源库的doff表max(uid)
const getMaxPanelUid = async sequelize_source => {
    let res = await sequelize_source.query('select max(uid) as uid from panel_info', { type: sequelize_source.QueryTypes.SELECT });
    return res.length ? res[0].uid : 0;
};

/**
 * 查询源库panel_id对应的缺陷分类的信息 || 查询源库panel_id对应的缺陷分类的信息
 * @param {*} sequelize_source
 * @param {String | Number} queryStr panel_id | uid(panel_info)
 * @returns {Array} panel_id对应的缺陷分类array || panel_id对应的缺陷分类array
 */
const getFlawCountByPanel = async (sequelize_source, queryStr) => {
    if (typeof queryStr == 'string') {
        let res_panel = await sequelize_source.query(`select uid from panel_info where panel_id = "${queryStr}" order by uid desc limit 1`, { type: sequelize_source.QueryTypes.SELECT, });
        queryStr = res_panel.length ? res_panel[0].uid : 1;
    }
    let res_flaw = await sequelize_source.query(`select flawClassType as flaw_class_type, station as station_name, cameraId as station_id from flaw where doffId = (select doff_id from panel_info where uid = ${queryStr})`, { type: sequelize_source.QueryTypes.SELECT, });
    // let res_doff = await sequelize_source.query(`select uid from doff where uid = ${queryStr}`, { type: sequelize_source.QueryTypes.SELECT, });
    let res_panel = await sequelize_source.query(`select panel_id, uid  from panel_info where uid = ${queryStr}`, { type: sequelize_source.QueryTypes.SELECT, });
    if (res_flaw.length && res_panel.length) {
        return res_flaw.map(item => {
            return {
                ...item,
                panel_table_uid: res_panel[0].uid,
                panel_id: res_panel[0].panel_id
            }
        })
    } else {
        return [];
    }
};

// 查询源库的detectParam 获取缺陷全集信息
const getFlawFilterInfoByDoffUid = async (sequelize_source, queryStr) => {
    if (typeof queryStr == 'string') {
        let res_uid = await sequelize_source.query(`select uid from panel_info where panel_id = "${queryStr}" order by uid desc limit 1`, { type: sequelize_source.QueryTypes.SELECT, });
        queryStr = res_uid.length ? res_uid[0].uid : 1;
    }
    let res_doff = await sequelize_source.query(`select comment as detectParam from job where job.uid = (select doff.jobId from doff where uid = (select doff_id from panel_info where uid = ${queryStr}))`, { type: sequelize_source.QueryTypes.SELECT, });

    return res_doff.length ? res_doff[0].detectParam : '';
};

// 上传缺陷分类到目标库
const uploadPolInfo = async (FlawFilterPiantie, data) => {
    let res = await FlawFilterPiantie.bulkCreate(data, { updateOnDuplicate: ['panel_id', 'panel_table_uid', 'flaw_class_type', 'show', 'flaw_count', 'symbol', 'color', 'station_id', 'station_name', 'shape'], });
    return res;
};

module.exports = {
    getMaxPanelIdFromFlawFilter,
    getLatestFlawFilterId,
    getMaxPanelUid,
    getFlawCountByPanel,
    getFlawFilterInfoByDoffUid,
    uploadPolInfo
};
