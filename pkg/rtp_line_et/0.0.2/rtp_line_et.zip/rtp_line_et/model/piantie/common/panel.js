'use strict'

// 获取源库panel_info表的max(uid)
const getLatestPanelFromSource = async (sequelize_source, uid) => {
    let sql = uid ? 'select max(uid) as uid from panel_info' : 'select panel_id from panel_info where uid = (select max(uid) from panel_info)';
    let res = await sequelize_source.query(sql, { type: sequelize_source.QueryTypes.SELECT });
    if (res.length && uid) {
        return res[0].uid;
    } else if (res[0] && !uid) {
        return res[0].panel_id;
    } else {
        return null;
    }
}

// 查询目标库panel表的max(uid)
const getLatestPanelId = async (sequelize_aim) => {
    let res = await sequelize_aim.query('select max(uid) as uid from panel', { type: sequelize_aim.QueryTypes.SELECT });
    return res[0].uid ? res[0].uid : 1;
}

/**
 * 获取源库的对应pabelID的panel信息 || 获取源库 panel_info -> uid 对应的panel片的信息
 * @param {*} sequelize_source
 * @param {String | Number} queryStr panelID | uid
 * @returns {Object} panel信息
 */
const findLatestPanelInfo = async (sequelize_source, queryStr) => {
    let query = typeof (queryStr) == 'string' ? `b.panel_id = "${queryStr}"` : `b.uid = ${queryStr}`;
    let res = await sequelize_source.query(`select a.jobId as job_id, b.panel_id, a.flawCount as flaw_count, a.exConfig1, a.startTime as gen_time, a.comment as save_path, 
    b.lot_id, b.uid, b.meter, b.ex_info1, c.comment as detectParam from doff a inner join panel_info b on a.uid = b.doff_id inner join job c on a.jobId = c.uid where ${query}`, { type: sequelize_source.QueryTypes.SELECT });
    return res[0];
}


const uploadPolInfo = async (PanelPiantie, data) => {
    let res = await PanelPiantie.bulkCreate([data], { updateOnDuplicate: ['uid', 'job_id', 'panel_id', 'flaw_count', 'is_ok', 'length_md', 'length_cd', 'save_path', 'gen_time', 'gen_time_str', 'detectParam', 'checked'] });
    return res;
}
module.exports = {
    getLatestPanelFromSource,
    getLatestPanelId,
    findLatestPanelInfo,
    uploadPolInfo
};
