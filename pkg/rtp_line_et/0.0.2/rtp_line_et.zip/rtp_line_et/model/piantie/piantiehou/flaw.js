'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {flawInitData} = require('../../common/init_data');
class FlawPiantiehou extends Model { }
const {
    getLatestFlawId,
    getFlawData,
    uploadPolInfo
} = require('../common/flaw');

const initPiantiehouFlawData = (sequelize_aim) => {
FlawPiantiehou.init(
    ...flawInitData,
    {
        freezeTableName: true,
        sequelize: sequelize_aim,
        modelName: 'flaw',
        timestamps: false
    }
    )
}
FlawPiantiehou.getLatestFlawId = getLatestFlawId;
FlawPiantiehou.getFlawData = getFlawData;
FlawPiantiehou.uploadPolInfo = uploadPolInfo;

module.exports = {
    FlawPiantiehou,
    initPiantiehouFlawData
};