'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {flawFilterInitData} = require('../../common/init_data');
class FlawFilterPiantiehou extends Model { }
const {
    getMaxPanelIdFromFlawFilter,
    getLatestFlawFilterId,
    getMaxPanelUid,
    getFlawCountByPanel,
    getFlawFilterInfoByDoffUid,
    uploadPolInfo
} = require('../common/flaw_filter');
/**
 * @desc 映射需要的字段 【源库的 部分字段 --> 目标库字段】
 */
const initPiantiehouFlawFilterData = (sequelize_aim) => {
FlawFilterPiantiehou.init(
        ...flawFilterInitData,
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'flaw_filter',
            timestamps: false
        }
)
}
FlawFilterPiantiehou.getMaxPanelIdFromFlawFilter = getMaxPanelIdFromFlawFilter;
FlawFilterPiantiehou.getLatestFlawFilterId = getLatestFlawFilterId;
FlawFilterPiantiehou.getMaxPanelUid = getMaxPanelUid;
FlawFilterPiantiehou.getFlawCountByPanel = getFlawCountByPanel;
FlawFilterPiantiehou.getFlawFilterInfoByDoffUid = getFlawFilterInfoByDoffUid;
FlawFilterPiantiehou.uploadPolInfo = uploadPolInfo;

module.exports = {
    initPiantiehouFlawFilterData,
    FlawFilterPiantiehou
};