'use strict'

const { Model } = require('sequelize');
const { panelInitData } = require('../../common/init_data');
const {
    getLatestPanelFromSource,
    getLatestPanelId,
    findLatestPanelInfo,
    uploadPolInfo
} = require('../common/panel');
const { reWriteOtherChecked } = require('../../common/rewirte_check');
class PanelPiantiehou extends Model { }

const initPiantiehouPanelData = (sequelize_aim) => {
    PanelPiantiehou.init(
        ...panelInitData, {
        freezeTableName: true,
        sequelize: sequelize_aim,
        modelName: 'panel',
        timestamps: false
    }
    )
}

PanelPiantiehou.getLatestPanelFromSource = getLatestPanelFromSource;
PanelPiantiehou.getLatestPanelId = getLatestPanelId;
PanelPiantiehou.findLatestPanelInfo = findLatestPanelInfo;
PanelPiantiehou.uploadPolInfo = uploadPolInfo;
PanelPiantiehou.reWriteChecked = reWriteOtherChecked;
module.exports = {
    PanelPiantiehou,
    initPiantiehouPanelData
};