/**
 * @file {cf_pol目标库flaw表model}
 */
'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const { jobInitData } = require('../../common/init_data');
class JobCfPol extends Model { }
const {
    getMaxUidfromSourceJob,
    getLatestJobId,
    getJobInfoByPanelId,
    uploadPolInfo,
    getPanelExistJobInfo
} = require('../common/job');

const initCfPolJobData = (sequelize_aim) => {
    JobCfPol.init(
        ...jobInitData,
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'job',
            timestamps: false
        }
    )
}

JobCfPol.getMaxUidfromSourceJob = getMaxUidfromSourceJob;
JobCfPol.getLatestJobId = getLatestJobId;
JobCfPol.getJobInfoByPanelId = getJobInfoByPanelId;
JobCfPol.uploadPolInfo = uploadPolInfo;
JobCfPol.getPanelExistJobInfo = getPanelExistJobInfo;
module.exports = {
    JobCfPol,
    initCfPolJobData
};