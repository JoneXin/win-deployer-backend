'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {flawFilterInitData} = require('../../common/init_data');
class FlawFilterTftPol extends Model {}
const {
    getMaxPanelUid,
    getNewsFlawFilterInfoFromLineDb,
    getLatestFlawFilterId,
    getMaxPanelIdFromFlawFilter,
    getFlawFilterInfoByPanelId,
    uploadPolInfo,
    getAllFlawType
} = require('../common/flaw_filter');

const initTftPolFlawFilterData = (sequelize_aim) => {
    FlawFilterTftPol.init(
        ...flawFilterInitData,
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'flaw_filter',
            timestamps: false
        }
    )
}
FlawFilterTftPol.getMaxPanelUid = getMaxPanelUid;
FlawFilterTftPol.getNewsFlawFilterInfoFromLineDb = getNewsFlawFilterInfoFromLineDb;
FlawFilterTftPol.getLatestFlawFilterId = getLatestFlawFilterId;
FlawFilterTftPol.getMaxPanelIdFromFlawFilter = getMaxPanelIdFromFlawFilter;
FlawFilterTftPol.getFlawFilterInfoByPanelId = getFlawFilterInfoByPanelId;
FlawFilterTftPol.uploadPolInfo = uploadPolInfo;
FlawFilterTftPol.getAllFlawType = getAllFlawType;

module.exports = {
    initTftPolFlawFilterData,
    FlawFilterTftPol
};