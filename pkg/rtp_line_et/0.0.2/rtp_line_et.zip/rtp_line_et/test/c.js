let a= {
    'ad尿素': 1
}

console.log(a['ad尿素']);