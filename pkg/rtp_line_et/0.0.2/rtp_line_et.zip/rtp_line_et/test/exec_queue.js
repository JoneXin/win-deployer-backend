let testQueue = require('./test_queue');

setTimeout(() => {
    testQueue.addQueue(1);
    testQueue.addQueue(2);
}, 2000);
setTimeout(() => {
    testQueue.addQueue(3);
    testQueue.addQueue(4);
}, 4000);
setTimeout(() => {
    testQueue.addQueue(5);
    testQueue.addQueue(6);
}, 6000);
setTimeout(() => {
    testQueue.addQueue(7);
    testQueue.addQueue(8);
}, 8000);