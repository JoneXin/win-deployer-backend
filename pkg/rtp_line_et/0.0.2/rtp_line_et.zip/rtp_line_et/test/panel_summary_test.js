const handlePanelSummary = require('../class/summary/panel_summary');
(async () => {
    setInterval(async () => {
        const res = await handlePanelSummary.handleSyncToPanelSummary();
        console.log(res);
    }, 5000);
    // const res = await handlePanelSummary.handleSyncToPanelSummary();
    // console.log(res);
})()
