
const {FlawMujian, initFlawMujinaData} = require('../model/summary/flaw');
const { linedb_summary_config } = require('../config.json').line_db;
const seqRtpSummary = require('../lib/db').getSequelizeInstance(linedb_summary_config);
initFlawMujinaData(seqRtpSummary);

FlawMujian.uploadInfo([
    {
        uid: 1,
        center_pos_md: 200
    }
])