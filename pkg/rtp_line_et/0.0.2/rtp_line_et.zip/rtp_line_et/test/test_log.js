const xinLog = require('../lib/x_log');

let logger = new xinLog('a.js');
let a = 'ssadasdaa'
logger.info('转回转给你');
logger.err(`---${a}`);