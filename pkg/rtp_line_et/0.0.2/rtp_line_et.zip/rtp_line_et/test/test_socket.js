
const { initSocket } = require('../lib/socket');
const emiter = initSocket(); //PLC

console.log(emiter.length);
// 所有PLC的监听
emiter.forEach(emiters => {

    emiters.on('plc', data => {
        console.log(data, '------');
    })
})