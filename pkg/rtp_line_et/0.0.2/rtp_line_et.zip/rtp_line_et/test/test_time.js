const schedule = require('node-schedule');


let job = schedule.scheduleJob('*/4 * * * * *', () => {
    this.timer1 && clearTimeout(this.timer1);
    this.tmmer1 = setTimeout(() => {
        console.log(1);
    }, 1000)
    this.timer2 && clearTimeout(this.timer1);
    this.tmmer2 = setTimeout(() => {
        console.log(2);
    }, 2000)
    this.timer3 && clearTimeout(this.timer1);
    this.tmmer3 = setTimeout(() => {
        console.log(3);
    }, 3000)
    this.timer4 && clearTimeout(this.timer1);
    this.tmmer4 = setTimeout(() => {
        console.log(4);
    }, 4000)
});