-- rtp_piantiehou
TRUNCATE Table rtp_piantiehou.flaw;
TRUNCATE Table rtp_piantiehou.flaw_filter;
TRUNCATE Table rtp_piantiehou.job;
TRUNCATE Table rtp_piantiehou.panel;
-- rtp_piantieqian
TRUNCATE Table rtp_piantieqian.flaw;
TRUNCATE Table rtp_piantieqian.flaw_filter;
TRUNCATE Table rtp_piantieqian.job;
TRUNCATE Table rtp_piantieqian.panel;
-- rtp_cf_pol
TRUNCATE Table rtp_cf_pol.flaw;
TRUNCATE Table rtp_cf_pol.flaw_filter;
TRUNCATE Table rtp_cf_pol.job;
TRUNCATE Table rtp_cf_pol.panel;
-- rtp_tft_pol
TRUNCATE Table rtp_tft_pol.flaw;
TRUNCATE Table rtp_tft_pol.flaw_filter;
TRUNCATE Table rtp_tft_pol.job;
TRUNCATE Table rtp_tft_pol.panel;
-- rtp_tft_pol
TRUNCATE Table rtp_summary.flaw;
TRUNCATE Table rtp_summary.flaw_filter;
TRUNCATE Table rtp_summary.panel_summary;
TRUNCATE Table rtp_cf_jingdujiance.panel;
TRUNCATE Table rtp_tft_jingdujiance.panel;