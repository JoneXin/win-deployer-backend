
'use strict'

const { plc_max_connections } = require('../config.json')

// 心跳消息
const HEART_MESSAGE = JSON.stringify({
    cmd: 'heart',
    content: {
        "desc": "服务端在线!"
    }
})

// 收到devicePort 回复
const PORT_MESSAGE = JSON.stringify({
    cmd: 'reply',
    content: {
        desc: "收到port端口信息!"
    }
})

const ERR_PORT_MESSAGE = JSON.stringify({
    cmd: 'reply',
    content: {
        desc: "devicePort输入错误,请与PLC端口保持一致!"
    }
})

// 不规范请求格式回复
const ERR_MESSAGE = JSON.stringify({
    cmd: 'reply',
    content: {
        desc: "请发送正确的数据格式!"
    }
})

// 连接超出额消息
const CAPCITY_FULL = JSON.stringify({
    cmd: 'reply',
    content: {
        desc: `连接数已超过${plc_max_connections}`
    }
})

module.exports = {
    PLC_SOCKET_KEY: '500000FF03FF000018001004010000D*020100001B',
    HEART_MESSAGE,
    PORT_MESSAGE,
    ERR_MESSAGE,
    CAPCITY_FULL,
    ERR_PORT_MESSAGE
}