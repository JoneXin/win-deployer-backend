'use strict';

const schedule = require('node-schedule');
const { transformData, formatFlawFilterData, formatDate } = require('../../uitls/tool');
const Tools = require('../../uitls/tools');
let handleUuid = require('../summary/handle_uuid');
const queue = require('queue');
const {piantie_precision} = require('../../config.json');

class PiantieBase {
    constructor(tableModel, sequelize_source, sequelize_aim, stationInfo, logger, startPosition, sourceIp, rotateConf) {
        this.PanelPiantie = tableModel.PanelPiantieqian || tableModel.PanelPiantiehou;
        this.FlawFilterPiantie = tableModel.FlawFilterPiantieqian || tableModel.FlawFilterPiantiehou;
        this.FlawPiantie = tableModel.FlawPiantieqian || tableModel.FlawPiantiehou;
        this.JobPiantie = tableModel.JobPiantieqian || tableModel.JobPiantiehou;
        this.logger = logger;

        this.sequelize_source = sequelize_source;
        this.sequelize_aim = sequelize_aim;
        this.stationName = stationInfo.station_name_standard;
        this.stationInfo = stationInfo;
        this.flawFilterDataArr = [];
        this.flawFilterDataArr1 = [];
        this.uploadPanelTimes = 0;
        this.uploadPanelTimes_flawFilter = 0;
        //源库的最大片uid
        this.sourceDoffMaxUid = 0;
        // 统计次数
        this.accountIndex = 0;
        // 当前片
        this.currentPanel = null;
        // 当前的缺陷分类
        this.currentFlawFilterArr = [];

        this.taskQueue_panel = queue({ concurrency: 1, autostart: true });
        this.taskQueue_flawFilter = queue({ concurrency: 1, autostart: true });
        this.taskQueue_job = queue({ concurrency: 1, autostart: true });
        this.timeDelay = '*/2 * * * * *';
        this.startPosition = startPosition;
        this.sourceIp = sourceIp;
        this.rotateConf = rotateConf;

        this.init();
    }
    // 初始化
    async init() {
        // 查询当前同步的位置
        await this.getSyncPosition();

        // 开始定时缓存任务
        this.pieantieJob = schedule.scheduleJob(this.timeDelay, () => {
            this.addTaskQueue();
        });
    }

    // push task queue
    addTaskQueue() {
        // panel,flaw, flaw_filter
        this.taskQueue_panel.push(async cb => {
            await this.handPanelInfo();
            cb();
        })
        // job 同步
        this.taskQueue_job.push(async cb => {
            await this.handJobInfo();
            cb();
        })
    }
    /**
     * 获取当各表同步的位置
     */
    async getSyncPosition() {
        try {
            // panel 同步起点 以源库panel_info uid为准
            this.panelUid = await this.PanelPiantie.getLatestPanelId(this.sequelize_aim);
            if (this.panelUid == 1) {
                this.panelUid = this.startPosition.panelUid;
            }
            // job 同步起点 以源库job uid为准
            this.jobUid = await this.JobPiantie.getLatestJobId(this.sequelize_aim);
            if (this.jobUid == 1) {
                this.jobUid = this.startPosition.jobUid;
            }
            // 缺陷分类的最新同步的uid
            this.FlawFilterId = await this.FlawFilterPiantie.getLatestFlawFilterId(this.sequelize_aim, this.panelUid);
            // 缺陷分类的id与panelUid保持一致
            this.currentFlawFilterId = this.panelUid;
        } catch (_) {
            this.logger.err(_);
        }
    }
    /**
     * 查询某片的缺陷，并转成具有父子关系的缺陷数组
     * @param {panelId} panelId
     * @returns 具有父子关系的缺陷分类数组
     */
    async transformFlawFilteDataToDetectParam(panelId) {
        try {

            // 查询缺陷类型全集
            let res = await this.FlawFilterPiantie.getFlawFilterInfoByDoffUid(this.sequelize_source, panelId);
            let flawTypeObj = JSON.parse(res || JSON.stringify({}));
            // 把缺陷归类--存到this.flawFilterDataArr
            this.handTranformData(flawTypeObj, true);
            this.handTranformData(flawTypeObj, false);
            // 查询缺陷
            let flawFilterCountArr = await this.FlawFilterPiantie.getFlawCountByPanel(this.sequelize_source, panelId);
            const resultDataObj = {}; // 记录已经存储了那些缺陷
            // this.logger.info(JSON.stringify(flawFilterCountArr) + '---+++---');
            if (flawFilterCountArr.length) {
                // 转成有flaw_count的缺陷分类数组
                let map = transformData(flawFilterCountArr);
                let flawFilterArray = [];
                for (const i of map) {
                    flawFilterArray.push(i[1]);
                }
                let resultData = [];
                this.flawFilterDataArr1.forEach(item => {
                    let data = {
                        ...item,
                    };
                    delete data.id;
                    flawFilterArray.forEach(flawFilterItem => {
                        if (flawFilterItem.flaw_class_type == item.id) {
                            data.flaw_count = flawFilterItem.flaw_count;
                            data.station_id = flawFilterItem.station_id;
                            data.station_name = flawFilterItem.station_name;
                        }
                    });
                    if(!resultDataObj[item.id]) {
                        resultDataObj[item.id] = true;
                        //TODO: 没有缺陷数量的缺陷，在本次统计中无 station_name 和 station_id
                        resultData.push({
                            ...data,
                            panel_id: flawFilterArray[0].panel_id,
                            panel_table_uid: flawFilterArray[0].panel_table_uid,
                            // TODO flaw_class_type: item.id,
                            flaw_class_type: item.id + '__' + this.stationInfo.station_alias,
                            flaw_count: data.flaw_count ? data.flaw_count : 0,
                        });
                    }
                });
                // 缺陷分类数组置空
                this.flawFilterDataArr1 = [];
                // 返回格式化成父子关系的数组
                return formatFlawFilterData(resultData);
            } else {
                let resultData = this.flawFilterDataArr1;
                this.flawFilterDataArr1 = [];
                return formatFlawFilterData(resultData);
            }
        } catch (error) {
            this.logger.err(error);
            return [];
        }
    }
    /**
     * hand flaw_filter
     */
    async handFlawFilterinfo(panelId) {
        try {
            if (panelId) {
                return await this.transformFlawFilteDataToDetectParam(panelId);
            }

            // 插叙缺陷类型json
            // let res = await this.FlawFilterPiantie.getFlawFilterInfoByDoffUid(this.sequelize_source, this.panelUid);
            // 整理缺陷类型
            //查询这片上面的所有缺陷
            let flawFilterCount = await this.FlawFilterPiantie.getFlawCountByPanel(this.sequelize_source, this.panelUid);
            // 这片上有缺陷
            if (flawFilterCount.length) {
                // 统计转换
                let map = transformData(flawFilterCount);
                let flawFilterArray = [];
                // flawFilter ID开始的位置
                if (this.panelUid != this.currentFlawFilterId) {
                    this.FlawFilterId = this.FlawFilterId + this.currentFlawFilterArr.length;
                }
                let index = 1;
                for (const i of map) {
                    flawFilterArray.push({
                        ...i[1],
                        id: this.FlawFilterId + index,
                    });
                    index++;
                }
                this.currentFlawFilterId = this.panelUid;
                // 遍历所有缺陷分类，加上color， show， symbol三个属性
                let resultData = [];
                const resultDataObj = {}; // 记录已经存储了那些缺陷
                flawFilterArray.forEach(flawFilterItem => {
                    this.flawFilterDataArr.forEach(item => {
                        if (flawFilterItem.flaw_class_type === item.id) {
                            if(!resultDataObj[item.id]) {
                                // 此缺陷已经存储  记录下来
                                resultDataObj[item.id] = true;
                                resultData.push({
                                    ...flawFilterItem,
                                    // TODO flaw_class_type: flawFilterItem.flaw_class_type,
                                    flaw_class_type: flawFilterItem.flaw_class_type + '__' + this.stationInfo.station_alias,
                                    color: item.color,
                                    show: item.show,
                                    shape: item.shape,
                                    symbol: item.symbol,
                                });
                            }
                        }
                    });
                });
                this.currentFlawFilterArr = resultData;
                //post目标库
                let postResult = await this.postDataToLineDb(this.FlawFilterPiantie, resultData, 'flaw_filter');

                return resultData;
            }
            // 缺陷类型数组置空
            this.flawFilterDataArr = [];
            return [];
        } catch (_) {
            this.logger.err(_);
            return []
        }
    }
    /**
     * 解析缺陷信息
     * @param {Object} data 代转换的对象
     */
    handTranformData(data, update) {
        for (const key in data) {
            if (key === 'Attributes') {
                if (update) {
                    this.flawFilterDataArr1.push({
                        show: data[key].show,
                        symbol: data[key].symbol,
                        color: data[key].color,
                        id: data[key].id,
                        shape: data[key].shape,
                        // TODO flaw_class_type: data[key].id,
                        flaw_class_type: data[key].id + '__' + this.stationInfo.station_alias,
                        flaw_count: 0,
                    });
                } else {
                    this.flawFilterDataArr.push({
                        show: data[key].show,
                        symbol: data[key].symbol,
                        color: data[key].color,
                        id: data[key].id,
                        shape: data[key].shape,
                        // TODO flaw_class_type: data[key].id,
                        flaw_class_type: data[key].id + '__' + this.stationInfo.station_alias,
                        flaw_count: 0,
                    });
                }
            }
            if (
                key !== 'Attributes' &&
                Object.prototype.toString.call(data[key]) === '[object Object]'
            ) {
                this.handTranformData(data[key], update);
            }
        }
    }
    /**
     * 同步 flaw信息
     * @param {string} panelInfo
     * @returns flaw的信息对象
     */
    async handFlawInfo(panelInfo) {
        try {
            let res = [];
            if (panelInfo.panelId) {
                res = await this.FlawPiantie.getFlawData(this.sequelize_source, panelId, this.stationInfo.station_alias);
                res = res.map(item => {
                    let temp = '';
                    if (item.save_path) {
                        temp = item.save_path.split("\\");
                        // 把内网IP 转成 能与产线直连的 ip
                        temp[2] = this.sourceIp;
                    }
                    return {
                        ...item,
                        save_path: temp == '' ? '' : temp.join('\\')
                    }
                })
            } else {
                // 根据 panel_info 的uid 查询这片上的缺陷信息
                res = await this.FlawPiantie.getFlawData(this.sequelize_source, this.panelUid, this.stationInfo.station_alias);
                let detectParam = await this.FlawFilterPiantie.getFlawFilterInfoByDoffUid(this.sequelize_source, this.panelUid);
                // 此片上有缺陷
                let flawObj = Tools.getPtStationFlawTypeObj(detectParam, this.stationInfo.station_alias ,this.stationInfo.station_name_standard);
                if (res.length) {
                    // 转ip
                    let rotatePoints = {};
                    res = res.map(item => {
                        let temp = '';
                        if (item.save_path) {
                            temp = item.save_path.split("\\");
                            // 把内网IP 转成 能与产线直连的 ip
                            temp[2] = this.sourceIp;
                        }
                        // 旋转flaw
                        rotatePoints = Tools.getRotatedFlawPoints(
                            {
                                x: item.center_pos_cd,
                                y: item.center_pos_md
                            },
                            {
                                rotate: this.rotateConf.rotate,
                                xMirror: this.rotateConf.xMirror,
                                height: panelInfo.length_md,
                                width: panelInfo.length_cd
                            }
                        )
                        return {
                            ...item,
                            save_path: temp == '' ? '' : temp.join('\\'),
                            show: flawObj[item.flaw_class_type].show,
                            ui_show_text: flawObj[item.flaw_class_type].symbol,
                            center_pos_cd: rotatePoints.x,
                            center_pos_md: rotatePoints.y,
                        }
                    })

                    //post目标库
                    await this.postDataToLineDb(this.FlawPiantie, res);
                    this.logger.info(`panel_info表uid: ${this.panelUid}的缺陷信息同步成功`);
                }
            }
            return res;
        } catch (_) {
            this.logger.err(_);
            return [];
        }
    }
    /**
     * hand job
     * @param {String} panelId
     */
    async handJobInfo(panelId) {
        try {
            if (panelId) {
                let jobInfo = await this.JobPiantie.getJobInfoByPanelId(this.sequelize_source, panelId);
                return jobInfo;
            }
            // 保证job下的所有doff都存再去同步job
            let res = await this.JobPiantie.getJobInfoByPanelId(this.sequelize_source, this.jobUid);
            if (res) {
                // post目标库
                await this.postDataToLineDb(this.JobPiantie, res);
                this.logger.info(`${res.job_name}工单上传${this.stationName} 工站sucess!`);
                if (res.ok_number + res.ng_number != res.panel_sum && maxJobUid == this.jobUid) {
                    this.logger.info(`job_name: ${res.job_name}不是最新，轮询继续更新!`);
                    return false;
                }
            }
            // 查询doff表的max(jobId)
            let maxJobUid = await this.JobPiantie.getMaxJobIdFromSource(this.sequelize_source);
            // 更新当前同步位置
            this.jobUid < maxJobUid ? this.jobUid++ : '';
        } catch (error) {
            this.logger.err(error);
        }
    }
    /**
     * 处理panel
     * @param {String} panelId
     */
    async handPanelInfo(panelId) {
        try {
            // 通过panel_id查
            if (panelId) {
                let panelInfo = await this.PanelPiantie.findLatestPanelInfo(this.sequelize_source, panelId);
                if (!panelInfo) return [];
                // 缓存不需要这个数据
                delete panelInfo.detectParam;
                return this.shakePanelInfo(panelInfo);
            }

            // 查询 panel_info uid对应的片信息
            let panelInfo = await this.PanelPiantie.findLatestPanelInfo(this.sequelize_source, this.panelUid);
            // this.logger.info(panelInfo);
            if (panelInfo) {
                let detectParamData = await this.transformFlawFilteDataToDetectParam(panelInfo.panel_id);

                // 缺陷分类有问题，抛弃
                if (!detectParamData.length) {
                    let maxPanelUid = await this.PanelPiantie.getLatestPanelFromSource(this.sequelize_source, true);
                    this.panelUid < maxPanelUid ? this.panelUid++ : '';
                    return;
                }
                // 格式转换
                let detectParamDataJson = JSON.stringify(detectParamData);
                let panelInfoFormat = this.shakePanelInfo(panelInfo, detectParamDataJson);
               
                // 片旋转
                let panelInfoRotated = {
                    ...panelInfoFormat,
                    // 旋转角度引起的高度变化
                    length_md: this.rotateConf.rotate % 180 == 0 ? panelInfoFormat.length_md : panelInfoFormat.length_cd,
                    length_cd: this.rotateConf.rotate % 180 == 0 ? panelInfoFormat.length_cd : panelInfoFormat.length_md
                }
                // 上传panel
                await this.postDataToLineDb(this.PanelPiantie, panelInfoRotated);
                // 上传 flaw
                const flawInfo = await this.handFlawInfo({
                    length_md: panelInfoFormat.length_md,
                    length_cd: panelInfoFormat.length_cd
                });
                // 上传 flaw_filter
                const flawFilterInfo = await this.handFlawFilterinfo();
                const panelAllInfo = {
                    panelInfo: panelInfoRotated, // Object
                    flawInfo, // arr
                    flawFilterInfo, //arr
                    isPiantie: true
                }
                // 生成uuid 并把此片的信息以及缺陷信息写到汇总
                handleUuid.addQueue(this.sequelize_aim, panelInfo.panel_id, this.stationName, panelAllInfo);
            }
            let maxPanelUid = await this.PanelPiantie.getLatestPanelFromSource(this.sequelize_source, true);
            this.panelUid < maxPanelUid ? this.panelUid++ : '';
        } catch (_) {
            this.logger.err(_);
        }
    }
    /**
     * panel的数据格式转换逻辑
     * @param {*} panelInfo
     * @returns {Object} panel信息
     */
    shakePanelInfo(panelInfo, detectParamData) {

        let exConfig1 = JSON.parse(panelInfo.exConfig1);
        if (exConfig1) {
            let modelSize = exConfig1.job.modelSize.value;
            // let length_cd = Math.floor(Number(modelSize.slice(0, modelSize.search(/;/))) * piantie_precision.scaleX);
            // let length_md = Math.floor(Number(modelSize.slice(modelSize.search(/;/) + 1, modelSize.length)) * piantie_precision.scaleY);
            let length_cd = parseFloat(modelSize.split(';')[0]) * piantie_precision.scaleX;
            let length_md = parseFloat(modelSize.split(';')[1]) * piantie_precision.scaleY;
            let panelInfoFormat = {
                ...panelInfo,
                length_md,
                length_cd,
                gen_time_str: formatDate(panelInfo.gen_time),
                is_ok: panelInfo.flaw_count > 0 ? 0 : 1,
                checked: false,
                detectParam: detectParamData,
                ex_info: JSON.stringify({
                    ex_info1: JSON.parse(panelInfo.ex_info1 ? panelInfo.ex_info1 : {} )
                })
            };
            delete panelInfoFormat.exConfig1;
            return panelInfoFormat;
        } else {
            this.logger.info(`**${this.stationName}**源库panelID: ${panelInfo.panel_id}缺少exConfig1字段!`);
            let panelInfoFormat = {
                ...panelInfo,
                gen_time_str: formatDate(panelInfo.gen_time),
                is_ok: panelInfo.flaw_count > 0 ? 0 : 1,
                checked: false,
                detectParam: detectParamData,
                ex_info: JSON.stringify({
                    ex_info1: JSON.parse(panelInfo.ex_info1 ? panelInfo.ex_info1 : {} )
                })
            };
            delete panelInfoFormat.exConfig1;
            return panelInfoFormat;
        }
    }
    /**
     * 上传data到产线db的指定表中
     * @param {} operatorName 表的操作对象
     * @param {Object} data 上传的数据
     */
    async postDataToLineDb(operatorName, data) {
        try {
            let res = await operatorName.uploadPolInfo(operatorName, data);
            return (res.dataValues || res.length) ? true : false
        } catch (_) {
            this.logger.err(_);
            return false;
        }
    }
}

module.exports = PiantieBase;
