/**
 * @file {同步cf_pol 精度检测工位数据}
 */
'use strict'

const PolBase = require('./base');
const { initCfPolFlawData } = require('../../model/pol/cf_pol/flaw');
const { initCfPolFlawFilterData } = require('../../model/pol/cf_pol/flaw_filter');
const { initCfPolJobData } = require('../../model/pol/cf_pol/job');
const { initCfPolPanelData } = require('../../model/pol/cf_pol/panel');
const { start_position } = require('../../config.json');
const { xlog, path } = require('xlog');
const logger = new xlog({
    projectName: 'rtp_line_et',
    filePath: path.join(__dirname, '../../logs'),
    category: ['pol', 'cf_pol'],
    logsName: 'cf_pol',
    logging: true
});
const { station_db, cf_pol_gap_num } = require('../../config.json')
class SynchronizeCfPol extends PolBase {

    constructor(tableModel, sequelize_source, sequelize_source_ipu, sequelize_aim, stationInfo, rotateConf) {
        initCfPolFlawData(sequelize_aim);
        initCfPolFlawFilterData(sequelize_aim);
        initCfPolJobData(sequelize_aim);
        initCfPolPanelData(sequelize_aim);
        super(tableModel, sequelize_source, sequelize_source_ipu, sequelize_aim, stationInfo, logger, start_position.cf_pol, station_db.cf_pol_new_db_config.host, cf_pol_gap_num, rotateConf);
    }
    /**
     * 初始化参数
     * @param {Object} 各个表的模型
     * @param {Sequeliz} sequelize_source 源表的sequelize实例
     * @param {Sequeliz} sequelize_aim 目标表的sequelize实例
     * @param {string} stationName 工站名（便于日志区分）
     * @returns
     */
    static getInstance(tableModel, sequelize_source, sequelize_source_ipu, sequelize_aim, stationInfo, rotateConf) {
        if (SynchronizeCfPol.instance) {
            return SynchronizeCfPol.instance;
        } else {
            SynchronizeCfPol.instance = new SynchronizeCfPol(tableModel, sequelize_source, sequelize_source_ipu, sequelize_aim, stationInfo, rotateConf);
            return SynchronizeCfPol.instance;
        }
    }
    /**
    * 根据panel获取全部信息
    * @param {String} panel_id
    * @returns Object | null
    */
    async getNewstInfoByPanelId(panel_id) {
        try {
            let panel_info = await this.handPanelInfo(panel_id);
            let job_info = await this.handJobInfo(panel_id);
            let flaw_info = await this.handFlawInfo(panel_id);
            let flaw_filter_info = await this.handFlawFilterInfo(panel_id);
            // console.log(flaw_filter_info);
            let stations = flaw_filter_info.map((item) => {
                return {
                    station_id: item.station_id,
                    station_name: item.station_name
                }
            })
            let result = stations.filter(item => {
                return item.station_id;
            })
            return {
                panel_info,
                job_info,
                flaw_info,
                flaw_filter_info,
                stations: result
            }
        } catch (error) {
            console.log(error);
            return null;
        }

    }
    // 回写checked字段
    async reWriteChecked(panelId) {
        try {
            let res = await this.PanelPol.reWriteChecked(this.PanelPol, panelId);
            if (res[0] && res[0].dataValues) {
                console.log(`${this.stationName} Panel checked回写成功!`);
            }
        } catch (error) {
            console.log(error);
        }
    }
}

module.exports = SynchronizeCfPol;
