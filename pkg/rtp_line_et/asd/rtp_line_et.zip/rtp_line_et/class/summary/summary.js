'use strict'
const { linedb_summary_config } = require('../../config.json').line_db;
const { lia_web_rtp_config } = require('../../config.json').line_db;
const seqRtpSummary = require('../../lib/db').getSequelizeInstance(linedb_summary_config);
const seqWebInstance = require('../../lib/db').getSequelizeInstance(lia_web_rtp_config);
const seqModleRtpSummary = require('../../model/summary/panel_summary');
const flawModel = require('../../model/summary/flaw');
const flawFilterModel = require('../../model/summary/flaw_filter');
const { isEndWith } = require('../../uitls/tool');
const { xlog, path } = require('xlog');
const logger = new xlog({
    projectName: 'rtp_line_et',
    filePath: path.join(__dirname, '../../logs'),
    category: ['summary', 'summary'],
    logsName: 'summary',
    logging: true
});

class panelSummary {

    constructor() {
        // 初始化model
        seqModleRtpSummary.initPanelData(seqRtpSummary);
        flawModel.initFlawMujinaData(seqRtpSummary);
        flawFilterModel.initFlawFilterData(seqRtpSummary);
        // 时间起始选择的工站
        this.minStationName = "piantieqian"
        this.maxStationName = "piantiehou"
        // 片大小选择的工站
        this.panelStationName = "piantiehou"
        this.init();
    }

    async init() {
        // 时间按照所有工站中的最先一站（开始）与最后一站（结束）为准，片大小按除精度检测的最后一站
        let webStation = await seqWebInstance.query(`select station_name, order_weights from cube_rtp_station where is_open=1`, { type: seqWebInstance.QueryTypes.SELECT })
        if (webStation.length) {
            let order = webStation.map(v => v.order_weights)
            let orderPanel = webStation.filter(v => {
                return !isEndWith(v.station_name, 'jingdu')
            }).map(v => v.order_weights)
            let min = Math.min(...order)
            let max = Math.max(...order)
            let maxPanel = Math.max(...orderPanel)
            this.minStationName = webStation.find(v => v.order_weights == min).station_name
            this.maxStationName = webStation.find(v => v.order_weights == max).station_name
            this.panelStationName = webStation.find(v => v.order_weights == maxPanel).station_name
        }
        // panel的汇总uid
        let res = await seqRtpSummary.query(`select max(uid) as uid from  panel_summary`, { type: seqRtpSummary.QueryTypes.SELECT });
        if (res.length) {
            this.pSuid = res[0].uid;
            return;
        }
        // 初始值 0 + 1
        this.pSuid = 0;
    }
    /**
     * 根据uuid查到汇总片的信息 + panel_ifno的信息，汇总起来
     * @param {Panel_uuid} uuid
     * @param {Object} panel_info {panelInfo: {}, flawInfo: [], flawFilterInfo: []}
     */
    async handPanelSummary(uuid, panelAllInfo, stationName) {

        try {
            // 查出汇总的这片的片信息做汇总
            const panelSummaryInfos = await seqRtpSummary.query(`select * from panel_summary where panel_uuid = "${uuid}" order by uid desc limit 1`, { type: seqRtpSummary.QueryTypes.SELECT });
            // logger.info(stationName, '++++');
            if (panelSummaryInfos.length) {
                let panelSummaryInfo = panelSummaryInfos[0];
                let detectParam = null;
                // 合并 除精度检测外的其他站的 detectParam
                if (panelSummaryInfo.detectParam && stationName != 'cf_jingdu' && stationName != 'tft_jingdu') {
                    let detect1 = JSON.parse(panelSummaryInfo.detectParam);
                    let detect2 = JSON.parse(panelAllInfo.panelInfo.detectParam);
                    detectParam = JSON.stringify([
                        ...detect1,
                        ...detect2
                    ])
                } else {
                    detectParam = panelAllInfo.panelInfo.detectParam;
                }
                // console.log(panelAllInfo.panelInfo.length_md, panelSummaryInfo.length_md, panelAllInfo.panelInfo.length_md > (panelSummaryInfo.length_md || 0 ));
                // logger.info(detectParam, '+++');
                let newsPanelSummaryInfo = {
                    ...panelSummaryInfo,
                    flaw_count: (panelSummaryInfo.flaw_count ? panelSummaryInfo.flaw_count : 0) + (panelAllInfo.panelInfo.flaw_count ? panelAllInfo.panelInfo.flaw_count : 0),
                    is_ok: Number(panelSummaryInfo.is_ok) && panelAllInfo.panelInfo.is_ok,
                    // 宽度 和 高度 拿 最大的值（汇总缺陷 + 中心对齐）
                    length_md: panelAllInfo.panelInfo.length_md > (panelSummaryInfo.length_md || 0) ? panelAllInfo.panelInfo.length_md : panelSummaryInfo.length_md, // 和偏贴后保持一致
                    length_cd: panelAllInfo.panelInfo.length_cd > (panelSummaryInfo.length_cd || 0) ? panelAllInfo.panelInfo.length_cd : panelSummaryInfo.length_cd, // 和偏贴后保持一致
                    checked: Number(panelSummaryInfo.checked) && panelAllInfo.panelInfo.checked,
                    start_time: stationName == this.minStationName ? panelAllInfo.panelInfo.gen_time : panelSummaryInfo.start_time, // 开始时间
                    start_time_str: stationName == this.minStationName ? panelAllInfo.panelInfo.gen_time_str : panelSummaryInfo.start_time_str,
                    finish_time: stationName == this.maxStationName ? panelAllInfo.panelInfo.gen_time : panelSummaryInfo.finish_time,// 结束时间
                    finish_time_str: stationName == this.maxStationName ? panelAllInfo.panelInfo.gen_time_str : panelSummaryInfo.finish_time_str,
                    detectParam
                }

                // flaw
                // 处理缺陷点的 基于新大小的中心对齐
                await this.handFlawSummary(panelAllInfo, panelSummaryInfo, stationName);

                // 上传panel信息
                await seqModleRtpSummary.PanelMujian.uploadInfo([newsPanelSummaryInfo]);
                logger.info(`${stationName}站panelId: ${panelAllInfo.panelInfo.panel_id}汇总成功!`);

                // flaw_filter
                await this.handFlawFilterSummary(panelAllInfo.flawFilterInfo, panelSummaryInfo.uid);
                logger.info(`${stationName}站panelId: ${panelAllInfo.panelInfo.panel_id}在汇总生成!`);
                return;
            }
            // 直接上传
            await seqModleRtpSummary.PanelMujian.uploadInfo([{
                ...panelAllInfo.panelInfo,
                uid: ++this.pSuid // 维护汇总uid 自增序列
            }]);
            // flaw
            await this.handFlawSummary(panelAllInfo, {}, stationName);
            // flaw_filter
            await this.handFlawFilterSummary(panelAllInfo.flawFilterInfo, this.pSuid);
            logger.info(`${stationName}站panelId: ${panelAllInfo.panelInfo.panel_id}在汇总生成!`);
        } catch (_) {
            console.log(_);
            // logger.err(_);
        }
    }
    /**
     * 汇总缺陷
     * @param {Object} panelAllInfo 当前工站panel
     * @param {Object} panelSummaryInfo 汇总panel
     * @param {string} stationName 当前工站名
     */
    async handFlawSummary(panelAllInfo, panelSummaryInfo, stationName) {
        
        if (!panelAllInfo.flawInfo.length) return;

        // panel_table_uid
        panelAllInfo.flawInfo = panelAllInfo.flawInfo.map(item => ({...item, panel_table_uid: panelSummaryInfo.uid}));
        // 第一个汇总的工站 直接上传 或者 精度检测 直接上传
        if (
            !panelSummaryInfo.uid ||
            (stationName == 'cf_jingdu' || stationName == 'tft_jingdu') ||
            !panelSummaryInfo.length_md ||
            !panelSummaryInfo.length_cd
        ) {
            return await flawModel.FlawMujian.uploadInfo(panelAllInfo.flawInfo);
        }

        // 新工站的 片宽高
        const newsPanelMd = panelAllInfo.panelInfo.length_md;
        const newsPanelCd = panelAllInfo.panelInfo.length_cd;
        // 汇总 原来的片的 宽高
        const oldPanelMd = panelSummaryInfo.length_md;
        const oldPanelCd = panelSummaryInfo.length_cd;
        // 偏移
        const x_offset = parseFloat((Math.abs(newsPanelCd - oldPanelCd) / 2));
        const y_offset = parseFloat((Math.abs(newsPanelMd - oldPanelMd) / 2));

        console.log(newsPanelMd, newsPanelCd, oldPanelMd, oldPanelCd, x_offset, y_offset);
        if (newsPanelMd == oldPanelMd && newsPanelCd == oldPanelCd) {
            return await flawModel.FlawMujian.uploadInfo(panelAllInfo.flawInfo);
        }

        // 新的长宽都比老的小 ---> 中心对齐新的坐标集合 老数据不变
        if (newsPanelMd < oldPanelMd && newsPanelCd < oldPanelCd) {
            const newsFlawInfo = panelAllInfo.flawInfo.map(item => {
                
                return {
                    ...item,
                    center_pos_md: Number(item.center_pos_md) + y_offset,
                    center_pos_cd: Number(item.center_pos_cd) + x_offset
                }
            })

            return await flawModel.FlawMujian.uploadInfo(newsFlawInfo);
        }

        // 新的长宽都比老的大 ---> 中心对齐老的坐标集合 新数据不变
        if (newsPanelMd > oldPanelMd && newsPanelCd > oldPanelCd) {
            // 更新老的
            let updateFlawInfo = await seqRtpSummary.query(`select * from flaw where panel_table_uid = ${panelSummaryInfo.uid}`, { type: seqRtpSummary.QueryTypes.SELECT });
            updateFlawInfo = updateFlawInfo.map(item => {
                // 精度检测 部中心对齐
                if (item.flaw_class_type.indexOf('10000__') !== -1) {
                    return item;
                }
                return {
                    ...item,
                    center_pos_md:   Number(item.center_pos_md) + y_offset,
                    center_pos_cd: Number(item.center_pos_cd )+ x_offset
                }
            });

            // 更新老的
            await flawModel.FlawMujian.updateFlawPos(updateFlawInfo);

            // 上传新的
            return await flawModel.FlawMujian.uploadInfo(panelAllInfo.flawInfo);
        }

        // 其余的情况
        if (newsPanelCd < oldPanelCd && newsPanelMd > oldPanelMd) {
            // 更新老的
            let updateFlawInfo = await seqRtpSummary.query(`select * from flaw where panel_table_uid = ${panelSummaryInfo.uid}`, { type: seqRtpSummary.QueryTypes.SELECT });
            updateFlawInfo = updateFlawInfo.map(item => {
                // 精度检测 部中心对齐
                if (item.flaw_class_type.indexOf('10000__') !== -1) {
                    return item;
                }
                return {
                    ...item,
                    center_pos_md: Number(item.center_pos_md) + y_offset
                }
            });

            // 更新老的
            await flawModel.FlawMujian.updateFlawPos(updateFlawInfo);

            // 更新新的
            const newsFlawInfo = panelAllInfo.flawInfo.map(item => {
                return {
                    ...item,
                    center_pos_cd: Number(item.center_pos_cd) + x_offset
                }
            })
            // 上传新的
            return await flawModel.FlawMujian.uploadInfo(newsFlawInfo);
        }

        // 其余的情况
        if (newsPanelCd > oldPanelCd && newsPanelMd < oldPanelMd) {
            // 更新老的
            let updateFlawInfo = await seqRtpSummary.query(`select * from flaw where panel_table_uid = ${panelSummaryInfo.uid}`, { type: seqRtpSummary.QueryTypes.SELECT });
            updateFlawInfo = updateFlawInfo.map(item => {
                // 精度检测 部中心对齐
                if (item.flaw_class_type.indexOf('10000__') !== -1) {
                    return item;
                }
                return {
                    ...item,
                    center_pos_cd: Number(item.center_pos_cd) + x_offset
                }
            });

            // 更新老的
            await flawModel.FlawMujian.updateFlawPos(updateFlawInfo);

            // 更新新的
            const newsFlawInfo = panelAllInfo.flawInfo.map(item => {
                return {
                    ...item,
                    center_pos_md: Number(item.center_pos_md) + y_offset,
                }
            })
            // 上传新的
            return await flawModel.FlawMujian.uploadInfo(newsFlawInfo);
        }
    }
    /**
     * 汇总缺陷筛选
     * @param {Array} flawFilterArr
     * @param {Number} panelSummaryUid
     */
    async handFlawFilterSummary(flawFilterArr, panelSummaryUid) {
        let flawFilter = {};
        const dealedFlawFilterArr = flawFilterArr.map(item => {
            flawFilter = item;
            delete flawFilter.uid;
            flawFilter.panel_table_uid = panelSummaryUid;
            return flawFilter;
        })
        await flawFilterModel.FlawFilterMujian.uploadInfo(dealedFlawFilterArr);
        logger.info('flaw汇总成成功!');
    }
    // 回写汇总库checked
    async reWriteChecked(panelId, panel_info) {
        try {
            let res = await seqModleRtpSummary.PanelMujian.reWriteChecked(seqModleRtpSummary.PanelMujian, panelId);
            if (res[0] && res[0].dataValues) {
                logger.info(`汇总库 Panel checked回写成功!`);
                return res[0].panel_uuid;
            } else {
                return false;
            }
        } catch (error) {
            logger.info(error);
            return false;
        }
    }

    static getInstance() {
        if (!panelSummary.instance) {
            panelSummary.instance = new panelSummary();
        }
        return panelSummary.instance;
    }
}

module.exports = panelSummary.getInstance();
