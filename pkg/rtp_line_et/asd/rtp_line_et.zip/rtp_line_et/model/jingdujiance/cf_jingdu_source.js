/**
 * @file {cf精度检测目标库panel表model}
 */
'use strict'

const { Model, Op } = require('sequelize');
const { station_db, jingdu_table_name } = require('../../config.json');
const seqCfSource = require('../../lib/db').getSequelizeInstance(station_db.cf_jingdu_db_config);
class PanelSourceCfJingdu extends Model { }

// const { panelJingduInitData } = require('../common/init_data');
// PanelSourceCfJingdu.init(
//     ...panelJingduInitData,
//     {
//         freezeTableName: true,
//         sequelize: seqCfSource,
//         modelName: jingdu_table_name,
//         timestamps: false
//     }
// )

// 通过uid 获取panel信息
// PanelSourceCfJingdu.getPanelInfoByUid = async (uid) => {
//     const res = await PanelSourceCfJingdu.findOne({
//         where: {
//             uid
//         }
//     });
//     // console.log(res, '--');
//     return res;
// }

// PanelSourceCfJingdu.getStartPos = async () => {
//     const res = await seqCfSource.query('select min(uid) as uid from panel', {type: seqCfSource.QueryTypes.SELECT});
//     if(res[0]) {
//         return
//     }
// }

// 查询源库最新的同步位置
// PanelSourceCfJingdu.getMaxUidFromSource = async () => {
//     const res = await PanelSourceCfJingdu.findOne({
//         attributes: [seqCfSource.fn('max', seqCfSource.col('uid'))]
//     });
//     return res['max(`uid`)'];
// }

// 因为精度检的原库改变，所以改为原生查询

// 通过uid 获取panel信息
PanelSourceCfJingdu.getPanelInfoByUid = async (uid) => {
    const res = await seqCfSource.query(`select * from  panel where uid = ${uid} limit 1`, { type: seqCfSource.QueryTypes.SELECT })
    return res[0];
}
// 查询源库最新的同步位置
PanelSourceCfJingdu.getMaxUidFromSource = async () => {
    const res = await seqCfSource.query(`select * from panel ORDER BY uid DESC limit 1`, { type: seqCfSource.QueryTypes.SELECT });
    return res[0] && res[0].uid;
}



module.exports = { PanelSourceCfJingdu, seqCfSource };