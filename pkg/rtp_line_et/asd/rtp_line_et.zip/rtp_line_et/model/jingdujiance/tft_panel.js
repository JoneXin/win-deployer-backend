/**
 * @file {cf精度检测目标库panel表model}
 */
'use strict'

const { Model, DataTypes } = require('sequelize');
const { line_db } = require('../../config.json');
const seqTftAim = require('../../lib/db').getSequelizeInstance(line_db.linedb_tft_jingdujiance_config);
const { panelJingduInitData } = require('../common/init_data');
class PanelTftJingdu extends Model { }

PanelTftJingdu.init(
    {
        ...panelJingduInitData[0],
        checked: {
            field: 'checked',
            type: DataTypes.INTEGER
        },
        // 增加同步的字段
        ex_info: {
            field: 'ex_info',
            type: DataTypes.TEXT
        },
    },
    {
        freezeTableName: true,
        sequelize: seqTftAim,
        modelName: 'panel',
        timestamps: false
    }
)

PanelTftJingdu.getNewsSyncPanel = async () => {
    let res = await seqTftAim.query(`select max(uid) as uid from panel`, { type: seqTftAim.QueryTypes.SELECT });
    return res[0].uid ? res[0].uid : 1
}

PanelTftJingdu.upload = async (data) => {
    // 精度检测导出新增11个字段，从原库读取这11个字段，存放在中间库的ex_info字段中同步过来，所以下面要更新的字段需要添加一个"ex_info"
    let res = await PanelTftJingdu.bulkCreate([data], {
        updateOnDuplicate:
            ['uid', 'panelId', 'genTime', 'genTimeStr', 'isOk', 'savePath', 'ltX', 'ltY', 'rtY', 'rtX', 'lbX', 'lbY', 'rbY', 'rbX','ex_info'],
    });
    return res;
}

module.exports = { PanelTftJingdu, seqTftAim };