
'use strict'
const { formatDate } = require('../../../uitls/tool');
// 获取源库doff表的max(uid)
const getMaxJobIdFromSource = async (sequelize_source) => {
     // job_id 是有索引的
     let res = await sequelize_source.query('select max(jobId) as jobId from doff', { type: sequelize_source.QueryTypes.SELECT });
     return res[0].jobId;
}

// 获取目标库job的max(uid)
const getLatestJobId = async (sequelize_aim) => {
     let res = await sequelize_aim.query('select max(uid) as uid from job', { type: sequelize_aim.QueryTypes.SELECT });
     return res[0].uid ? res[0].uid : 1;
}

/**
 * 查询源库panelID对应的job信息 || 查询源库job -> uid对应的job信息
 * @param {*} sequelize_source
 * @param {String | Number} queryStr panelID | uid
 * @returns {Object} 源库的job信息
 */
const getJobInfoByPanelId = async (sequelize_source, queryStr) => {
     let query = typeof (queryStr) == 'string' ? `b.uid = (select d.uid from doff d inner join panel_info c on d.uid = c.doff_id where c.panel_id = "${queryStr}")` : `a.uid = ${queryStr}`;
     let query1 = typeof (queryStr) == 'string' ? `(select c.jobId from doff c inner join panel_info d on c.uid = d.doff_id where d.panel_id = "${queryStr}")` : `${queryStr}`;
     let res = await sequelize_source.query(`select a.uid, a.jobName as job_name, a.doffSum as panel_sum, a.createTime as start_time, 
     a.finishTime as finish_time, a.orderNumber as order_number from job a inner join doff b on a.uid = b.jobId where ${query}`, { type: sequelize_source.QueryTypes.SELECT });
     let res1 = await sequelize_source.query('select Count(*) as ok_number from doff where flawCount = 0 and jobId = ' + query1, { type: sequelize_source.QueryTypes.SELECT });
     return res.length ? {
          ...res[0],
          ok_number: res1[0].ok_number,
          ng_number: res[0].panel_sum - res1[0].ok_number,
          start_time_str: formatDate(res[0].start_time),
          finish_time_str: formatDate(res[0].finish_time),
     } : null
}

//上传job信息到目标库
const uploadPolInfo = async (JobPiantie, data) => {
     let res = await JobPiantie.bulkCreate([data], { updateOnDuplicate: ['uid', 'job_name', 'panel_sum', 'ok_number', 'ng_number', 'start_time', 'finish_time', 'start_time_str', 'finish_time_str'], });
     return res;
}
module.exports = {
     getMaxJobIdFromSource,
     getLatestJobId,
     getJobInfoByPanelId,
     uploadPolInfo
};