'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {jobInitData} = require('../../common/init_data');
const {
    getMaxJobIdFromSource,
    getLatestJobId,
    getJobInfoByPanelId,
    uploadPolInfo
} = require('../common/job');

class JobPiantiehou extends Model {}

const initPiantiehouJobData = (sequelize_aim) => {
    JobPiantiehou.init(
        ...jobInitData, {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'job',
            timestamps: false
        }
    )
}

JobPiantiehou.getMaxJobIdFromSource = getMaxJobIdFromSource;
JobPiantiehou.getLatestJobId = getLatestJobId;
JobPiantiehou.getJobInfoByPanelId = getJobInfoByPanelId;
JobPiantiehou.uploadPolInfo = uploadPolInfo;

module.exports = {
    JobPiantiehou,
    initPiantiehouJobData
};