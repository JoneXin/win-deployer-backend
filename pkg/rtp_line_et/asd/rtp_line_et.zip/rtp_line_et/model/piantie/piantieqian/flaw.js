'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {flawInitData} = require('../../common/init_data');
class FlawPiantieqian extends Model { }
const {
    getLatestFlawId,
    getFlawData,
    uploadPolInfo
} = require('../common/flaw');

const initPiantieqianFlawData = (sequelize_aim) => {
FlawPiantieqian.init(
    ...flawInitData,
    {
        freezeTableName: true,
        sequelize: sequelize_aim,
        modelName: 'flaw',
        timestamps: false
    }
    )
}
FlawPiantieqian.getLatestFlawId = getLatestFlawId;
FlawPiantieqian.getFlawData = getFlawData;
FlawPiantieqian.uploadPolInfo = uploadPolInfo;

module.exports = {
    FlawPiantieqian,
    initPiantieqianFlawData
};