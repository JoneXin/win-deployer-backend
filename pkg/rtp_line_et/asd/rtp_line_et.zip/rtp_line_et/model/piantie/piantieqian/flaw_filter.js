'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {flawFilterInitData} = require('../../common/init_data');
class FlawFilterPiantieqian extends Model { }
const {
    getMaxPanelIdFromFlawFilter,
    getLatestFlawFilterId,
    getMaxPanelUid,
    getFlawCountByPanel,
    getFlawFilterInfoByDoffUid,
    uploadPolInfo
} = require('../common/flaw_filter');
/**
 * @desc 映射需要的字段 【源库的 部分字段 --> 目标库字段】
 */
const initPiantieqianFlawFilterData = (sequelize_aim) => {
FlawFilterPiantieqian.init(
        ...flawFilterInitData,
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'flaw_filter',
            timestamps: false
        }
)
}
FlawFilterPiantieqian.getMaxPanelIdFromFlawFilter = getMaxPanelIdFromFlawFilter;
FlawFilterPiantieqian.getLatestFlawFilterId = getLatestFlawFilterId;
FlawFilterPiantieqian.getMaxPanelUid = getMaxPanelUid;
FlawFilterPiantieqian.getFlawCountByPanel = getFlawCountByPanel;
FlawFilterPiantieqian.getFlawFilterInfoByDoffUid = getFlawFilterInfoByDoffUid;
FlawFilterPiantieqian.uploadPolInfo = uploadPolInfo;

module.exports = {
    initPiantieqianFlawFilterData,
    FlawFilterPiantieqian
};