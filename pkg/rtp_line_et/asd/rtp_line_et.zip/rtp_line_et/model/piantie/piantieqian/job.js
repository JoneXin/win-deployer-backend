'use strict'

const { DataTypes, Model, Op} = require('sequelize');
const { jobInitData} = require('../../common/init_data');

const {
    getMaxJobIdFromSource,
    getLatestJobId,
    getJobInfoByPanelId,
    uploadPolInfo
} = require('../common/job');
class JobPiantieqian extends Model {}

const initPiantieqianJobData = (sequelize_aim) => {
    JobPiantieqian.init(
        ...jobInitData, {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'job',
            timestamps: false
        }
    )
}

JobPiantieqian.getMaxJobIdFromSource = getMaxJobIdFromSource;
JobPiantieqian.getLatestJobId = getLatestJobId;
JobPiantieqian.getJobInfoByPanelId = getJobInfoByPanelId;
JobPiantieqian.uploadPolInfo = uploadPolInfo;

module.exports = {
    JobPiantieqian,
    initPiantieqianJobData
};