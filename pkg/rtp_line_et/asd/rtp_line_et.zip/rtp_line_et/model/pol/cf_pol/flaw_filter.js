'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {flawFilterInitData} = require('../../common/init_data');
class FlawFilterCfPol extends Model {}
const {
    getMaxPanelUid,
    getNewsFlawFilterInfoFromLineDb,
    getLatestFlawFilterId,
    getMaxPanelIdFromFlawFilter,
    getFlawFilterInfoByPanelId,
    uploadPolInfo,
    getAllFlawType
} = require('../common/flaw_filter');

const initCfPolFlawFilterData = (sequelize_aim) => {
    FlawFilterCfPol.init(
        ...flawFilterInitData,
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'flaw_filter',
            timestamps: false
        }
    )
}

FlawFilterCfPol.getMaxPanelUid = getMaxPanelUid;
FlawFilterCfPol.getNewsFlawFilterInfoFromLineDb = getNewsFlawFilterInfoFromLineDb;
FlawFilterCfPol.getLatestFlawFilterId = getLatestFlawFilterId;
FlawFilterCfPol.getMaxPanelIdFromFlawFilter = getMaxPanelIdFromFlawFilter;
FlawFilterCfPol.getFlawFilterInfoByPanelId = getFlawFilterInfoByPanelId;
FlawFilterCfPol.uploadPolInfo = uploadPolInfo;
FlawFilterCfPol.getAllFlawType = getAllFlawType;

module.exports = {
    initCfPolFlawFilterData,
    FlawFilterCfPol
};