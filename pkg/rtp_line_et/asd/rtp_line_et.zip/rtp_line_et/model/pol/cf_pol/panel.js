/**
 * @file {cf_pol目标库flaw表model}
 */
'use strict'

const { Model } = require('sequelize');
const { panelInitData } = require('../../common/init_data');
class PanelCfPol extends Model { }
const {
    getNewsPanelInfoFromLineDb,
    getMaxUidfromSourcePanel,
    getLatestPanelId,
    getLatestPanel,
    uploadPolInfo,
    updateDetectParam
} = require('../common/panel');
const { reWriteOtherChecked } = require('../../common/rewirte_check');
const initCfPolPanelData = (sequelize_aim) => {
    PanelCfPol.init(
        ...panelInitData,
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'panel',
            timestamps: false
        }
    )
}
PanelCfPol.getNewsPanelInfoFromLineDb = getNewsPanelInfoFromLineDb;
PanelCfPol.getMaxUidfromSourcePanel = getMaxUidfromSourcePanel;
PanelCfPol.getLatestPanelId = getLatestPanelId;
PanelCfPol.getLatestPanel = getLatestPanel;
PanelCfPol.uploadPolInfo = uploadPolInfo;
PanelCfPol.updateDetectParam = updateDetectParam;
PanelCfPol.reWriteChecked = reWriteOtherChecked;
module.exports = {
    PanelCfPol,
    initCfPolPanelData
};