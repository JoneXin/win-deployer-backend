'use strict'
const { formatDate } = require('../../../uitls/tool')
// 查询目标库某片的缺陷信息
const getNewsPanelInfoFromLineDb = async (sequelize_aim, panelId) => {
    let sql = `select * from flaw where panel_id = ${panelId}`;
    let res = await sequelize_aim.query(sql, { type: sequelize_aim.QueryTypes.SELECT });
    return res[0];
}

// 查询目标库flaw最新uid
const getLatestFlawId = async (sequelize_aim) => {
    let sql = 'select max(uid) as uid from flaw';
    let res = await sequelize_aim.query(sql, { type: sequelize_aim.QueryTypes.SELECT });
    return res[0].uid;
}

/**
 * 查询某片的缺陷信息
 * @param {sequelize} sequelize_source
 * @param {string | number} queryStr panelId | uid
 * @returns 缺陷信息
 */
const getFlawInfoByPanelId = async (sequelize_source, sequelize_source_ipu, queryStr, stationName) => {
    // 根据panelId 查询缺陷信息
    if (typeof queryStr === 'string') {
        let res_panel = await sequelize_source.query(`select uid as id from sheet where panel_id = '${queryStr}' order by uid desc limit 1`, { type: sequelize_source.QueryTypes.SELECT });
        queryStr = res_panel.length ? res_panel[0].id : 1;
    }
    // 没有panel_id的sheet缺陷信息不同步
    let panelIdInfo = await sequelize_source.query(`select panel_id from sheet where uid = ${queryStr} order by uid desc limit 1`, { type: sequelize_source.QueryTypes.SELECT });
    if (!panelIdInfo[0] || !panelIdInfo[0].panel_id) return [];

    // job 信息
    let resJob = await sequelize_source.query(`select job_id from sheet where uid = ${queryStr}`, { type: sequelize_source.QueryTypes.SELECT })

    // 根据 sheet_uid 这片的缺陷信息
    let sql_flaw = `select uid, job_id, sheet_id as panel_table_uid, class_id as flaw_class_type, center_pos_md, 
     center_pos_cd, length_md, length_cd, gen_time, gen_time_str, camera_id, flaw_uuid from flaw where sheet_id = ${queryStr} and job_id = ${resJob[0].job_id}`;
    let sql_panel = `select panel_id, head_md from sheet where uid = ${queryStr} order by uid desc limit 1`;

    let res_flaw = await sequelize_source.query(sql_flaw, { type: sequelize_source.QueryTypes.SELECT });
    // 这片上有缺陷
    if (res_flaw.length) {
        let uuidArr = res_flaw.map(v => v.flaw_uuid);
        let uuidObj = await getIPURelationFlawInfo(sequelize_source_ipu, uuidArr);
        if (uuidObj == null) {
            console.log("flaw match by uuid error completely so stop at flaw.js on line 42")
            return [];
        }
        let sql_lot = `select lot_number from job where uid = ${res_flaw[0].job_id}`;
        let res_lot = await sequelize_source.query(sql_lot, { type: sequelize_source.QueryTypes.SELECT });
        let res_panel = await sequelize_source.query(sql_panel, { type: sequelize_source.QueryTypes.SELECT });
        // 这片上的其他信息都是完整的lot_id, panel_id
        if (res_lot.length && res_panel.length) {
            return res_flaw.map(item => {
                return {
                    ...item,
                    // TODO flaw_class_type: Number(item.flaw_class_type),
                    flaw_class_type: item.flaw_class_type + '__' + stationName,
                    center_pos_md: Number(item.center_pos_md) - res_panel[0].head_md, // md 值基于当前切割膜起点的位置
                    gen_time_str: formatDate(item.gen_time),
                    center_pos_cd: Number(item.center_pos_cd),
                    lot_id: res_lot[0].lot_number,
                    panel_id: res_panel[0].panel_id,
                    contours: uuidObj[item.flaw_uuid].contour_list,
                    area: uuidObj[item.flaw_uuid].area,
                    diameter: uuidObj[item.flaw_uuid].diameter,
                    save_path: uuidObj[item.flaw_uuid].flaw_dat_path,
                    ex_info: JSON.stringify({
                        ...JSON.parse(uuidObj[item.flaw_uuid].ex_info),
                        flaw_uuid: item.flaw_uuid,
                        ex_info: JSON.parse(uuidObj[item.flaw_uuid].ex_info)
                    }),
                }
            })
        } else {
            console.log(`job_name丢失 p`);
            return [];
        }
    } else {
        return [];
    }
}
/**
 * 获取ipu数据库中flaw表的uuid对应的信息
 * 并转化为uuid为key的对象
 * @param {*} sequelizeObj
 * @param {*} uuidArr
 * @returns
 */
// const getIPURelationFlawInfo = async (sequelizeObj, uuidArr) => {
//     const sql = `select contour_list, flaw_dat_path, area, diameter, flaw_uuid, ex_info from flaw where flaw_uuid in (:uuidArr)`
//     const data = await sequelizeObj.query(sql, {
//         replacements: {
//             uuidArr: uuidArr
//         },
//         type: sequelizeObj.QueryTypes.SELECT
//     });
//     if (data && data.length > 0) {
//         return data.reduce((tol, cur) => {
//             tol[cur.flaw_uuid] = cur;
//             return tol;
//         }, {})
//     }
//     return null;
// }

/**
 * 获取ipu数据库中flaw表的uuid对应的信息
 * 并转化为uuid为key的对象
 * @param {*} sequelizeObj
 * @param {*} uuidArr
 * @returns
 */
const getIPURelationFlawInfo = async (sequelizeObj, uuidArr) => {
    let data = [];
    let res = null;
    try {
        let tasks = await genIPUTask(sequelizeObj, uuidArr);
        res = await Promise.allSettled(tasks);
    } catch {
        console.log("query flaw error");
    }
    res &&
        res.forEach((v) => {
            if (v.status == "fulfilled") data.push(...v.value);
        });

    if (data && data.length > 0) {
        return data.reduce((tol, cur) => {
            tol[cur.flaw_uuid] = cur;
            return tol;
        }, {})
    }
    return null;
}

const genIPUTask = async (sequelize_ipu, uuidArr) => {

    let arrAll = [];
    let queryHead = "select contour_list, flaw_dat_path, area, diameter, flaw_uuid, ex_info from flaw where flaw_uuid =";
    let len = uuidArr.length;
    if (len < 15) {
        for (let i = 0; i < len; i++) {
            let sql = `${queryHead}'${uuidArr[i]}'`;
            arrAll.push(sql);
        }
    } else {
        let taskLen = Math.ceil(len / 10);
        for (let i = 0; i < taskLen; i++) {
            let arr = [];
            let restLen = len - i * 10 >= 10 ? 10 : len - i * 10;
            for (let j = 0; j < restLen; j++) {
                let sql = `${queryHead}'${uuidArr[i * 10 + j]}'`;
                arr.push(sql);
            }
            let unionSql = arr.join(" UNION ALL ");
            arrAll.push(unionSql);
        }
    }
    let sqlLen = arrAll.length;
    let result = [];
    for (let i = 0; i < sqlLen; i++) {
        let temp = new Promise((resolve) => {
            sequelize_ipu
                .query(arrAll[i], {
                    replacements: {
                        arr: uuidArr,
                    },
                    raw: true,
                    type: sequelize_ipu.QueryTypes.SELECT,
                })
                .then((res) => {
                    resolve(res);
                })
                .catch((e) => {
                    resolve("err message " + e.message);
                });
        });
        result.push(temp);
    }
    return result;

}

const uploadPolInfo = async (FlawPol, data) => {
    // ignoreDuplicates: 忽略重复数据
    let res = await FlawPol.bulkCreate(data, {
        updateOnDuplicate: ['uid', 'panel_id', 'job_id', 'center_pos_md', 'center_pos_cd', 'length_md', 'length_cd', ' save_path', ' gen_time', ' gen_time_str', 'contours', 'ui_show_text', 'diameter', 'flaw_class_type', 'lot_id']
    });
    return res;
}

module.exports = {
    getNewsPanelInfoFromLineDb,
    getLatestFlawId,
    getFlawInfoByPanelId,
    uploadPolInfo
};
