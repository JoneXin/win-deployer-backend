/**
 * @file {cf_pol目标库flaw表model}
 */
'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {flawInitData} = require('../../common/init_data');
class FlawTftPol extends Model { }
const {
    getNewsPanelInfoFromLineDb,
    getLatestFlawId,
    getFlawInfoByPanelId,
    uploadPolInfo
} = require('../common/flaw');

const initTftPolFlawData = (sequelize_aim) => {
FlawTftPol.init(
    ...flawInitData,
    {
        freezeTableName: true,
        sequelize: sequelize_aim,
        modelName: 'flaw',
        timestamps: false
    }
    )
}
FlawTftPol.getNewsPanelInfoFromLineDb = getNewsPanelInfoFromLineDb;
FlawTftPol.getLatestFlawId = getLatestFlawId;
FlawTftPol.getFlawInfoByPanelId = getFlawInfoByPanelId;
FlawTftPol.uploadPolInfo = uploadPolInfo;

module.exports = {
    FlawTftPol,
    initTftPolFlawData
};