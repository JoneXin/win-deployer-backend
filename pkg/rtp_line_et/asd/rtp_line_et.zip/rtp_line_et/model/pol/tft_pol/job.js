/**
 * @file {cf_pol目标库flaw表model}
 */
'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {jobInitData} = require('../../common/init_data');
class JobTftPol extends Model { }
const {
    getMaxUidfromSourceJob,
    getLatestJobId,
    getJobInfoByPanelId,
    uploadPolInfo,
    getPanelExistJobInfo
} = require('../common/job');

const initTftPolJobData = (sequelize_aim) => {
JobTftPol.init(
        ...jobInitData,
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'job',
            timestamps: false
        }
    )
}

JobTftPol.getMaxUidfromSourceJob = getMaxUidfromSourceJob;
JobTftPol.getLatestJobId = getLatestJobId;
JobTftPol.getJobInfoByPanelId = getJobInfoByPanelId;
JobTftPol.uploadPolInfo = uploadPolInfo;
JobTftPol.getPanelExistJobInfo = getPanelExistJobInfo;
module.exports = {
    JobTftPol,
    initTftPolJobData
};