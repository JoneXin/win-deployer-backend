/**
 * @file {目检 工站的flaw_filter model}
 */
'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const { flawFilterInitData } = require('../common/init_data');
class FlawFilterMujian extends Model { }

const initFlawFilterData = (sequelize_aim) => {
    FlawFilterMujian.init(
        {
            id: {
                field: 'id',
                type: DataTypes.BIGINT(11),
                allowNull: false,
                primaryKey: true,
                autoIncrement: true,
            },
            panel_id: {
                field: 'panel_id',
                type: DataTypes.STRING,
            },
            panel_table_uid: {
                field: 'panel_table_uid',
                type: DataTypes.INTEGER,
            },
            flaw_class_type: {
                field: 'flaw_class_type',
                type: DataTypes.STRING,
            },
            station_id: {
                field: 'station_id',
                type: DataTypes.INTEGER,
            },
            station_name: {
                field: 'station_name',
                type: DataTypes.STRING,
            },
            show: {
                field: 'show',
                type: DataTypes.STRING,
            },
            flaw_count: {
                field: 'flaw_count',
                type: DataTypes.INTEGER,
            },
            symbol: {
                field: 'symbol',
                type: DataTypes.STRING,
            },
            color: {
                field: 'color',
                type: DataTypes.STRING,
            },
            shape: {
                field: 'shape',
                type: DataTypes.INTEGER,
            },
            sync_db: {
                field: 'sync_db',
                type: DataTypes.STRING,
            },
            sync_id: {
                field: 'sync_id',
                type: DataTypes.STRING,
            }

        },
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'flaw_filter',
            timestamps: false
        }
    )
}
/**
 *上传到产线flaw_filter 表
 * @param {Object} data 转换后上传的数据对象
 */
FlawFilterMujian.uploadInfo = async (data) => {
    let res = await FlawFilterMujian.bulkCreate(data, { ignoreDuplicates: true });
    return res;
}

module.exports = {
    initFlawFilterData,
    FlawFilterMujian
};