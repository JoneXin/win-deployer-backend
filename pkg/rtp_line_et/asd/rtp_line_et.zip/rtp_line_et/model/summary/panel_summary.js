/**
 * @file {目检 目标库panel表model}
 */
'use strict'

const { Model, DataTypes } = require('sequelize');
const { panelInitData } = require('../common/init_data');
class PanelMujian extends Model { }
const { reWriteSummaryChecked } = require('../common/rewirte_check');

/**
 * @desc 映射需要的字段 【源库的 部分字段 --> 目标库字段】
 */
const initPanelData = (sequelize_aim) => {
    PanelMujian.init(
        {
            uid: {
                field: 'uid',
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true
            },
            flaw_count: {
                field: 'flaw_count',
                type: DataTypes.INTEGER
            },
            panel_id: {
                field: 'panel_id',
                type: DataTypes.STRING
            },
            panel_uuid: {
                field: 'panel_uuid',
                type: DataTypes.STRING
            },
            is_ok: {
                field: 'is_ok',
                type: DataTypes.INTEGER
            },
            length_md: {
                field: 'length_md',
                type: DataTypes.BIGINT
            },
            length_cd: {
                field: 'length_cd',
                type: DataTypes.INTEGER
            },
            checked: {
                field: 'checked',
                type: DataTypes.INTEGER
            },
            start_time: {
                field: 'start_time',
                type: DataTypes.INTEGER
            },
            start_time_str: {
                field: 'start_time_str',
                type: DataTypes.STRING
            },
            finish_time: {
                field: 'finish_time',
                type: DataTypes.INTEGER
            },
            finish_time_str: {
                field: 'finish_time_str',
                type: DataTypes.STRING
            },
            detectParam: {
                field: 'detectParam',
                type: DataTypes.TEXT
            }
        },
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'panel_summary',
            timestamps: false
        }
    )
}
/**
 * 上传panel
 * @param {Object} data 上传的panel信息对象
 * @returns
 */
PanelMujian.uploadInfo = async (data) => {
    let res = await PanelMujian.bulkCreate(data, {
        updateOnDuplicate: ['flaw_count', 'is_ok', 'length_md', 'length_cd', 'start_time', 'start_time_str', 'finish_time', 'finish_time_str', 'checked', 'detectParam']
    });
    return res;
}

PanelMujian.reWriteChecked = reWriteSummaryChecked;

module.exports = {
    PanelMujian,
    initPanelData
};