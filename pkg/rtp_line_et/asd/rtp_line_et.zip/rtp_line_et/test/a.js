
// 偏贴
var save_path = '\\\\192.168.9.6\\webflaw/2021-12-22/local_2021-12-22-11-3-36-575_0_4.dat';
let a = save_path.split("\\");

a[2] = '192.168.0.32';
let b = a.join('\\');

console.log(b);

// pol

let save_path_1 = '//127.0.0.1/rts_flaw_data/2022_02/0c/58/09/14/de/6a/28/cf/70/14/35/44/2d/33/d4/49/0c580914de6a28cf701435442d33d449.dat'

let temp = save_path_1.split("/");

temp[2] = '192.168.0.32';

console.log(temp.join('/'));