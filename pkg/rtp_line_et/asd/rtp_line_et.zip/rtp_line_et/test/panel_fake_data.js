// 1 六个工站生成panel
// 2 调用handle_uuid生成uuid
// 3 起panel_summary的程序同步六个工站数据

let handleUuid = require('../class/summary/handle_uuid');
const { linedb_piantiehou_config, linedb_cf_jingdujiance_config, linedb_cf_pol_config, linedb_piantieqian_config, linedb_tft_jingdujiance_config, linedb_tft_pol_config } = require('../config.json').line_db;
const seqPiantiehou = require('../lib/db').getSequelizeInstance(linedb_piantiehou_config);
const seqPiantieqian = require('../lib/db').getSequelizeInstance(linedb_piantieqian_config);
const seqCfJingdujiance = require('../lib/db').getSequelizeInstance(linedb_cf_jingdujiance_config);
const seqTftJingdujiance = require('../lib/db').getSequelizeInstance(linedb_tft_jingdujiance_config);
const seqCfPol = require('../lib/db').getSequelizeInstance(linedb_cf_pol_config);
const seqTftPol = require('../lib/db').getSequelizeInstance(linedb_tft_pol_config);

let id = 73;
let detectParam = [
    {
        "id": 1,
        "panel_id": "PANLEID12378913",
        "panel_table_uid": 1,
        "flaw_class_type": 3000,
        "show": "失印",
        "color": "#aa0000",
        "symbol": "C",
        "flaw_count": 1,
        "station_id": 1,
        "station_name": "反射",
        "shape": 1,
        "children": [
            {
                "id": 1,
                "panel_id": "PANLEID12378913",
                "panel_table_uid": 1,
                "flaw_class_type": 3001,
                "show": "失印的子缺陷",
                "color": "#aa0000",
                "symbol": "C",
                "flaw_count": 1,
                "station_id": 1,
                "station_name": "反射",
                "shape": 1
            }
        ]
    },
    {
        "id": 1,
        "panel_id": "PANLEID12378913",
        "panel_table_uid": 1,
        "flaw_class_type": 4000,
        "show": "魔豆",
        "color": "#aa0000",
        "symbol": "B",
        "flaw_count": 1,
        "station_id": 2,
        "station_name": "刮伤工位",
        "shape": 2
    },
    {
        "id": 1,
        "panel_id": "PANLEID12378913",
        "panel_table_uid": 1,
        "flaw_class_type": 5000,
        "show": "白点",
        "color": "#aa0000",
        "symbol": "A",
        "flaw_count": 1,
        "station_id": 3,
        "station_name": "透射工位",
        "shape": 3
    }
]
setInterval(async () => {
    let panelId = 'PANELID0000' + id++;
    let lengthMd = parseInt(30000 * Math.random());
    let lengthCd = parseInt(10000 * Math.random());
    console.log('start insert');
    await seqPiantieqian.query(`insert into panel(job_id, panel_id, flaw_count, is_ok, length_md, length_cd, checked, gen_time, gen_time_str, detectParam) values(888, '${panelId}', ${parseInt(100 * Math.random())}, 0, ${lengthMd}, ${lengthCd}, 0, ${new Date().getTime()}, '${new Date().toLocaleString()}', '${JSON.stringify(detectParam)}')`)
    await handleUuid.addQueue(seqPiantieqian, panelId);
    await seqCfPol.query(`insert into panel(job_id, panel_id, flaw_count, is_ok, length_md, length_cd, checked, gen_time, gen_time_str, detectParam) values(888, '${panelId}', ${parseInt(100 * Math.random())}, 0, ${lengthMd}, ${lengthCd}, 0, ${new Date().getTime()}, '${new Date().toLocaleString()}', '${JSON.stringify(detectParam)}')`)
    await handleUuid.addQueue(seqCfPol, panelId);
    await seqCfJingdujiance.query(`insert into panel(job_id, panel_id, flaw_count, is_ok, length_md, length_cd, checked, gen_time, gen_time_str, detectParam) values(888, '${panelId}', ${parseInt(100 * Math.random())}, 0, ${lengthMd}, ${lengthCd}, 0, ${new Date().getTime()}, '${new Date().toLocaleString()}', '${JSON.stringify(detectParam)}')`)
    await handleUuid.addQueue(seqCfJingdujiance, panelId);
    await seqTftPol.query(`insert into panel(job_id, panel_id, flaw_count, is_ok, length_md, length_cd, checked, gen_time, gen_time_str, detectParam) values(888, '${panelId}', ${parseInt(100 * Math.random())}, 0, ${lengthMd}, ${lengthCd}, 0, ${new Date().getTime()}, '${new Date().toLocaleString()}', '${JSON.stringify(detectParam)}')`)
    await handleUuid.addQueue(seqTftPol, panelId);
    await seqTftJingdujiance.query(`insert into panel(job_id, panel_id, flaw_count, is_ok, length_md, length_cd, checked, gen_time, gen_time_str, detectParam) values(888, '${panelId}', ${parseInt(100 * Math.random())}, 0, ${lengthMd}, ${lengthCd}, 0, ${new Date().getTime()}, '${new Date().toLocaleString()}', '${JSON.stringify(detectParam)}')`)
    await handleUuid.addQueue(seqTftJingdujiance, panelId);
    await seqPiantiehou.query(`insert into panel(job_id, panel_id, flaw_count, is_ok, length_md, length_cd, checked, gen_time, gen_time_str, detectParam) values(888, '${panelId}', ${parseInt(100 * Math.random())}, 0, ${lengthMd}, ${lengthCd}, 0, ${new Date().getTime()}, '${new Date().toLocaleString()}', '${JSON.stringify(detectParam)}')`)
    await handleUuid.addQueue(seqPiantiehou, panelId);
}, 10000);