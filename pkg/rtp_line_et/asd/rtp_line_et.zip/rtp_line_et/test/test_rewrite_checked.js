const cleannings = require('../job/cleanning');

cleannings.reWriteAlllibraryChecked('PANELID00002');