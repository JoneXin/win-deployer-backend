'use strict'

const client = require('../lib/ws_client');

let wsClient = client('127.0.0.1', 4000, () => {
    wsClient.client.on('text', (msg) => {
        console.log(msg, '----');
    })

    setInterval(() => {
        wsClient.client.sendText(JSON.stringify({
            cmd: "panelId",
            content: {
                panelId: `panelId`
            }
        }))
    }, 1000)

});