const { v1, v4 } = require('uuid');
console.log(v1().replace(/-/g, ''));
console.log(v4().replace(/-/g, ''));