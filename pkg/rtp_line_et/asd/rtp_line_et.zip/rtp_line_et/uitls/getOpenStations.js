'use strict'

const { cube_station_db } = require('../config.json');
const seq_lia_web = require('../lib/db').getSequelizeInstance(cube_station_db);

/**
 * 请求要同步的工站信息
 * @returns 工站信息数组
 */
module.exports = async () => {
    try {
        let opStations = await seq_lia_web.query(`select * from cube_rtp_station where is_open = 1`, { type: seq_lia_web.QueryTypes.SELECT });
        // console.log(opStations);
        return opStations.length ? opStations : [];
    } catch (error) {
        console.log(error);
        return [];
    }
}