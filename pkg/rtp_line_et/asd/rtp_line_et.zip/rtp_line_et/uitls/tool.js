'use strict';

/**
 * 去重，然后统计每种缺陷的数量
 * @param {Array} data
 * @returns
 */
function transformData(data) {
    let map = new Map();

    for (let i = 0; i < data.length; i++) {
        if (map.has(data[i].flaw_class_type)) {
            map.set(data[i].flaw_class_type, {
                ...data[i],
                flaw_count: ++map.get(data[i].flaw_class_type).flaw_count,
            });
        } else {
            map.set(data[i].flaw_class_type, {
                ...data[i],
                flaw_count: 1,
            });
        }
    }
    return map;
}

/**
 * 把扁平话的数组 转成 有父子关系的数组
 * @param {*} flawFilterArr
 */
function formatFlawFilterData(flawFilterArr, is_pol) {
    let resultData = [];
    let map = new Map();
    flawFilterArr.forEach(item => {
        // 整型的flaw_class_type， 工站别名
        const t = item.flaw_class_type.split('__');
        const [old_flaw_class_type, station_alias] = item.flaw_class_type.split('__');
        // 转为父节点key 1637__pth -> 1600__pth
        const fatherKey = Math.floor(old_flaw_class_type / 100) * 100 + '__' + station_alias;
        // 当前节点属于父节点
        const isFatherNode = old_flaw_class_type % 100 == 0;
        // 第一次添加父节点
        if (!map.has(fatherKey)) {
            // 当前节点就是父节点
            if (isFatherNode) {
                map.set(fatherKey, {
                    ...item,
                    children: []
                })
            }
            // 当前节点为子节点 且并无父节点
            else {
                !is_pol ? map.set(fatherKey, {
                    flaw_class_type: fatherKey,
                    children: [item],
                    flaw_count: item.flaw_count,
                }) : map.set(fatherKey, {
                    flaw_class_type: fatherKey,
                    children: [item],
                    flaw_count: item.flaw_count,
                    symbol: item.fa_symbol,
                    show: item.fa_show,
                    shape: 8,
                })
            }
        }
        // 已经缓存过父节点
        else {
            // 当前节点为父节点
            if (isFatherNode) {
                map.set(fatherKey, {
                    ...item,
                    ...map.get(fatherKey)
                });
            }
            // 子节点
            else {
                const fatherNode = map.get(fatherKey);
                fatherNode.children.push(item);
                fatherNode.flaw_count += item.flaw_count;
            }
        }
    })
    for (const item of map) {
        resultData.push(item[1]);
    }
    return resultData;
}

/**
 * @param {时间戳} date
 * @returns 格式化后的时间
 */
function formatDate(date) {
    let time = new Date(date);
    let minites = time.getMinutes() < 10 ? `0${time.getMinutes()}` : time.getMinutes();
    let seconds = time.getSeconds() < 10 ? `0${time.getSeconds()}` : time.getSeconds();
    return `${time.toLocaleDateString()} ${time.getHours()}:${minites}:${seconds}`;
}

/**
 * 将pol的缺陷分类信息（test/test_rts_detect.json） 转换成
 * 数组形式 [{ flaw_class_type:'', symbol: '', show: '', color: '', shape: ''}]
 * @param {JSON} detect pol 的缺陷分类json
 */
function parseDetectParam(detectParam, stationName) {
    try {
        const detect = JSON.parse(detectParam);
        let flawTypeArr = [];
        let flawTypeObj = {};

        for (const fClass in detect) {
            const group = detect[fClass];
            const typeName = group.group_name;
            for (const cClass in group.sub_class) {
                const group_child = group.sub_class[cClass];
                // if (group_child.is_shown || group_child.enable) {
                    flawTypeArr.push({
                        // TODO flaw_class_type: cClass,
                        flaw_class_type: cClass + '__' + stationName,
                        show: typeName + group_child.type_name,
                        symbol: group_child.show_name,
                        color: '#FF0000',
                        shape: 8,
                        fa_show: typeName,
                        fa_symbol: group.show_name || ''
                    })

                    flawTypeObj[cClass + '__' + stationName] = {
                        flaw_class_type: cClass + '__' + stationName,
                        show: typeName + group_child.type_name,
                        symbol: group_child.show_name,
                        color: '#FF0000',
                        shape: 8
                    }
                // }
            }
        }
        return { flawTypeArr, flawTypeObj };
    } catch (_) {
        console.log(_);
        return []
    }
}

/**
 * 判断字符串是否以某字符结尾
 * 返回Boolean
 */
function isEndWith(string, sub) {
    if (typeof string != "string" || typeof sub != "string" || string.length < sub.length) {
        return false;
    }
    var index = string.length - sub.length;
    return (index >= 0 && string.lastIndexOf(sub) == index);
}

module.exports = {
    transformData,
    formatFlawFilterData,
    formatDate,
    parseDetectParam,
    isEndWith
};
