
class Tools {

    static piantieqian = {};  // 缺陷类型转成k-v
    static piantiehou = {};  // 缺陷类型转成k-v
    static cf_pol = {};  // 缺陷类型转成k-v
    static tft_pol = {};  // 缺陷类型转成k-v

    static currentParentShowAttr = '';
    constructor() { };

    /**
     * 解析偏贴站的 缺陷分裂
     * @param {*} detectParam
     */
    static getPtStationFlawTypeObj(detectParam, stationAlias, stationName) {
        try {
            let flawTypeObj = JSON.parse(detectParam);
            Tools.handTranformData(flawTypeObj, stationAlias, stationName);
            return Tools[stationName];
        } catch (error) {
            console.log(error);
            return {};
        }
    }

    /**
     * 递归转换缺陷类型
     */
    static handTranformData(data, stationAlias, stationName) {
        for (const key in data) {
            if (key === 'Attributes') {

                // 父缺陷 记住缺陷名
                if (data[key].id % 100 == 0) {
                    Tools.currentParentShowAttr = data[key].show;
                }

                Tools[stationName][data[key].id + '__' + stationAlias] = {
                    show: data[key].id % 100 == 0 ? data[key].show : `${this.currentParentShowAttr}_${data[key].show}`,
                    symbol: data[key].symbol,
                    color: data[key].color,
                    shape: data[key].shape
                };

            }
            if (
                key !== 'Attributes' &&
                Object.prototype.toString.call(data[key]) === '[object Object]'
            ) {
                Tools.handTranformData(data[key], stationAlias, stationName);
            }
        }
    }

    /**
     * 返回旋转过后的坐标集
     * @param {array} flawPoint
     * @param {Object} rotateConf
     * @returns rotatedPoints {x, y}
     */
    static getRotatedFlawPoints(flawPoint, rotateConf) {

        const {rotate, xMirror, height, width} = rotateConf;
        const rotatedPoints = {};

         // 90 deg
         if (rotate == 0) {
            rotatedPoints.x = flawPoint.x;
            rotatedPoints.y = flawPoint.y;
        }

        // 90 deg
        if (rotate == 90) {
            rotatedPoints.x = height - flawPoint.y;
            rotatedPoints.y = flawPoint.x;
        }
        // 180 deg
        if (rotate == 180) {
            rotatedPoints.x = width - flawPoint.x;
            rotatedPoints.y = height - flawPoint.y;
        }
        // 270 deg
        if (rotate == 270) {
            rotatedPoints.x = flawPoint.y;
            rotatedPoints.y = width - flawPoint.x;
        }

        if (xMirror == 'true') {
            rotatedPoints.y = (rotate % 180 == 0 ? (height - flawPoint.y) : ( width - flawPoint.x));
        }

        // 镜像
        return {
            x: parseFloat(rotatedPoints.x).toFixed(3),
            y: parseFloat(rotatedPoints.y).toFixed(3)
        };
    }
}

module.exports = Tools;
