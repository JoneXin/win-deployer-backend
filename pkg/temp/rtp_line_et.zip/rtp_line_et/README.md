### 启动
`node index.js`

### 项目的配置文件详情

-   `station_db`
    源库 db 配置

-   `line_db`
    产线库 db 配置

-   `web_socket_config`
    websocket IP 端口配置

-   `cube _station_db`
    动态工站同步数据库配置

-   `plc_socket_list`
    plc 的 TCP 通信配置

-   `plc_request_timeout`
    PLC 的请求间隔

-   `rewrite_timeout`
    回写checked间隔
