'use strict';

const schedule = require('node-schedule');
let handleUuid = require('../summary/handle_uuid');
const queue = require('queue');
const db = require('../../lib/db');
const Tools = require('../../uitls/tools');

class JingduBase {

    constructor(PanelAimCfJingdu, stationInfo, PanelSourceCfJingdu, seqSource, seqAim, logger, sourceIp, startPosition, rotateConf) {
        this.PanelAimCfJingdu = PanelAimCfJingdu;
        this.PanelSourceCfJingdu = PanelSourceCfJingdu;
        this.stationName = stationInfo.station_name_standard;
        this.stationInfo = stationInfo;
        this.sequelize_src = seqSource;
        this.sequelize_aim = seqAim;
        this.currentPanel = null;
        this.panelUid = null;
        this.taskQueue = queue({ concurrency: 1, autostart: true });
        this.timeDelay = '*/2 * * * * *';
        this.logger = logger;
        this.sourceIp = sourceIp;
        this.startPosition = startPosition;
        this.fourCorners = [{
            key: 'lt',
        }, {
            key: 'lb',
        }, {
            key: 'rb',
        }, {
            key: 'rt',
        }]
        this.rotateConf = rotateConf;
        this.init();
    }

    async init() {
        try {

            // 查询中间库的最新同步位置
            this.panelUid = await this.PanelAimCfJingdu.getNewsSyncPanel();

            // 从最初开始同步()
            if (this.panelUid == 1) {
                this.panelUid = this.startPosition.panelUid;
            }
        } catch (error) {
            this.logger.err(error);
        }
        schedule.scheduleJob(this.timeDelay, () => {
            this.addTaskQueue();
        })
    }

    // push task queue
    addTaskQueue() {
        // 判断长度动态改版shceduleJob的时间延迟
        this.taskQueue.push(async cb => {
            await this.handPanel();
            cb()
        })
    }

    // 同步panel信息
    async handPanel() {
        try {
            // 获取源库的panel信息
            const oldPanelInfo = await this.PanelSourceCfJingdu.getPanelInfoByUid(this.panelUid);
            if (oldPanelInfo) {
                // 旋转
                let panelInfo = this.rotatePanel(oldPanelInfo, this.rotateConf);
                // 上传到中间库
                await this.postDataToLineDb(this.PanelAimCfJingdu, {
                    ...panelInfo,
                    checked: 0,
                    ex_info: JSON.stringify([{
                        auto_result: panelInfo.auto_result,
                        manual_result: panelInfo.manual_result,
                        are_auto_manual_results_same: panelInfo.are_auto_manual_results_same,
                        is_lt_x_ok: panelInfo.is_lt_x_ok,
                        is_lt_y_ok: panelInfo.is_lt_y_ok,
                        is_lb_x_ok: panelInfo.is_lb_x_ok,
                        is_lb_y_ok: panelInfo.is_lb_y_ok,
                        is_rt_x_ok: panelInfo.is_rt_x_ok,
                        is_rt_y_ok: panelInfo.is_rt_y_ok,
                        is_rb_x_ok: panelInfo.is_rb_x_ok,
                        is_rb_y_ok: panelInfo.is_rb_y_ok,
                    }]),
                    save_path: panelInfo.save_path ? `http://${this.sourceIp}:3144/${panelInfo.save_path.slice(3)}` : ''
                });
                this.logger.info(`${this.stationName}--uid: ${this.panelUid}同步成功!`);
                delete panelInfo.auto_result;
                delete panelInfo.manual_result;
                delete panelInfo.are_auto_manual_results_same;
                delete panelInfo.is_lt_x_ok;
                delete panelInfo.is_lt_y_ok;
                delete panelInfo.is_lb_x_ok;
                delete panelInfo.is_lb_y_ok;
                delete panelInfo.is_rt_x_ok;
                delete panelInfo.is_rt_y_ok;
                delete panelInfo.is_rb_x_ok;
                delete panelInfo.is_rb_y_ok;
               
                const flaw_class_type = `10000__${this.stationInfo.station_select_alias || this.stationInfo.station_name}`
                const panelAllInfo = {
                    panelInfo: {
                        ...panelInfo,
                        checked: 0,
                        save_path: panelInfo.save_path ? `http://${this.sourceIp}:3144/${panelInfo.save_path.slice(3)}` : '',
                    },
                    flawInfo: [],
                    flawFilterInfo: [{
                        ...panelInfo,
                        "flaw_class_type": flaw_class_type,
                        "panel_table_uid": panelInfo.uid,
                        "panel_id": panelInfo.panel_id,
                        "flaw_count": 0,
                        "color": "red",
                        "show": "精度检测",
                        "shape": 3, // 空心圆
                        "symbol": "⚪"
                    }]
                }
                this.fourCorners.forEach(item => {
                    if (panelInfo[`is_ok_${item.key}`] === 0) {
                        let center_pos_cd, center_pos_md;
                        if (item.key === 'lt') {
                            [center_pos_cd, center_pos_md] = [0, 0];
                        } else if (item.key === 'lb') {
                            [center_pos_cd, center_pos_md] = [0, 1];
                        } else if (item.key === 'rb') {
                            [center_pos_cd, center_pos_md] = [1, 1];
                        } else if (item.key === 'rt') {
                            [center_pos_cd, center_pos_md] = [1, 0];
                        }

                        // 旋转flaw
                        // const rotatePoints = Tools.getRotatedFlawPoints(
                        //     {
                        //         x: center_pos_cd,
                        //         y: center_pos_md
                        //     },
                        //     {
                        //         rotate: this.rotateConf.rotate,
                        //         xMirror: this.rotateConf.xMirror,
                        //         height: 1,
                        //         width: 1
                        //     }
                        // )
                        panelAllInfo.flawFilterInfo[0].flaw_count++;
                        const save_path = panelInfo[`save_path_${item.key}`] ? `http://${this.sourceIp}:3144/${panelInfo[`save_path_${item.key}`].slice(3)}` : '';
                        panelAllInfo.flawInfo.push({
                            ...panelInfo,
                            job_id: panelInfo.job_id,
                            // center_pos_cd: rotatePoints.x,
                            // center_pos_md: rotatePoints.y,
                            center_pos_cd,
                            center_pos_md,
                            flaw_class_type: flaw_class_type,
                            gen_time: panelInfo.gen_time,
                            save_path: save_path,
                            panel_id: panelInfo.panel_id,
                            gen_time_str: panelInfo.gen_time_str,
                            panel_tabel_id: panelInfo.uid,
                            show: '精度检测',
                            ui_show_text: '⚪',
                            ex_info: JSON.stringify({
                                symbolSize: 20,
                            })
                        })
                    }
                });
                panelAllInfo.panelInfo.detectParam = JSON.stringify([panelAllInfo.flawFilterInfo[0]])
                // 处理uuid
                handleUuid.addQueue(this.sequelize_aim, panelInfo.panel_id, this.stationName, panelAllInfo);
            }
            // 查询源库的最新同步位置
            let maxPanelSourceUid = await this.PanelSourceCfJingdu.getMaxUidFromSource();
            if (this.panelUid < maxPanelSourceUid) {
                this.panelUid++;
            } else {
                this.logger.info(`已同步到最新的位置--uid:${this.panelUid}`);
            }
        } catch (_) {
            this.logger.err(_);
        }
    }

    /**
     * 旋转片
     * @param {Object} panelInfo
     * @param {Object} rotateConf
     * @return newsPanelInfo
     */
    rotatePanel(panelInfo, rotateConf) {
        let newsPanelInfo = Object.assign({}, panelInfo);
        const { rotate, xMirror } = rotateConf;

        // 90 deg
        if (rotate == 90) {
            // 精度值变换
            newsPanelInfo.lt_x = panelInfo.lb_y;
            newsPanelInfo.lt_y = panelInfo.lb_x;

            newsPanelInfo.rt_x = panelInfo.lt_y;
            newsPanelInfo.rt_y = panelInfo.lt_x;

            newsPanelInfo.rb_x = panelInfo.rt_y;
            newsPanelInfo.rb_y = panelInfo.rt_x;

            newsPanelInfo.lb_x = panelInfo.rb_y;
            newsPanelInfo.lb_y = panelInfo.rb_x;
            // ok情况变换
            newsPanelInfo.is_ok_lt = panelInfo.is_ok_lb;
            newsPanelInfo.is_ok_rt = panelInfo.is_ok_lt;
            newsPanelInfo.is_ok_rb = panelInfo.is_ok_rt;
            newsPanelInfo.is_ok_lb = panelInfo.is_ok_rb;

            // 精度检测的值 - 新字段也需要变化

            newsPanelInfo.is_lt_x_ok = panelInfo.is_lb_y_ok;
            newsPanelInfo.is_lt_y_ok = panelInfo.is_lb_x_ok;

            newsPanelInfo.is_rt_x_ok = panelInfo.is_lt_y_ok;
            newsPanelInfo.is_rt_y_ok = panelInfo.is_lt_x_ok;

            newsPanelInfo.is_rb_x_ok = panelInfo.is_rt_y_ok;
            newsPanelInfo.is_rb_y_ok = panelInfo.is_rt_x_ok;

            newsPanelInfo.is_lb_x_ok = panelInfo.is_rb_y_ok;
            newsPanelInfo.is_lb_y_ok = panelInfo.is_rb_x_ok;

        }
        // 180 deg
        if (rotate == 180) {
            // 精度值变换
            newsPanelInfo.lt_x = panelInfo.rb_x;
            newsPanelInfo.lt_y = panelInfo.rb_y;

            newsPanelInfo.rt_x = panelInfo.lb_x;
            newsPanelInfo.rt_y = panelInfo.lb_y;

            newsPanelInfo.rb_x = panelInfo.lt_x;
            newsPanelInfo.rb_y = panelInfo.lt_y;

            newsPanelInfo.lb_x = panelInfo.rt_x;
            newsPanelInfo.lb_y = panelInfo.rt_y;
            // ok情况变换
            newsPanelInfo.is_ok_lt = panelInfo.is_ok_rb;
            newsPanelInfo.is_ok_rt = panelInfo.is_ok_lb;
            newsPanelInfo.is_ok_rb = panelInfo.is_ok_lt;
            newsPanelInfo.is_ok_lb = panelInfo.is_ok_rt;

            // 精度检测的值 - 新字段也需要变化
            newsPanelInfo.is_lt_x_ok = panelInfo.is_rb_x_ok;
            newsPanelInfo.is_lt_y_ok = panelInfo.is_rb_y_ok;

            newsPanelInfo.is_rt_x_ok = panelInfo.is_lb_x_ok;
            newsPanelInfo.is_rt_y_ok = panelInfo.is_lb_y_ok;

            newsPanelInfo.is_rb_x_ok = panelInfo.is_lt_x_ok;
            newsPanelInfo.is_rb_y_ok = panelInfo.is_lt_y_ok;

            newsPanelInfo.is_lb_x_ok = panelInfo.is_rt_x_ok;
            newsPanelInfo.is_lb_y_ok = panelInfo.is_rt_y_ok;


        }
        // 270 deg
        if (rotate == 270) {
            // 精度值变换
            newsPanelInfo.lt_x = panelInfo.rt_y;
            newsPanelInfo.lt_y = panelInfo.rt_x;

            newsPanelInfo.rt_x = panelInfo.rb_y;
            newsPanelInfo.rt_y = panelInfo.rb_x;

            newsPanelInfo.rb_x = panelInfo.lb_y;
            newsPanelInfo.rb_y = panelInfo.lb_x;

            newsPanelInfo.lb_x = panelInfo.lt_y;
            newsPanelInfo.lb_y = panelInfo.lt_x;
            // ok情况变换
            newsPanelInfo.is_ok_lt = panelInfo.is_ok_rt;
            newsPanelInfo.is_ok_rt = panelInfo.is_ok_rb;
            newsPanelInfo.is_ok_rb = panelInfo.is_ok_lb;
            newsPanelInfo.is_ok_lb = panelInfo.is_ok_lt;
            // 精度检测的值 - 新字段也需要变化
            newsPanelInfo.is_lt_x_ok = panelInfo.is_rt_y_ok;
            newsPanelInfo.is_lt_y_ok = panelInfo.is_rt_x_ok;

            newsPanelInfo.is_rt_x_ok = panelInfo.is_rb_y_ok;
            newsPanelInfo.is_rt_y_ok = panelInfo.is_rb_x_ok;

            newsPanelInfo.is_rb_x_ok = panelInfo.is_lb_y_ok;
            newsPanelInfo.is_rb_y_ok = panelInfo.is_lb_x_ok;

            newsPanelInfo.is_lb_x_ok = panelInfo.is_lt_y_ok;
            newsPanelInfo.is_lb_y_ok = panelInfo.is_lt_x_ok;
        }

        // 上下变换
        if (xMirror == 'true') {
            // 精度值变换
            newsPanelInfo.lt_x = panelInfo.lb_x;
            newsPanelInfo.lt_y = panelInfo.lb_y;

            newsPanelInfo.rt_x = panelInfo.rb_x;
            newsPanelInfo.rt_y = panelInfo.rb_y;

            newsPanelInfo.rb_x = panelInfo.rt_x;
            newsPanelInfo.rb_y = panelInfo.rt_y;

            newsPanelInfo.lb_x = panelInfo.lt_x;
            newsPanelInfo.lb_y = panelInfo.lt_y;
            // ok情况变换
            newsPanelInfo.is_ok_lt = panelInfo.is_ok_lb;
            newsPanelInfo.is_ok_rt = panelInfo.is_ok_rb;
            newsPanelInfo.is_ok_rb = panelInfo.is_ok_rt;
            newsPanelInfo.is_ok_lb = panelInfo.is_ok_lt;

            // 精度检测的值 - 新字段也需要变化

            newsPanelInfo.is_lt_x_ok = panelInfo.is_lb_x_ok;
            newsPanelInfo.is_lt_y_ok = panelInfo.is_lb_y_ok;

            newsPanelInfo.is_rt_x_ok = panelInfo.is_rb_x_ok;
            newsPanelInfo.is_rt_y_ok = panelInfo.is_rb_y_ok;

            newsPanelInfo.is_rb_x_ok = panelInfo.is_rt_x_ok;
            newsPanelInfo.is_rb_y_ok = panelInfo.is_rt_y_ok;

            newsPanelInfo.is_lb_x_ok = panelInfo.is_lt_x_ok;
            newsPanelInfo.is_lb_y_ok = panelInfo.is_lt_y_ok;

        }

        return newsPanelInfo;
    }

    /**
     * 上传data到产线db的指定表中
     * @param {} operatorName 表的操作对象
     * @param {Object} data 上传的数据
     */
    async postDataToLineDb(operatorName, data) {
        // 存进目标库
        try {
            let res = await operatorName.upload(data);
            if (res.dataValues || res.length) {
                return true;
            } else {
                return false;
            }
        } catch (error) {
            this.logger.err(error);
            return false;
        }
    }
}

module.exports = JingduBase;
