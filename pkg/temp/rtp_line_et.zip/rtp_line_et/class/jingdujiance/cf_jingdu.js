
'use strict'

const JingduBase = require('./base');
const { station_db, jingdu_table_name } = require('../../config.json')
const { start_position } = require('../../config.json');
const { xlog, path } = require('xlog');
const logger = new xlog({
    projectName: 'rtp_line_et',
    httpConf: {
        aimIp: '127.0.0.1',
        aimPort: 4499
    },
    filePath: path.join(__dirname, '../../logs'),
    category: ['jingdu', 'cf_jingdu'],
    logsName: 'cf_jingdu',
    logging: true
});

class SynchronizeCfJingdu extends JingduBase {

    constructor(panel, stationInfo, PanelSourceCfJingdu, seqSource, seqAim, rotateConf) {
        super(panel, stationInfo, PanelSourceCfJingdu, seqSource, seqAim, logger, station_db.cf_jingdu_db_config.host, start_position.cf_jindu, rotateConf);
    }
    static getInstance(panel, stationInfo, PanelSourceCfJingdu, seqSource, seqAim, rotateConf) {
        if (SynchronizeCfJingdu.instance) {
            return SynchronizeCfJingdu.instance;
        } else {
            SynchronizeCfJingdu.instance = new SynchronizeCfJingdu(panel, stationInfo, PanelSourceCfJingdu, seqSource, seqAim, rotateConf);
            return SynchronizeCfJingdu.instance;
        }
    }
    /**
     * 根据panel获取全部信息
     * @param {String} panel_id
     */
    async getNewstInfoByPanelId(panel_id) {
        try {
            let panel_info = await this.sequelize_src.query(`select panel_id , save_path , is_ok , gen_time , gen_time_str from ${jingdu_table_name} where panel_id = "${panel_id}" order by uid DESC limit 1`, { type: this.sequelize_src.QueryTypes.SELECT });
            if (panel_info.length) {
                return {
                    ...panel_info[0],
                    save_path: panelInfo[0].save_path ? `http://${cf_jingdu_db_config.host}:3144/${panelInfo[0].save_path.slice(3)}` : ''
                };
            }
            return null;
        } catch (error) {
            console.log(error);
            return null;
        }
    }
}

module.exports = SynchronizeCfJingdu;
