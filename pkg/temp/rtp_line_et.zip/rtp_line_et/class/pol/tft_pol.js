/**
 * @file {同步tft_pol 精度检测工位数据}
 */
'use strict'

const PolBase = require('./base');
const { initTftPolFlawData } = require('../../model/pol/tft_pol/flaw');
const { initTftPolFlawFilterData } = require('../../model/pol/tft_pol/flaw_filter');
const { initTftPolJobData } = require('../../model/pol/tft_pol/job');
const { initTftPanelData } = require('../../model/pol/tft_pol/panel');
const { start_position } = require('../../config.json');
const { xlog, path } = require('xlog');
const logger = new xlog({
    projectName: 'rtp_line_et',
    filePath: path.join(__dirname, '../../logs'),
    category: ['pol', 'tft_pol'],
    logsName: 'tft_pol',
    logging: true
});
const { station_db, tft_pol_gap_num } = require('../../config.json')
class SynchronizeTftPol extends PolBase {

    constructor(tableModel, sequelize_source, sequelize_source_ipu, sequelize_aim, stationInfo, rotateConf) {
        initTftPolFlawData(sequelize_aim);
        initTftPolFlawFilterData(sequelize_aim);
        initTftPolJobData(sequelize_aim);
        initTftPanelData(sequelize_aim);
        super(tableModel, sequelize_source, sequelize_source_ipu, sequelize_aim, stationInfo, logger, start_position.tft_pol, station_db.tft_pol_new_db_config.host, tft_pol_gap_num, rotateConf);
    }
    /**
     * 初始化参数
     * @param {Object} 各个表的模型
     * @param {Sequeliz} sequelize_source 源表的sequelize实例
     * @param {Sequeliz} sequelize_aim 目标表的sequelize实例
     * @param {string} stationName 工站名（便于日志区分）
     * @returns
     */
    static getInstance(tableModel, sequelize_source, sequelize_source_ipu, sequelize_aim, stationInfo, rotateConf) {
        if (SynchronizeTftPol.instance) {
            return SynchronizeTftPol.instance;
        } else {
            SynchronizeTftPol.instance = new SynchronizeTftPol(tableModel, sequelize_source, sequelize_source_ipu, sequelize_aim, stationInfo, rotateConf);
            return SynchronizeTftPol.instance;
        }
    }
    /**
    * 根据panel获取全部信息
    * @param {String} panel_id
    * @returns Object | null
    */
    async getNewstInfoByPanelId(panel_id) {
        try {
            let panel_info = await this.handPanelInfo(panel_id);
            let job_info = await this.handJobInfo(panel_id);
            let flaw_info = await this.handFlawInfo(panel_id);
            let flaw_filter_info = await this.handFlawFilterInfo(panel_id);
            // console.log(flaw_filter_info);
            let stations = flaw_filter_info.map((item) => {
                return {
                    station_id: item.station_id,
                    station_name: item.station_name
                }
            })
            let result = stations.filter(item => {
                return item.station_id;
            })
            return {
                panel_info,
                job_info,
                flaw_info,
                flaw_filter_info,
                stations: result
            }
        } catch (error) {
            console.log(error);
            return null;
        }
    }
    // 回写checked字段
    async reWriteChecked(panelId) {
        try {
            let res = await this.PanelPol.reWriteChecked(this.PanelPol, panelId);
            if (res[0] && res[0].dataValues) {
                console.log(`${this.stationName} Panel checked回写成功!`);
            }
        } catch (error) {
            console.log(error);
        }
    }
}

module.exports = SynchronizeTftPol;
