const { linedb_piantiehou_config, linedb_cf_jingdujiance_config, linedb_cf_pol_config, linedb_piantieqian_config, linedb_tft_jingdujiance_config, linedb_tft_pol_config, linedb_summary_config } = require('../../config.json').line_db;
const seqPiantiehou = require('../../lib/db').getSequelizeInstance(linedb_piantiehou_config);
const seqPiantieqian = require('../../lib/db').getSequelizeInstance(linedb_piantieqian_config);
// const seqCfJingdujiance = require('../../lib/db').getSequelizeInstance(linedb_cf_jingdujiance_config);
// const seqTftJingdujiance = require('../../lib/db').getSequelizeInstance(linedb_tft_jingdujiance_config);
const seqCfPol = require('../../lib/db').getSequelizeInstance(linedb_cf_pol_config);
const seqTftPol = require('../../lib/db').getSequelizeInstance(linedb_tft_pol_config);
const seqRtpSummary = require('../../lib/db').getSequelizeInstance(linedb_summary_config);
const flawModel = require('../../model/summary/flaw');
const getOpenstaions = require('../../uitls/getOpenStations');

class flaw {
    constructor() {
        // 初始化model
        flawModel.initFlawMujinaData(seqRtpSummary);

        // 同步数据库的配置，可放在json文件中
        this.syncFlawConfig = {
            syncLimit: 50
        };

        // seq实例的列表，严格按照先后顺序配置，后续的更新顺序会按照这个顺序来
        this.seqInstanceList = [
            {
                name: 'rtp_piantieqian',
                instance: seqPiantieqian,
                stationName: 'piantieqian'
            },
            {
                name: 'rtp_tft_pol',
                instance: seqTftPol,
                stationName: 'tft_pol'
            },
            {
                name: 'rtp_cf_pol',
                instance: seqCfPol,
                stationName: 'cf_pol'
            },
            {
                name: 'rtp_piantiehou',
                instance: seqPiantiehou,
                stationName: 'piantiehou'
            }
        ];
        this.init();
    }

    async init() {
        let openStations = await getOpenstaions();
        // 动态指定同步工站
        this.seqInstanceList = this.seqInstanceList.filter(item => {
            for (let i = 0; i < openStations.length; i++) {
                if (openStations[i].station_name == item.stationName) {
                    return true;
                }
            }
        })
        console.log(`flaw的汇总工站列表${this.seqInstanceList}`);
    }

    static getInstance() {
        if (!flaw.instance) {
            flaw.instance = new flaw();
        }
        return flaw.instance;
    }

    // 处理flaw的同步
    handleSyncToFlaw = async () => {
        try {
            // 1. 查询rtp_summary的flawr表,根据 sync_db 与 sync_id 确定哪个数据库从哪儿开始同步
            let allFlawUuidList = [];
            let syncFlawList = [];

            for (const seqInfo of this.seqInstanceList) {
                let syncId = await this.getNewestSyncIdBySyncDb(seqInfo.name);
                // 2. 通过panel_table_uid 与 panel表uid的 建立左外连接
                let flawInfo = await this.getFlawInfoByJoinPanel(seqInfo.instance, syncId.length ? syncId[0].sync_id : 0);
                // console.log(flawInfo);

                // 3. 判断每个panel_uuid是否存在（不存在就停止后续）
                if (flawInfo.length == 0) continue;
                //      两个逻辑：
                //          先 判断是否是数据缺失(当前没有panel.uid，并且panel.uid不是panel数据库的最后一条) return true; 接着下面的插入数据
                //          再 判断是否panel_uuids生成,生成就return true;接着下面的插入数据
                //         其实总结起来就是只有(item.panelUid存在并且item.panel_uuid也存在) 或者(item.panelUid不存在,并且不是panel的最后一条数据) 这两种情况 才能继续
                let lastPanelUidRes = await seqInfo.instance.query(`select uid from panel order by uid desc limit 1`, { type: seqInfo.instance.QueryTypes.SELECT })
                if (!flawInfo.every(item => {
                    if (item.panelUid && item.panel_uuid) return true;
                    if (!item.panelUid && item.panel_table_uid < lastPanelUidRes[0].uid) {
                        console.log(`${seqInfo.name}库 的panel表缺少uid为${item.panel_table_uid}的数据`);
                        return true;
                    }
                    console.log(`看到这个log表示flaw中的table_uid已经存在，但是panel信息还没同步过来`);
                    return false;
                })) continue;

                // 加入更新信息列表中
                flawInfo.map(item => {
                    item.sync_db = seqInfo.name;
                    item.sync_id = item.uid;
                    delete item.uid;
                });
                syncFlawList.push(...flawInfo);
                const flawUuidList = flawInfo.map(item => item.panel_uuid);
                allFlawUuidList.push(...flawUuidList);

            }

            // 如果没有数据就return
            if (syncFlawList.length == 0) return true;

            // 4. 通过panel_uuid去 rtp_summary库的panel_summary表中查询uid
            let allFlawUuidSet = new Set(allFlawUuidList);
            allFlawUuidSet.delete(null);
            allFlawUuidList = [...allFlawUuidSet];
            // console.log(allFlawUuidList);
            let panelUuidInfo = await this.getPanelSummaryUidByPanelUuid(allFlawUuidList);
            // console.log(panelUuidInfo);
            // console.log(syncFlawList);

            // 5. 将uid的值写入要更新的字段panel_table_uid中
            //     5.1 修改更新的数据和格式
            //      将panel_table_uid 替换、 删除panel_uuid 字段
            syncFlawList.map(item => {
                item.panel_table_uid = panelUuidInfo[item.panel_uuid] || null;
                delete item.panel_uuid;
                delete item.panelUid;
            });
            // console.log(syncFlawList);
            await flawModel.FlawMujian.uploadInfo(syncFlawList);
            return true;
        } catch (error) {
            console.log(error);
            return false;
        }
    }

    // flaw 与 panel 建立左外连接的信息
    getFlawInfoByJoinPanel = async (seqInstance, syncId) => {
        let sql = 'SELECT flaw.uid,flaw.job_id,flaw.panel_id,flaw.panel_table_uid,center_pos_md,center_pos_cd,flaw.length_md,flaw.length_cd,contours,flaw.gen_time,flaw.gen_time_str,flaw.save_path,ui_show_text,area,diameter,camera_id,flaw_class_type,flaw.lot_id,panel_uuid, panel.uid as panelUid FROM flaw LEFT JOIN panel ON flaw.panel_table_uid = panel.uid WHERE flaw.uid > ' + syncId + ' ORDER BY flaw.uid LIMIT ' + this.syncFlawConfig.syncLimit;
        let res = await seqInstance.query(sql, { type: seqInstance.QueryTypes.SELECT });
        return res;
    }

    // 根据panel_uuid获取rtp_summary数据库的 panel_summary表中的uuid
    getPanelSummaryUidByPanelUuid = async (flawUuidList) => {
        if (!flawUuidList.length) return {};
        // 处理语句格式变成 panel_id1,panel_id2,panel_id3,......
        const uuidIn = flawUuidList.length > 1 ? flawUuidList.reduce((acc, cur, idx) => idx == 1 ? "'" + acc + "','" + cur + "'" : acc + ",'" + cur + "'") : `'${flawUuidList[0] || ''}'`;
        let res = await seqRtpSummary.query(`select uid,panel_uuid from panel_summary where panel_uuid in (${uuidIn})`, { type: seqRtpSummary.QueryTypes.SELECT });
        let rtn = {};
        res.forEach(item => {
            rtn[item.panel_uuid] = item.uid;
        });
        return rtn;
    }

    // 查询flaw_filter 中某个sync_db的最新的sync_id
    getNewestSyncIdBySyncDb = async (syncDb) => {
        let res = await seqRtpSummary.query(`SELECT sync_id FROM flaw WHERE sync_db = '${syncDb}' ORDER BY uid DESC LIMIT 1`, { type: seqRtpSummary.QueryTypes.SELECT });
        return res;
    }
}

module.exports = flaw.getInstance();