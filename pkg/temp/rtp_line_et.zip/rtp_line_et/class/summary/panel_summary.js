const { linedb_piantiehou_config, linedb_cf_jingdujiance_config, linedb_cf_pol_config, linedb_piantieqian_config, linedb_tft_jingdujiance_config, linedb_tft_pol_config, linedb_summary_config } = require('../../config.json').line_db;
const seqPiantiehou = require('../../lib/db').getSequelizeInstance(linedb_piantiehou_config);
const seqPiantieqian = require('../../lib/db').getSequelizeInstance(linedb_piantieqian_config);
const seqCfJingdujiance = require('../../lib/db').getSequelizeInstance(linedb_cf_jingdujiance_config);
const seqTftJingdujiance = require('../../lib/db').getSequelizeInstance(linedb_tft_jingdujiance_config);
const seqCfPol = require('../../lib/db').getSequelizeInstance(linedb_cf_pol_config);
const seqTftPol = require('../../lib/db').getSequelizeInstance(linedb_tft_pol_config);
const seqRtpSummary = require('../../lib/db').getSequelizeInstance(linedb_summary_config);
const seqModleRtpSummary = require('../../model/summary/panel_summary');
const getOpenstaions = require('../../uitls/getOpenStations');

class panelSummary {
    constructor() {
        // 初始化model
        seqModleRtpSummary.initPanelData(seqRtpSummary);

        // 同步数据库的配置，可放在json文件中
        this.syncPanelSummaryConfig = {
            syncLimit: 200
        };

        // seq实例的列表，严格按照先后顺序配置，后续的更新顺序会按照这个顺序来
        this.seqInstanceList = [
            {
                name: 'seqPiantieqian',
                instance: seqPiantieqian,
                stationName: 'piantieqian'
            },
            {
                name: 'seqTftPol',
                instance: seqTftPol,
                stationName: 'tft_pol'
            },
            {
                name: 'seqTftJingdujiance',
                instance: seqTftJingdujiance,
                stationName: 'tft_jingdu'
            },
            {
                name: 'seqCfPol',
                instance: seqCfPol,
                stationName: 'cf_pol'
            },
            {
                name: 'seqCfJingdujiance',
                instance: seqCfJingdujiance,
                stationName: 'cf_jingdu'
            },
            {
                name: 'seqPiantiehou',
                instance: seqPiantiehou,
                stationName: 'piantiehou'
            }
        ];
        this.init();
    }

    async init() {
        let openStations = await getOpenstaions();
        // 动态指定同步工站 （最多循环 6 * 7 = 42次）
        this.seqInstanceList = this.seqInstanceList.filter(item => {
            for (let i = 0; i < openStations.length; i++) {
                if (openStations[i].station_name == item.stationName) {
                    return true;
                }
            }
        })
    }

    static getInstance() {
        if (!panelSummary.instance) {
            panelSummary.instance = new panelSummary();
        }
        return panelSummary.instance;
    }

    // 处理panel_summary表的同步
    handleSyncToPanelSummary = async () => {
        try {
            // 1. 取出表中的后n个数据
            const panelSummaryUuidRes = await seqRtpSummary.query(`select uid,panel_uuid from panel_summary where panel_uuid is not null and panel_id !='' order by uid desc limit ${this.syncPanelSummaryConfig.syncLimit}`, { type: seqRtpSummary.QueryTypes.SELECT });
            // console.log(panelSummaryUuidRes);

            // 2. 所有的uuid的列表数组
            const panelSummaryUuidList = panelSummaryUuidRes.map(item => item.panel_uuid);
            // console.log(panelSummaryUuidList);

            // 3. 取六个工站的信息, 所有的工站信息添加到数组中，按照先后顺序push，这样取的时候就按照先后顺序判断即可
            let seqResInfo = [];
            for (let i = 0; i < this.seqInstanceList.length; i++) {
                const seqInstance = this.seqInstanceList[i];
                let infoRes = await this.getPanelInfoByUuid(panelSummaryUuidList, seqInstance.instance);
                seqResInfo.push(...infoRes);
            }
            // console.log(seqResInfo);

            // 4. 更新到表中
            let panelSummayUpdateInfo = [];

            panelSummaryUuidRes.forEach(item => {
                // 4.1 每个panel_id依次更新， 取出六个工站中所有这个panel的信息
                let workInstanceInfoList = seqResInfo.filter(panel => panel.panel_uuid == item.panel_uuid);
                console.log("asdasdas",workInstanceInfoList);

                // 4.2 生成更新数组
                //  更新原则为: 
                //      flaw_count 六个工站相加
                //      is_ok 有一个0就是0  (全1为1)
                //      checked 有一个1就是1 (全0为0)
                //      start_time 最早的那个机台时间
                //      finish_time 最晚的那个机台时间
                //      length_md length_cd 最晚的那台机器的
                //      detectParam 合并所有机台数组
                let flawCount = 0;
                let detectParam = workInstanceInfoList.reduce((acc, cur) => {
                    // console.log(cur, '***');
                    // 合并所有的参数
                    let detect;
                    try {
                        detect = JSON.parse(cur.detectParam) || [];
                        // console.log(detect);
                    } catch (error) {
                        console.log('detectParam 转json失败');
                        console.log(error);
                        detect = [];
                    }
                    return acc.concat(detect);
                }, []);
                panelSummayUpdateInfo.push({
                    uid: item.uid,
                    flaw_count: workInstanceInfoList.reduce((acc, cur) => acc + (Number(cur.flaw_count) || 0), flawCount),
                    is_ok: workInstanceInfoList.every(item => item.is_ok == 1) ? 1 : 0,
                    checked: workInstanceInfoList.every(item => item.checked == 0) ? 0 : 1,
                    start_time: workInstanceInfoList[0].gen_time,
                    start_time_str: workInstanceInfoList[0].gen_time_str,
                    finish_time: workInstanceInfoList[workInstanceInfoList.length - 1].gen_time,
                    finish_time_str: workInstanceInfoList[workInstanceInfoList.length - 1].gen_time_str,
                    //TODO:
                    length_md: workInstanceInfoList[workInstanceInfoList.length - 1].length_md,
                    length_cd: workInstanceInfoList[workInstanceInfoList.length - 1].length_cd,
                    // length_md: workInstanceInfoList[0].length_md,
                    // length_cd: workInstanceInfoList[0].length_cd,
                    detectParam: JSON.stringify(detectParam)
                });
            })
            console.log('要更新的数据');
            console.log(panelSummayUpdateInfo);

            // 5 执行更新
            await seqModleRtpSummary.PanelMujian.uploadInfo(panelSummayUpdateInfo);
            return true;
        } catch (error) {
            console.log(error);
            return false;
        }
    }

    // 根据uuid读取panel表
    getPanelInfoByUuid = async (panelSummaryUuidList, seqInstance) => {
        if (panelSummaryUuidList.length == 0) return [];
        // 处理语句格式变成 panel_id1,panel_id2,panel_id3,......
        const uuidIn = panelSummaryUuidList.length > 1 ? panelSummaryUuidList.reduce((acc, cur, idx) => idx == 1 ? "'" + acc + "','" + cur + "'" : acc + ",'" + cur + "'") : `'${panelSummaryUuidList[0]}'`;
        const seqInstanceRes = await seqInstance.query(`select uid,panel_uuid,flaw_count,is_ok,length_md,length_cd,gen_time,gen_time_str,checked,detectParam from panel where panel_uuid in (${uuidIn})`, { type: seqInstance.QueryTypes.SELECT });
        return seqInstanceRes;
    }

    // 回写汇总库checked
    async reWriteChecked(panelId) {
        try {
            let res = await seqModleRtpSummary.PanelMujian.reWriteChecked(seqModleRtpSummary.PanelMujian, panelId);
            if (res[0] && res[0].dataValues) {
                console.log(`汇总库 Panel checked回写成功!`);
                return res[0].panel_uuid;
            } else {
                return false;
            }
        } catch (error) {
            console.log(error);
            return false;
        }
    }
}

module.exports = panelSummary.getInstance();