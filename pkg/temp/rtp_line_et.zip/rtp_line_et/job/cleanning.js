'use strict'

const schedule = require('node-schedule');
const LRU = require("lru-cache");

const handlePanelSummary = require('../class/summary/panel_summary');
// 每一个工站的库实例化
const SynchronizeCfJingdu = require('../class/jingdujiance/cf_jingdu');
const SynchronizeTftJingdu = require('../class/jingdujiance/tft_jingdu');
const SynchronizeCfPol = require('../class/pol/cf_pol');
const SynchronizeTftPol = require('../class/pol/tft_pol');
const SynchronizePiantieqian = require('../class/piantie/piantieqian');
const SynchronizePiantiehou = require('../class/piantie/piantiehou');

const { rewrite_timeout } = require('../config.json');

const {
    piantieqian_db_config,
    piantiehou_db_config,
    cf_pol_new_db_config,
    cf_pol_ipu_db_config,
    tft_pol_new_db_config,
    tft_pol_ipu_db_config
} = require('../config.json').station_db; // 源库
const {
    linedb_piantiehou_config,
    linedb_piantieqian_config,
    linedb_cf_pol_config,
    linedb_tft_pol_config,
    linedb_summary_config
} = require('../config.json').line_db; // 目标库

const seq_src_new_cf_pol = require('../lib/db').getSequelizeInstance(cf_pol_new_db_config);
const seq_src_ipu_cf_pol = require('../lib/db').getSequelizeInstance(cf_pol_ipu_db_config);
const seq_aim_cf_pol = require('../lib/db').getSequelizeInstance(linedb_cf_pol_config);
const seq_src_new_tft_pol = require('../lib/db').getSequelizeInstance(tft_pol_new_db_config);
const seq_src_ipu_tft_pol = require('../lib/db').getSequelizeInstance(tft_pol_ipu_db_config);
const seq_aim_tft_pol = require('../lib/db').getSequelizeInstance(linedb_tft_pol_config);

const seq_src_piantieqian = require('../lib/db').getSequelizeInstance(piantieqian_db_config);
const seq_aim_piantieqian = require('../lib/db').getSequelizeInstance(linedb_piantieqian_config);
const seq_src_piantiehou = require('../lib/db').getSequelizeInstance(piantiehou_db_config);
const seq_aim_piantiehou = require('../lib/db').getSequelizeInstance(linedb_piantiehou_config);

const seq_aim_summray = require('../lib/db').getSequelizeInstance(linedb_summary_config);

// 精度检测工位表实例
const { PanelCfJingdu, seqCfAim } = require('../model/jingdujiance/cf_panel');
const { PanelTftJingdu, seqTftAim } = require('../model/jingdujiance/tft_panel');
const { PanelSourceCfJingdu, seqCfSource } = require('../model/jingdujiance/cf_jingdu_source');
const { PanelSourceTftJingdu, seqTftSource } = require('../model/jingdujiance/tft_jingdu_source');

// CF_POL工位表实例
const { FlawCfPol } = require('../model/pol/cf_pol/flaw');
const { FlawFilterCfPol } = require('../model/pol/cf_pol/flaw_filter');
const { JobCfPol } = require('../model/pol/cf_pol/job');
const { PanelCfPol } = require('../model/pol/cf_pol/panel');
// TGT_POL
const { FlawTftPol } = require('../model/pol/tft_pol/flaw');
const { FlawFilterTftPol } = require('../model/pol/tft_pol/flaw_filter');
const { JobTftPol } = require('../model/pol/tft_pol/job');
const { PanelTftPol } = require('../model/pol/tft_pol/panel');

// 偏贴前
const { FlawPiantieqian } = require('../model/piantie/piantieqian/flaw');
const { FlawFilterPiantieqian } = require('../model/piantie/piantieqian/flaw_filter');
const { JobPiantieqian } = require('../model/piantie/piantieqian/job');
const { PanelPiantieqian } = require('../model/piantie/piantieqian/panel');
// 偏贴后
const { FlawPiantiehou } = require('../model/piantie/piantiehou/flaw');
const { FlawFilterPiantiehou } = require('../model/piantie/piantiehou/flaw_filter');
const { JobPiantiehou } = require('../model/piantie/piantiehou/job');
const { PanelPiantiehou } = require('../model/piantie/piantiehou/panel');

// 获取open状态的工站信息
const getOpenStationList = require('../uitls/getOpenStations');

// 缓存偏贴后 新增的片
const options = {
    max: 500,
    maxAge: 1000 * 60 * 60
}
const { xlog, path } = require('xlog');
const logger = new xlog({
    projectName: 'rtp_line_et',
    filePath: path.join(__dirname, '../../logs'),
    category: ['job', 'cleanning'],
    logsName: 'cleanning',
    logging: true
});

class Cleanning {

    constructor() {
        this.timmer = null;
        this.curentPanel = null;
        this.curentPanel_cache = null;
        this.reCheckqueue = []; // 回写checked字段队列
        // 初始化缓存
        this.cache = new LRU(options);
        this.rotateMap = new Map();
        this.init();
    }

    async init() {

        // 查询需要同步的工站信息
        this.syncStationList = await getOpenStationList();
        if (!this.syncStationList.length) return false;
        logger.info('同步工站列表:', this.syncStationList);

        // 查询各个工站旋转角度
        await this.getRotateAngle();

        // 开启指定工站的同步任务
        this.syncStationList.forEach(stationInfo => {

            // this.tft_jingdu = SynchronizeTftJingdu.getInstance(PanelTftJingdu, 'TFT 精度检测', PanelSourceTftJingdu, seqTftSource, seqTftAim);
            // return
            if (stationInfo.station_name == 'piantieqian') {
                // 标准工站名称
                stationInfo.station_name_standard = 'piantieqian';
                this.piantieqian = SynchronizePiantieqian.getInstance(
                    { 
                        FlawPiantieqian, 
                        FlawFilterPiantieqian, 
                        JobPiantieqian,
                        PanelPiantieqian 
                    }, 
                    seq_src_piantieqian, 
                    seq_aim_piantieqian, 
                    stationInfo,
                    this.rotateMap.get('piantieqian')
                );
            }
            else if (stationInfo.station_name == 'tft_pol') {
                stationInfo.station_name_standard = 'tft_pol';
                this.tft_pol = SynchronizeTftPol.getInstance(
                    { 
                        FlawTftPol, 
                        FlawFilterTftPol, 
                        JobTftPol,
                        PanelTftPol 
                    }, 
                    seq_src_new_tft_pol, 
                    seq_src_ipu_tft_pol, 
                    seq_aim_tft_pol, 
                    stationInfo,
                    this.rotateMap.get('tft_pol')
                );
            }
            else if (stationInfo.station_name == 'tft_jingdu') {
                stationInfo.station_name_standard = 'tft_jingdu';
                this.tft_jingdu = SynchronizeTftJingdu.getInstance(
                    PanelTftJingdu, 
                    stationInfo, 
                    PanelSourceTftJingdu, 
                    seqTftSource, 
                    seqTftAim,
                    this.rotateMap.get('tft_jingdu')
                );
            }
            else if (stationInfo.station_name == 'cf_pol') {
                stationInfo.station_name_standard = 'cf_pol';
                this.cf_pol = SynchronizeCfPol.getInstance(
                    { 
                        FlawCfPol, 
                        FlawFilterCfPol, 
                        JobCfPol,
                        PanelCfPol 
                    }, 
                    seq_src_new_cf_pol, 
                    seq_src_ipu_cf_pol, 
                    seq_aim_cf_pol, 
                    stationInfo,
                    this.rotateMap.get('cf_pol')
                );
            }
            else if (stationInfo.station_name == 'cf_jingdu') {
                stationInfo.station_name_standard = 'cf_jingdu';
                this.cf_jingdu = SynchronizeCfJingdu.getInstance(
                    PanelCfJingdu, 
                    stationInfo, 
                    PanelSourceCfJingdu, 
                    seqCfSource, 
                    seqCfAim,
                    this.rotateMap.get('cf_jingdu')
                );
            }
            else if (stationInfo.station_name == 'piantiehou') {
                stationInfo.station_name_standard = 'piantiehou';
                this.piantiehou = SynchronizePiantiehou.getInstance(
                    { 
                        FlawPiantiehou, 
                        FlawFilterPiantiehou, 
                        JobPiantiehou,
                        PanelPiantiehou 
                    }, 
                    seq_src_piantiehou, 
                    seq_aim_piantiehou, 
                    stationInfo,
                    this.rotateMap.get('piantiehou')
                );
            }
        })

        // 延时5分钟回写checked 字段，防止目检命中 回写时汇总信息还没上来的情况，重启的时候会漏掉内存
        this.timmer && clearTimeout(this.timmer);
        this.timmer = setTimeout(() => {
            this.reWriteAlllibraryChecked();
        }, rewrite_timeout)
    }

    /**
     * getAllRotateList
     * @returns [] 各个工站旋转角度list
     */
    async getRotateAngle () {
        let rotateList = await seq_aim_summray.query(`select * from station_rotate_set where is_open = 1`, { type: seq_aim_summray.QueryTypes.SELECT });
        
        rotateList.map(item => {
            this.rotateMap.set(item.station, {rotate: item.rotate, xMirror: item.turn})
        })
    }

    // 汇总6站信息
    getSummaryInfo(piantieqian_info, cf_pol_info, cf_jingdu_info, tft_pol_info, tft_jingdu_info, piantiehou_info, flaw_count_all) {

        let okStatus = 1;
        let panelSummry = null; // 汇总片  从最后一站往前推，找到第一个存在的站
        let flawSummary = []; // 汇总flaw
        let flawFilterSummary = []; // 汇总flawFilter
        let stationSummary = []; // 汇总station
        // 偏贴前
        if (piantieqian_info) {
            panelSummry = piantieqian_info.panel_info;
            flawSummary = flawSummary.concat(piantieqian_info.flaw_info);
            flawFilterSummary = flawFilterSummary.concat(piantieqian_info.flaw_filter_info);
            stationSummary = stationSummary.concat(piantieqian_info.stations);
        }
        // tft_pol
        if (tft_pol_info) {
            panelSummry = tft_pol_info.panel_info;
            flawSummary = flawSummary.concat(tft_pol_info.flaw_info);
            flawFilterSummary = flawFilterSummary.concat(tft_pol_info.flaw_filter_info);
            stationSummary = stationSummary.concat(tft_pol_info.stations);
        }
        // tft_精度
        if (tft_jingdu_info) {
            panelSummry = tft_jingdu_info;
            okStatus = tft_jingdu_info.is_ok && okStatus
        }
        // cf_pol
        if (cf_pol_info) {
            panelSummry = cf_pol_info.panel_info;
            flawSummary = flawSummary.concat(cf_pol_info.flaw_info);
            flawFilterSummary = flawFilterSummary.concat(cf_pol_info.flaw_filter_info);
            stationSummary = stationSummary.concat(cf_pol_info.stations);
        }
        // cf 精度
        if (cf_jingdu_info) {
            panelSummry = cf_jingdu_info;
            okStatus = cf_jingdu_info.is_ok && okStatus;
        }
        // 偏贴后
        if (piantiehou_info) {
            panelSummry = piantiehou_info.panel_info;
            flawSummary = flawSummary.concat(piantiehou_info.flaw_info);
            flawFilterSummary = flawFilterSummary.concat(piantiehou_info.flaw_filter_info);
            stationSummary = stationSummary.concat(piantiehou_info.stations);
        }
        // 汇总ok状态
        if (flaw_count_all) {
            okStatus = okStatus && 0;
        }

        return {
            panel_info: {
                ...panelSummry,
                is_ok: okStatus,
                flaw_count: flaw_count_all
            },
            flaw_info: flawSummary,
            flaw_filter_info: flawFilterSummary,
            stations: stationSummary,
        }
    }

    /**
     * 回写 checked 悉知:
     * 1，在没启动本脚本但是 又被目检过的片，不会回写checked字段
     * 2，此脚本启动时间 - 源库启动时间 > 20分钟的片，不会回写checked字段
     */
    // 回写所有中间库的checked字段
    async reWriteAlllibraryChecked() {
        const job = schedule.scheduleJob('*/4 * * * * *', async () => {
            // 查询汇总库是是否存在这一片，不存在跳过，存在从汇总库拿这片的uuid 回写checked到其余6个库中
            try {
                // 如果回写队列有要回写的字段
                if (this.reCheckqueue.length) {
                    let panelId = this.reCheckqueue.shift();
                    // 判断汇总表中是否存在着一片，存在取最新片的uuid 回写所有站的checked字段
                    let panel_uuid = await handlePanelSummary.reWriteChecked(panelId);
                    if (panel_uuid) {
                        this.piantieqian.reWriteChecked(panel_uuid);
                        this.piantiehou.reWriteChecked(panel_uuid);
                        this.cf_pol.reWriteChecked(panel_uuid);
                        this.tft_pol.reWriteChecked(panel_uuid);
                    } else {
                        logger.info(`汇总库无此片信息，将跳过回写panelId: ${panelId}的片checked字段!`);
                    }
                }
            } catch (error) {
                logger.info(error);
            }
        })
    }


    static getInstance() {
        if (Cleanning.instance) {
            return Cleanning.instance;
        } else {
            Cleanning.instance = new Cleanning();
            return Cleanning.instance;
        }
    }
}

module.exports = Cleanning;
