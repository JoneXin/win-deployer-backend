'use strict';

const handleFlawFilter = require('../class/summary/flaw_filter');
const handlePanelSummary = require('../class/summary/panel_summary');
const handleFlaw = require('../class/summary/flaw');
const schedule = require('node-schedule');
const queue = require('queue');
class LibrarySummary {

    constructor() {
        this.taskQueue_panel = queue({ concurrency: 1, autostart: true });
        this.taskQueue_flawFilter = queue({ concurrency: 1, autostart: true });
        this.taskQueue_flaw = queue({ concurrency: 1, autostart: true });
        this.timeDelay = '*/1 * * * * *';
        this.init();
    }

    async init() {
        // 汇总 flaw_filter flaw  panel 三张表表到 rtp_summary库
        schedule.scheduleJob(this.timeDelay, () => {
            this.addTaskQueue();
        });
    }
    // push task queue
    addTaskQueue() {
        // 判断长度动态改版shceduleJob的时间延迟
        this.taskQueue_panel.push(async cb => {
            await handlePanelSummary.handleSyncToPanelSummary();
            cb();
        })
        this.taskQueue_flawFilter.push(async cb => {
            await handleFlawFilter.handleSyncToFlawFilter();
            cb();
        })
        this.taskQueue_flaw.push(async cb => {
            await handleFlaw.handleSyncToFlaw();
            cb();
        })
    }
    static getInstance() {
        if (LibrarySummary.instance) {
            return LibrarySummary.instance;
        } else {
            LibrarySummary.instance = new LibrarySummary();
            return LibrarySummary.instance;
        }
    }
}

LibrarySummary.getInstance();
