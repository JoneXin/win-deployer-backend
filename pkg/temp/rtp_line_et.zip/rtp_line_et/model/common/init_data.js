/**
 * @file {初始化表的}
 */
const { DataTypes } = require('sequelize');

// Job表初始化的数据
const jobInitData = [
    {
        uid: {
            field: 'uid',
            type: DataTypes.BIGINT(11),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        job_name: {
            field: 'job_name',
            type: DataTypes.STRING,
        },
        panel_sum: {
            field: 'panel_sum',
            type: DataTypes.INTEGER
        },
        ok_number: {
            field: 'ok_number',
            type: DataTypes.INTEGER
        },
        ng_number: {
            field: 'ng_number',
            type: DataTypes.INTEGER
        },
        start_time: {
            field: 'start_time',
            type: DataTypes.BIGINT
        },
        finish_time: {
            field: 'finish_time',
            type: DataTypes.BIGINT
        },
        start_time_str: {
            field: 'start_time_str',
            type: DataTypes.STRING
        },
        finish_time_str: {
            field: 'finish_time_str',
            type: DataTypes.STRING
        },
        order_number: {
            field: 'order_number',
            type: DataTypes.STRING
        }
    }
]

//  flaw表初始化数据
const flawInitData = [
    {
        uid: {
            field: 'uid',
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        job_id: {
            field: 'job_id',
            type: DataTypes.INTEGER,
        },
        panel_id: {
            field: 'panel_id',
            type: DataTypes.STRING,
        },
        panel_table_uid: {
            field: 'panel_table_uid',
            type: DataTypes.INTEGER,
        },
        class_id: {
            field: 'class_id',
            type: DataTypes.INTEGER,
        },
        center_pos_md: {
            field: 'center_pos_md',
            type: DataTypes.INTEGER,
        },
        center_pos_cd: {
            field: 'center_pos_cd',
            type: DataTypes.INTEGER,
        },
        length_md: {
            field: 'length_md',
            type: DataTypes.INTEGER,
        },
        length_cd: {
            field: 'length_cd',
            type: DataTypes.INTEGER,
        },
        contours: {
            field: 'contours',
            type: DataTypes.TEXT,
        },
        gen_time: {
            field: 'gen_time',
            type: DataTypes.BIGINT,
        },
        gen_time_str: {
            field: 'gen_time_str',
            type: DataTypes.STRING,
        },
        save_path: {
            field: 'save_path',
            type: DataTypes.STRING,
        },
        ui_show_text: {
            field: 'ui_show_text',
            type: DataTypes.STRING,
        },
        area: {
            field: 'area',
            type: DataTypes.INTEGER,
        },
        diameter: {
            field: 'diameter',
            type: DataTypes.INTEGER,
        },
        camera_id: {
            field: 'camera_id',
            type: DataTypes.INTEGER,
        },
        flaw_class_type: {
            field: 'flaw_class_type',
            type: DataTypes.STRING,
        },
        lot_id: {
            field: 'lot_id',
            type: DataTypes.STRING,
        },
        show: {
            field: 'show',
            type: DataTypes.STRING,
        },
        ex_info: {
            field: 'ex_info',
            type: DataTypes.TEXT
        }
    },
]

// panel表初始化数据
const panelInitData = [
    {
        uid: {
            field: 'uid',
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        job_id: {
            field: 'job_id',
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: false
        },
        panel_id: {
            field: 'panel_id',
            type: DataTypes.STRING
        },
        flaw_count: {
            field: 'flaw_count',
            type: DataTypes.INTEGER
        },
        is_ok: {
            field: 'is_ok',
            type: DataTypes.INTEGER
        },
        length_md: {
            field: 'length_md',
            type: DataTypes.INTEGER
        },
        length_cd: {
            field: 'length_cd',
            type: DataTypes.INTEGER
        },
        save_path: {
            field: 'save_path',
            type: DataTypes.STRING
        },
        gen_time: {
            field: 'gen_time',
            type: DataTypes.BIGINT
        },
        gen_time_str: {
            field: 'gen_time_str',
            type: DataTypes.STRING
        },
        detectParam: {
            field: 'detectParam',
            type: DataTypes.TEXT
        },
        checked: {
            field: 'checked',
            type: DataTypes.INTEGER
        },
        lot_id: {
            field: 'lot_id',
            type: DataTypes.STRING
        },
        ex_info: {
            field: 'ex_info',
            type: DataTypes.TEXT
        }
    },
]

// flaw_filter 表初始化数据
const flawFilterInitData = [
    {
        id: {
            field: 'id',
            type: DataTypes.BIGINT(11),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        panel_id: {
            field: 'panel_id',
            type: DataTypes.STRING,
        },
        panel_table_uid: {
            field: 'panel_table_uid',
            type: DataTypes.INTEGER,
        },
        flaw_class_type: {
            field: 'flaw_class_type',
            type: DataTypes.INTEGER,
        },
        station_id: {
            field: 'station_id',
            type: DataTypes.INTEGER,
        },
        station_name: {
            field: 'station_name',
            type: DataTypes.STRING,
        },
        show: {
            field: 'show',
            type: DataTypes.STRING,
        },
        flaw_count: {
            field: 'flaw_count',
            type: DataTypes.INTEGER,
        },
        symbol: {
            field: 'symbol',
            type: DataTypes.STRING,
        },
        color: {
            field: 'color',
            type: DataTypes.STRING,
        },
        shape: {
            field: 'shape',
            type: DataTypes.INTEGER,
        },

    }
]

// 精度检测工位初始化数据
const panelJingduInitData = [
    {
        uid: {
            field: 'uid',
            type: DataTypes.BIGINT(11),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        panel_id: {
            field: 'panel_id',
            type: DataTypes.STRING,
        },
        gen_time: {
            field: 'gen_time',
            type: DataTypes.BIGINT,
        },
        gen_time_str: {
            field: 'gen_time_str',
            type: DataTypes.STRING,
        },
        is_ok: {
            field: 'is_ok',
            type: DataTypes.INTEGER,
        },
        // length_md: {
        //     field: 'length_md',
        //     type: DataTypes.INTEGER,
        // },
        // length_cd: {
        //     field: 'length_cd',
        //     type: DataTypes.INTEGER,
        // },
        save_path: {
            field: 'save_path',
            type: DataTypes.STRING,
        },
        lt_x: {
            field: 'lt_x',
            type: DataTypes.DOUBLE,
        },
        lt_y: {
            field: 'lt_y',
            type: DataTypes.DOUBLE,
        },
        lb_x: {
            field: 'lb_x',
            type: DataTypes.DOUBLE,
        },
        lb_y: {
            field: 'lb_y',
            type: DataTypes.DOUBLE(255, 12),
        },
        rb_x: {
            field: 'rb_x',
            type: DataTypes.DOUBLE,
        },
        rb_y: {
            field: 'rb_y',
            type: DataTypes.DOUBLE,
        },
        rt_x: {
            field: 'rt_x',
            type: DataTypes.DOUBLE,
        },
        rt_y: {
            field: 'rt_y',
            type: DataTypes.DOUBLE
        },
        is_ok_lt: {
            field: 'is_ok_lt',
            type: DataTypes.INTEGER
        },
        is_ok_lb: {
            field: 'is_ok_lb',
            type: DataTypes.INTEGER
        },
        is_ok_rb: {
            field: 'is_ok_rb',
            type: DataTypes.INTEGER
        },
        is_ok_rt: {
            field: 'is_ok_rt',
            type: DataTypes.INTEGER
        },
        save_path_lt: {
            field: 'save_path_lt',
            type: DataTypes.STRING
        },
        save_path_lb: {
            field: 'save_path_lb',
            type: DataTypes.STRING
        },
        save_path_rt: {
            field: 'save_path_rt',
            type: DataTypes.STRING
        },
        save_path_rb: {
            field: 'save_path_rb',
            type: DataTypes.STRING
        },
        save_path_rb: {
            field: 'save_path_rb',
            type: DataTypes.STRING
        }
    }
]

module.exports = {
    jobInitData,
    flawInitData,
    panelInitData,
    flawFilterInitData,
    panelJingduInitData
}
