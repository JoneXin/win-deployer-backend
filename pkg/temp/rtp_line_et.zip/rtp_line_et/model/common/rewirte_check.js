'use strict';
// 1,查询目标库的panel信息
// 2,回写汇总库的checked字段
const reWriteSummaryChecked = async (PanelPol, panel_id) => {
    let panelInfo = await PanelPol.findAll({
        where: {
            panel_id
        },
        order: [['uid', 'DESC']],
        limit: 1
    });
    let res = await PanelPol.bulkCreate([{ ...panelInfo[0].dataValues, checked: 1 }], {
        updateOnDuplicate: ['checked']
    });
    return res;
}

/**
 * 回写 6个工站的中间库的checked字段
 * @param {string} panel_uuid
 * @returns res
 */
const reWriteOtherChecked = async (PanelPol, panel_uuid) => {
    let panelInfo = await PanelPol.findAll({
        where: {
            panel_uuid
        }
    });
    let res = await PanelPol.bulkCreate([{ ...panelInfo[0].dataValues, checked: 1 }], {
        updateOnDuplicate: ['checked']
    });
    return res;
}

module.exports = {
    reWriteSummaryChecked,
    reWriteOtherChecked
}