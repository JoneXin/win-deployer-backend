'use strict'

const { Model } = require('sequelize');
const { panelInitData } = require('../../common/init_data');
const {
    getLatestPanelFromSource,
    getLatestPanelId,
    findLatestPanelInfo,
    uploadPolInfo
} = require('../common/panel');
const { reWriteOtherChecked } = require('../../common/rewirte_check');

class PanelPiantieqian extends Model { }


const initPiantieqianPanelData = (sequelize_aim) => {
    PanelPiantieqian.init(
        ...panelInitData, {
        freezeTableName: true,
        sequelize: sequelize_aim,
        modelName: 'panel',
        timestamps: false
    }
    )
}

PanelPiantieqian.getLatestPanelFromSource = getLatestPanelFromSource;
PanelPiantieqian.getLatestPanelId = getLatestPanelId;
PanelPiantieqian.findLatestPanelInfo = findLatestPanelInfo;
PanelPiantieqian.uploadPolInfo = uploadPolInfo;
PanelPiantieqian.reWriteChecked = reWriteOtherChecked;
module.exports = {
    PanelPiantieqian,
    initPiantieqianPanelData
};