/**
 * @file {cf_pol目标库flaw表model}
 */
'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const {flawInitData} = require('../../common/init_data');
class FlawCfPol extends Model { }
const {
    getNewsPanelInfoFromLineDb,
    getLatestFlawId,
    getFlawInfoByPanelId,
    uploadPolInfo
} = require('../common/flaw');

const initCfPolFlawData = (sequelize_aim) => {
FlawCfPol.init(
    ...flawInitData,
    {
        freezeTableName: true,
        sequelize: sequelize_aim,
        modelName: 'flaw',
        timestamps: false
    }
    )
}
FlawCfPol.getNewsPanelInfoFromLineDb = getNewsPanelInfoFromLineDb;
FlawCfPol.getLatestFlawId = getLatestFlawId;
FlawCfPol.getFlawInfoByPanelId = getFlawInfoByPanelId;
FlawCfPol.uploadPolInfo = uploadPolInfo;

module.exports = {
    FlawCfPol,
    initCfPolFlawData
};