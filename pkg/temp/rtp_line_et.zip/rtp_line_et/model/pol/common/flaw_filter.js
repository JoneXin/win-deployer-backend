'use strict'

// 查询源库最新贴的片的uid
const getMaxPanelUid = async (sequelize_source) => {
    let res = await sequelize_source.query('select max(uid) as uid from sheet', { type: sequelize_source.QueryTypes.SELECT });
    return res.length ? res[0].uid : 0;
}

const getNewsFlawFilterInfoFromLineDb = async (sequelize_aim, panelId) => {
    let res = await sequelize_aim.query(`select * from flaw_filter where panel_id = ${panelId}`, { type: sequelize_aim.QueryTypes.SELECT });
    return res[0];
}

// 查询目标库Flaw_filter 最新同步的位置(id)
const getLatestFlawFilterId = async (sequelize_aim, flawFilterUid) => {
    // 第一次进的时候，这里FlawFIlter 也对应更新上一次可能没同步完的数据
    if (flawFilterUid) {
        let res = await sequelize_aim.query(`select min(id) as id from flaw_filter where panel_table_uid = ${flawFilterUid}`, { type: sequelize_aim.QueryTypes.SELECT });
        return res.length ? res[0].id - 1 : 0;
    } else {
        let res = await sequelize_aim.query('select max(id) as id from flaw_filter', { type: sequelize_aim.QueryTypes.SELECT });
        return res.length ? res[0].id : 0;
    }
}

// 查询目标库flaw_filter 同步的最新 panel_id
const getMaxPanelIdFromFlawFilter = async (sequelize_aim) => {
    let res = await sequelize_aim.query('select max(panel_table_uid) as id from flaw_filter', { type: sequelize_aim.QueryTypes.SELECT });
    return res[0].id ? res[0].id : 1;
}

/**
 * 查询某片缺陷分类信息
 * @param {sequelize} sequelize_source
 * @param {string | number} queryStr panel_id | uid
 * @returns 缺陷分类信息
 */
const getFlawFilterInfoByPanelId = async (sequelize_source, queryStr, stationName) => {
    // 根据panelId
    if (typeof queryStr == 'string') {
        let res_panel = await sequelize_source.query(`select uid as id from sheet where panel_id = "${queryStr}" order by uid desc limit 1`, { type: sequelize_source.QueryTypes.SELECT });
        queryStr = res_panel.length ? res_panel[0].id : 1;
    }

    // 没有panel_id的sheet缺陷信息不同步
    let panelIdInfo = await sequelize_source.query(`select panel_id from sheet where uid = ${queryStr} order by uid desc limit 1`, { type: sequelize_source.QueryTypes.SELECT });

    if (!panelIdInfo[0] || !panelIdInfo[0].panel_id) return [];
    let resJob = await sequelize_source.query(`select job_id from sheet where uid = ${queryStr}`, { type: sequelize_source.QueryTypes.SELECT })
    // 根据uid查
    let res_flaw = await sequelize_source.query(`select class_id as flaw_class_type from flaw where sheet_id = ${queryStr} and job_id = ${resJob[0].job_id}`, { type: sequelize_source.QueryTypes.SELECT });
    let res_panel = await sequelize_source.query(`select panel_id, uid as panel_table_uid from sheet where uid = ${queryStr}`, { type: sequelize_source.QueryTypes.SELECT });
    // let res_flaw_type = await sequelize_source.query('select a.class_id as flaw_class_type, a.card_txt as symbol, a.name as `show`, b.color, b.shape from flaw_info a inner join flaw_type b on  a.class_id = b.class_id', { type: sequelize_source.QueryTypes.SELECT });
    // 如果有缺陷
    if (res_flaw.length) {
        if (res_panel.length) {
            let arr = [];
            // 所有缺陷
            res_flaw.forEach(item => {
                // 缺陷类型全集
                arr.push({
                    ...item,
                    panel_id: res_panel[0].panel_id,
                    panel_table_uid: res_panel[0].panel_table_uid,
                    flaw_class_type: item.flaw_class_type + '__' + stationName
                })
            })
            return arr;
        } else {
            console.log(`pol工站缺陷类型 || 无此片的panel信息`);
            return res_flaw[0];
        }
    } else {
        return [];
    }
}

// 获取缺陷类型全集
const getAllFlawType = async (sequelize_source, query) => {
    let queryStr = '';
    if (typeof query == 'string') {
        queryStr = `(select job_id from sheet where panel_id = "${query}" order by uid desc limit 1)`
    } else {
        queryStr = `(select job_id from sheet where uid = ${query} order by uid desc limit 1)`
    }
    let res = await sequelize_source.query(`select detect_param, uid from job where uid = ${queryStr}`, { type: sequelize_source.QueryTypes.SELECT });
    return res.length ? res.map(v => {
        let temp = JSON.parse(v.detect_param)
        return {
            ...v,
            detect_param: JSON.stringify(temp.flaw_class)
        }
    }) : []
}

// 上传缺陷分类
const uploadPolInfo = async (FlawFilterCfPol, data) => {
    let res = await FlawFilterCfPol.bulkCreate([...data], {
        updateOnDuplicate: ['uid', 'panel_id', 'panel_table_uid', 'flaw_class_type', 'show', 'flaw_count', 'symbol', 'color', 'station_id', 'station_name', 'shape']
    });
    return res;
}

module.exports = {
    getMaxPanelUid,
    getNewsFlawFilterInfoFromLineDb,
    getLatestFlawFilterId,
    getMaxPanelIdFromFlawFilter,
    getFlawFilterInfoByPanelId,
    uploadPolInfo,
    getAllFlawType
};
