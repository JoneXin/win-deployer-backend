'use strict'

// 获取源库job表的最大uid
const getMaxUidfromSourceJob = async (sequelize_source) => {
    let res = await sequelize_source.query('select max(uid) as uid from job', { type: sequelize_source.QueryTypes.SELECT });
    return res[0].uid;
}

// 获取目标库的job的最大uid
const getLatestJobId = async (sequelize_aim) => {
    let res = await sequelize_aim.query('select max(uid) as uid from job', { type: sequelize_aim.QueryTypes.SELECT });
    return res[0].uid ? res[0].uid : 1;
}

/**
 * 根据panelid获取job信息  |  根据job uid获取job信息
 * @param {Sequelize} sequelize_source
 * @param {string | number} queryStr
 * @returns  job信息
 */
const getJobInfoByPanelId = async (sequelize_source, queryStr) => {
    let query = typeof (queryStr) == 'string' ? ` uid = (select job_id from sheet where panel_id = "${queryStr}") ` : ` uid =  ${queryStr}`;
    let res = await sequelize_source.query(`select uid, job_name, sheet_sum as panel_sum, ok_number, ng_number, start_time, start_time_str, finish_time, finish_time_str, lot_number as order_number from job where ${query}`, { type: sequelize_source.QueryTypes.SELECT });
    return res[0];
}

/**
 * 获取有panel_id的sheet信息
 * @param {*} sequelize_source 
 * @param {*} queryStr 
 * @param {*} sheet_sum 
 * @returns 
 */
const getPanelExistJobInfo = async (sequelize_source, queryStr, sheet_sum) => {
    // 没有panelId的片的数量
    let ngSheetInfo = await sequelize_source.query(`select count(*) as ngSheetNum from sheet where (panel_id is null or trim(panel_id)='') and job_id = ${queryStr}`, { type: sequelize_source.QueryTypes.SELECT });
    // 有panelid的NG片数量
    let paneExsitInfo = await sequelize_source.query(`select count(*) as ngPanelNum from sheet where trim(panel_id) != '' and job_id = ${queryStr} and flaw_count > 0`, { type: sequelize_source.QueryTypes.SELECT });

    console.log(ngSheetInfo, paneExsitInfo);
    return {
        panel_sum: sheet_sum - ngSheetInfo[0].ngSheetNum,
        ok_number: sheet_sum - ngSheetInfo[0].ngSheetNum - paneExsitInfo[0].ngPanelNum,
        ng_number: paneExsitInfo[0].ngPanelNum
    }
}

// 上传job信息
const uploadPolInfo = async (JobPol, data) => {
    let res = await JobPol.bulkCreate([data], {
        updateOnDuplicate: ['uid', 'job_name', 'panel_sum', 'ok_number', 'ng_number', 'start_time', 'finish_time', 'start_time_str', 'finish_time_str'],
    });
    return res;
}
module.exports = {
    getMaxUidfromSourceJob,
    getLatestJobId,
    getJobInfoByPanelId,
    uploadPolInfo,
    getPanelExistJobInfo
};