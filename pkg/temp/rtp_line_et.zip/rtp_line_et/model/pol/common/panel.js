'use strict'


const updateDetectParam = async (PanelPol, uid, detectParam) => {
    let res = await PanelPol.update({ detectParam }, { where: { uid } });
    return res;
}

// 通过panelId 查询目标库某片panel的信息
const getNewsPanelInfoFromLineDb = async (sequelize_aim, panelId) => {
    let res = await sequelize_aim.query(`select * from panel where panel_id = ${panelId}`, { type: sequelize_aim.QueryTypes.SELECT });
    return res[0];
}

// 获取源库的最新的sheet_id
const getMaxUidfromSourcePanel = async (sequelize_source) => {
    let res = await sequelize_source.query('select max(uid) as uid from sheet', { type: sequelize_source.QueryTypes.SELECT });
    return res[0].uid;
}

// 查询目标库最新的panel
const getLatestPanelId = async (sequelize_aim) => {
    let res = await sequelize_aim.query('select max(uid) as uid from panel', { type: sequelize_aim.QueryTypes.SELECT });
    return res[0].uid ? res[0].uid : 1;
}

/**
 * 查询panelId 对应片 |  uid 对应的片
 * @param {sequelize} sequelize_source
 * @param {string | number} queryStr panelId | uid
 * @returns panel 信息
 */
const getLatestPanel = async (sequelize_source, queryStr) => {
    // 通过panelId 查询panel信息
    if (typeof queryStr == 'string') {
        let res_panel = await sequelize_source.query(`select uid as id from sheet where panel_id = "${queryStr}" order by uid desc limit 1`, { type: sequelize_source.QueryTypes.SELECT });
        queryStr = res_panel.length ? res_panel[0].id : 1;
    }
    // 根据 panel的uid查 sheet这片膜对应的信息
    let res_sheet = await sequelize_source.query(`select * from sheet where uid = ${queryStr}`, { type: sequelize_source.QueryTypes.SELECT });

    if (res_sheet.length) {
        // lot_id
        let res_job = await sequelize_source.query(`select lot_number as lot_id from job where uid = ${res_sheet[0].job_id}`, { type: sequelize_source.QueryTypes.SELECT });
        if (res_job.length) {
            return {
                ...res_sheet[0],
                lot_id: res_job[0].lot_id
            }
        } else {
            console.log(`sheet: uid -> ${queryStr}job源库丢失数据!`);
            return {
                ...res_sheet[0]
            };
        }
    } else {
        return null;
    }
}

// 上出传panel信息
const uploadPolInfo = async (PanelPol, data) => {
    let res = await PanelPol.bulkCreate([data], {
        updateOnDuplicate: ['job_id', 'panel_id', 'length_md', 'length_cd', 'save_path', 'gen_time', 'gen_time_str', 'flaw_count', 'is_ok', 'detectParam', 'checked', 'lot_id']
    });
    return res;
}

module.exports = {
    getNewsPanelInfoFromLineDb,
    getMaxUidfromSourcePanel,
    getLatestPanelId,
    getLatestPanel,
    uploadPolInfo,
    updateDetectParam
};