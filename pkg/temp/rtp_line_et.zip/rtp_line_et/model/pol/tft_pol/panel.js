/**
 * @file {cf_pol目标库flaw表model}
 */
'use strict'

const { Model } = require('sequelize');
const { panelInitData } = require('../../common/init_data');
class PanelTftPol extends Model { }
const {
    getNewsPanelInfoFromLineDb,
    getMaxUidfromSourcePanel,
    getLatestPanelId,
    getLatestPanel,
    uploadPolInfo,
    updateDetectParam
} = require('../common/panel');
const { reWriteOtherChecked } = require('../../common/rewirte_check');

const initTftPanelData = (sequelize_aim) => {
    PanelTftPol.init(
        ...panelInitData,
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'panel',
            timestamps: false
        }
    )
}
PanelTftPol.getNewsPanelInfoFromLineDb = getNewsPanelInfoFromLineDb;
PanelTftPol.getMaxUidfromSourcePanel = getMaxUidfromSourcePanel;
PanelTftPol.getLatestPanelId = getLatestPanelId;
PanelTftPol.getLatestPanel = getLatestPanel;
PanelTftPol.uploadPolInfo = uploadPolInfo;
PanelTftPol.updateDetectParam = updateDetectParam;
PanelTftPol.reWriteChecked = reWriteOtherChecked;

module.exports = {
    PanelTftPol,
    initTftPanelData
};