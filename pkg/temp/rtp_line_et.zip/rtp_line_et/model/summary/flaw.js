/**
 * @file {pantie目标库flaw表model}
 */
'use strict'

const { DataTypes, Model, Op } = require('sequelize');
const { flawInitData } = require('../common/init_data');
class FlawMujian extends Model { }

/**
 * @desc 映射需要的字段 【源库的 部分字段 --> 目标库字段】
 */
const initFlawMujinaData = (sequelize_aim) => {
    FlawMujian.init(
        {
            uid: {
                field: 'uid',
                type: DataTypes.INTEGER,
                allowNull: false,
                primaryKey: true,
                autoIncrement: true,
            },
            job_id: {
                field: 'job_id',
                type: DataTypes.INTEGER,
            },
            panel_id: {
                field: 'panel_id',
                type: DataTypes.STRING,
            },
            panel_table_uid: {
                field: 'panel_table_uid',
                type: DataTypes.INTEGER,
            },
            center_pos_md: {
                field: 'center_pos_md',
                type: DataTypes.DECIMAL,
            },
            center_pos_cd: {
                field: 'center_pos_cd',
                type: DataTypes.DECIMAL,
            },
            length_md: {
                field: 'length_md',
                type: DataTypes.DECIMAL,
            },
            length_cd: {
                field: 'length_cd',
                type: DataTypes.DECIMAL,
            },
            contours: {
                field: 'contours',
                type: DataTypes.TEXT,
            },
            gen_time: {
                field: 'gen_time',
                type: DataTypes.BIGINT,
            },
            gen_time_str: {
                field: 'gen_time_str',
                type: DataTypes.STRING,
            },
            save_path: {
                field: 'save_path',
                type: DataTypes.STRING,
            },
            ui_show_text: {
                field: 'ui_show_text',
                type: DataTypes.STRING,
            },
            area: {
                field: 'area',
                type: DataTypes.DECIMAL,
            },
            diameter: {
                field: 'diameter',
                type: DataTypes.DECIMAL,
            },
            camera_id: {
                field: 'camera_id',
                type: DataTypes.INTEGER,
            },
            flaw_class_type: {
                field: 'flaw_class_type',
                type: DataTypes.STRING,
            },
            lot_id: {
                field: 'lot_id',
                type: DataTypes.STRING,
            },
            sync_db: {
                field: 'sync_db',
                type: DataTypes.STRING,
            },
            sync_id: {
                field: 'sync_id',
                type: DataTypes.INTEGER,
            },
            show: {
                field: 'show',
                type: DataTypes.STRING,
            },
            ex_info: {
                field: 'ex_info',
                type: DataTypes.TEXT,
            }
        },
        {
            freezeTableName: true,
            sequelize: sequelize_aim,
            modelName: 'flaw',
            timestamps: false
        }
    )
}

/**
 * 上传flaw信息
 * @param {Array} data 上传的缺陷信息数组
 * @returns 
 */
FlawMujian.uploadInfo = async (data) => {

    // ignoreDuplicates: 忽略重复数据
    let res = await FlawMujian.bulkCreate(data, {
        fields: ['job_id', 'panel_id', 'panel_table_uid', 'center_pos_md', 'center_pos_cd', 'length_md', 'length_cd', 'contours', 'gen_time', 'gen_time_str', 'save_path', 'ui_show_text', 'area', 'diameter', 'camera_id', 'flaw_class_type', 'lot_id', 'show', 'ex_info']
    });
    return res;
}

// 更新
FlawMujian.updateFlawPos = async (data) => {

    // ignoreDuplicates: 忽略重复数据
    let res = await FlawMujian.bulkCreate(data, { updateOnDuplicate: ['center_pos_md', 'center_pos_cd'] });
    return res;
}

module.exports = {
    FlawMujian,
    initFlawMujinaData
};