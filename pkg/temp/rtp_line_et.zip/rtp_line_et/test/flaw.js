const handleFlaw = require('../class/summary/flaw');
(async () => {
    // setInterval(async () => {
    //     const res = await handleFlaw.handleSyncToFlaw();
    //     console.log(res);
    // }, 2000);
    const res = await handleFlaw.handleSyncToFlaw();
    console.log(res);
})()