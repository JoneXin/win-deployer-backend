const handleFlawFilter = require('../class/summary/flaw_filter');
(async () => {
    // setInterval(async () => {
    //     const res = await handleFlawFilter.handleSyncToFlawFilter();
    //     console.log(res);
    // }, 2000);
    const res = await handleFlawFilter.handleSyncToFlawFilter();
    console.log(res);
})()