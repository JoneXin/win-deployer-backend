let handleUuid = require('../class/summary/handle_uuid');
const { linedb_piantiehou_config, linedb_cf_jingdujiance_config, linedb_cf_pol_config, linedb_piantieqian_config, linedb_tft_jingdujiance_config, linedb_tft_pol_config } = require('../config.json').line_db;
const seqPiantiehou = require('../lib/db').getSequelizeInstance(linedb_piantiehou_config);
const seqPiantieqian = require('../lib/db').getSequelizeInstance(linedb_piantieqian_config);
const seqCfJingdujiance = require('../lib/db').getSequelizeInstance(linedb_cf_jingdujiance_config);
const seqTftJingdujiance = require('../lib/db').getSequelizeInstance(linedb_tft_jingdujiance_config);
const seqCfPol = require('../lib/db').getSequelizeInstance(linedb_cf_pol_config);
const seqTftPol = require('../lib/db').getSequelizeInstance(linedb_tft_pol_config);

// setTimeout(async () => {
//     let res1 = await handleUuid.addQueue(seqPiantiehou, 'PANELID123123123380');
//     console.log('res1');
//     console.log(res1);
//     let res2 = await handleUuid.addQueue(seqPiantiehou, 'PANELID123123123381');
//     console.log('res2');
//     console.log(res2);
// }, 2000);
// setTimeout(async () => {
//     let res3 = await handleUuid.addQueue(seqPiantiehou, 'PANELID123123123382');
//     console.log('res3');
//     console.log(res3);
//     let res4 = await handleUuid.addQueue(seqPiantiehou, 'PANELID123123123383');
//     console.log('res4');
//     console.log(res4);
// }, 4000);
setTimeout(async () => {
    for (let i = 1; i <= 36; i++) {
        let res = await handleUuid.addQueue(seqPiantiehou, 'PANELID0000' + i);
        console.log('res' + i);
        console.log(res);
    }
}, 1000);