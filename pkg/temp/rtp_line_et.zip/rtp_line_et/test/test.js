const Toos = require('../uitls/tools');

let res = Toos.getRotatedFlawPoints(
    {x: 0.25, y : 79.66}, 
    {rotate: 90, xMirror: false, width: 1250, height: 1202.35}
);

console.log(res);