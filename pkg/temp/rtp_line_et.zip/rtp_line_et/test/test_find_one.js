const {PanelSourceCfJingdu} = require('../model/jingdujiance/cf_jingdu_source');

PanelSourceCfJingdu.getMaxUidFromSource(1);
