const queue = require('queue');
const { linedb_summary_config } = require('../config.json').line_db;
// let dbConfig = {
//     "host": "115.236.65.98",
//     "user": "root",
//     "port": 9400,
//     "password": "root",
//     "database": "rtp_summary"
// }
const seqSummary = require('../lib/db').getSequelizeInstance(linedb_summary_config);

class testQueue {
    constructor() {
        this.execQueue = queue({ concurrency: 1, autostart: true });
        this.handleQueue();
    }

    // 单例
    static getInstance() {
        if (!testQueue.instance) {
            testQueue.instance = new testQueue();
        }
        return testQueue.instance;
    }


    addQueue = (pId) => {
        this.execQueue.push(
            async (cb) => {
                console.log('调用了');
                await this.queueHandleItem(pId);
                cb();
            }
        )
    }

    async queueHandleItem(params) {
        try {
            if (Math.random() < 0.3) throw new Error('模拟发生错误');
            console.log('exec' + params);
            let res = await seqSummary.query('select * from panel_summary where panel_id=' + params, { type: seqSummary.QueryTypes.SELECT });
            console.log(res);
        } catch (error) {
            console.log(error);
            await this.queueHandleItem(params);
        }
    }

    handleQueue = () => {
        // this.execQueue.push(this.testQueue, this.testQueue, this.testQueue);

        // console.log('queue before start');
        this.execQueue.start(function (err) {
            if (err) throw err;
            console.log('all done:');
        });
        // console.log('queue finish');
    }

}

module.exports = testQueue.getInstance();

// let queueInstance = testQueue.getInstance();

// setTimeout(() => {
//     queueInstance.addQueue(5);
//     queueInstance.addQueue(6);
// }, 2000)
// queueInstance.addQueue(5);