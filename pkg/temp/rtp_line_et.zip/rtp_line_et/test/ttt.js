let a = JSON.stringify([1, 2, 3]); let b = (JSON.stringify([6, 8, 9]));
let c = JSON.parse(a).concat(JSON.parse(b));
console.log(c);